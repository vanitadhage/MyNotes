class ThisKeywordParent
{
	ThisKeywordParent()
	{
		super();
		System.out.println("No argu Praent const");
	}
}
class ThisKeywordChild extends ThisKeywordParent
{
	ThisKeywordChild()
	{
		this(10);
		System.out.println("No argu ThisKeywordChild const");
	}
	ThisKeywordChild(int a)
	{
		super();
		System.out.println("1 argu ThisKeywordChild const");
	}
	public static void main(String[] args) {
		ThisKeywordChild a=new ThisKeywordChild();
	}
}