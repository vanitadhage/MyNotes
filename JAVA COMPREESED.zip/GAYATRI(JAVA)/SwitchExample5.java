class SwitchExample5
{
	public static void main(String[] args) 
	{
	   String a = "RAMESH";
	   switch(a)
	   {
	   	case "RAMESH":System.out.println("case 1");
	   	       
	   	case "SURESH":System.out.println("case 2");

	   	case "MAHESH":System.out.println("case 3");

	   	case "GANESH":System.out.println("case 4");break;
	   	       
	   	default:System.out.println("From default ");
	   }	
	}
}