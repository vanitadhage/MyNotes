import java.util.*;
class BubbleSortAsc
{
	public static void main(String[] args) 
	{
	  int []arr={9,45,2,81,26,19,23,5,7,92,54,18};
	  System.out.println(Arrays.toString(arr));
	  int temp=0;

	  for (int i=0;i<arr.length ;i++ ) {
	  		for (int j=i+1;j<arr.length ;j++ ) {
	  			if (arr[i]>arr[j]) {
	  				temp=arr[i];
	  				arr[i]=arr[j];
	  				arr[j]=temp;
	  			}
	  		}
	  	}	
	  	System.out.print(Arrays.toString(arr));
	}
}