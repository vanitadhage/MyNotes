import java.util.*;
class OneDArray
{
	public static void main(String[] args) {

		//1 For int
		// int []arr={10,20,30,40,50};
		// for (int i=0;i<arr.length ;i++ ) 
		// {
		// 	System.out.print(arr[i]+"  ");
		// }

		// 2 While String
		// String []arr={"a","b","c","d","e"};
		// int i=0;
		// while(i<=arr.length-1)
		// {
		// 	System.out.print(arr[i++]+" ");
		// }
		// System.out.println();

        //3 do-while double
		// double []arr={10,20,30,40,50};
		// int i=0;
		// do{
		// 	System.out.print(arr[i]+" ");
		// 	i++;
		// }while(i<arr.length);
		// System.out.println();

		// 4 foreach
		// float []arr={10,20,30,40,50};	
		//   for (float i:arr ) 
		//   {
		//   	System.out.print(i+" ");
		//   }

		// 5 toString
		int []arr={10,20,30,40,50};
		System.out.println(Arrays.toString(arr));
	}
}