class Aeroplane 
{
  String company;
  String type;
  int noEngine;
  int seatingCap;
  double travellingRange;

  Aeroplane(String company,String type,int noEngine,int seatingCap,double travellingRange)
  {
   this.company=company;
   this.type=type;
   this.noEngine=noEngine;
   this.seatingCap=seatingCap;
   this.travellingRange=travellingRange;
  }
  public void display()
  {
  	System.out.println(this.company);
  	System.out.println(this.type);
  	System.out.println(this.noEngine);
  	System.out.println(this.seatingCap);
  	System.out.println(this.travellingRange);
  }
}
class ParameterizedConst
{
   public static void main(String[] args) {
   	Aeroplane a=new Aeroplane("AirIndia","commercial",4,100,2000);
     a.display();
   }
}