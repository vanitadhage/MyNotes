class DoorDriver
{
	public static void main(String[] args) {
		Door a=new Door("plastic","brown");
		a.displayDoor();
		a.createHandle("metal","square");
		a.handle.displayHandle();
	}
}