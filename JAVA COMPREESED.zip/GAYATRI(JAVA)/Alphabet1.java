class Alphabet1
{
	public static void main(String[] args) {
		for (char i='Z';i>='A' ;--i ) {
			System.out.print(i +"  ");
		}
	}
}