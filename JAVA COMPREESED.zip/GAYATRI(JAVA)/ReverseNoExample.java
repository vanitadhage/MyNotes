import java.util.Scanner;
class ReverseNoExample
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a num :");
		int num=sc.nextInt();//123
		int rev=0;//0
		int rem=num%10;//3
		rev=rem;//3
		num=num/10;//12
		rem=num%10;//2
		rev=rev*10+rem;//32
		num=num/10;//1
		rev=rev*10+num;//321
		System.out.println("Reverse number is :"+rev);
	}
}