class Example17
{
	public static void main(String[] args) 
	{
	   Example17 a=new Example17();
	   a.m1();	
	}
	public void m1()
	{
		System.out.println("Hello");
	}
}