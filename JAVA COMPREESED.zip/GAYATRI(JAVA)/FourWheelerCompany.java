class FourWheelerCompany
{
 public static void main(String [] args)
  {
   int noOfProduct=1146894321;
   int noOfSellProduct=1504467984;
   int noOfReturnProduct=604467984;
   int profitOnProduct=1432993432;
   int productDemand=1643568128;
   System.out.println("no Of Product :"+noOfProduct);
   System.out.println("no Of Sell Product :"+noOfSellProduct);
   System.out.println("no Of Return Product :"+noOfReturnProduct);
   System.out.println("profit On Product :"+profitOnProduct);
   System.out.println("product Demand:"+productDemand);
  }
} 