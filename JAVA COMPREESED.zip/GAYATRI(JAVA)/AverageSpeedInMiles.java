import java.util.Scanner;
class AverageSpeedInMiles
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		float mph,kph;

		System.out.print("distance in kilometer :");
		float distance=sc.nextFloat();

		System.out.print("minutes :");
		float min=sc.nextFloat();

		System.out.print("second :");
		float sec=sc.nextFloat();

		Float timesecond=(min*3600)+(min*60)+sec;
		kph=(distance/1000.0f)/(timesecond/3600.0f);
		mph=kph/1.6f;

		System.out.println("speed in km/h is :"+kph);
		System.out.println("speed in miles is :"+mph);
	}
}