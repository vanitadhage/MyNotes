//write a java program to find even odd number without moduls operator
import java.util.Scanner;
class EvenOdd1
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		for (int i=1;i>=5 ;i++ ) {
			if (i/2==0) {
				System.out.print("it is even number");
			}
		}
	}
}