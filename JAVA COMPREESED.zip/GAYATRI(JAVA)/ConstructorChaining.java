class ConstructorChaining1
{
	ConstructorChaining1()
	{
		this(10);
		System.out.println("No argu const");
	}
	ConstructorChaining1(int a)
	{
		this(10,20);
		System.out.println("1 argu const");
	}
	ConstructorChaining1(int a,int b)
	{
		System.out.println("2 argu const");
	}
}
class ConstructorChaining
{
	public static void main(String[] args) 
	{
		ConstructorChaining1 a=new ConstructorChaining1();
		
    }
}