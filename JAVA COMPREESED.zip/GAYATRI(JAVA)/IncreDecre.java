class IncreDecre
{
	public static void main(String[] args) {
		int a=1;
		int b=++a;//2
		int c=b--;//2(1)
                          //3  +3    +0   +0     +2   +2   +1  +1=12
		System.out.println(++a + a-- + --b + b++ + c-- + a + b + c);
	}
}