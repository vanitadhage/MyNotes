class CellPhone
{
	String brand;
	String type;
	double price;
	double screenShot;
	String model;
	int camera;
	int ram;
	int rom;

	public void displayPhone()
	{
		System.out.println("*****CellPhone Info*****");
		System.out.println("Brand :"+brand);
		System.out.println("Type :"+type);
		System.out.println("Model :"+model);
		System.out.println("Price :"+price);
		System.out.println("Screen Shot "+screenShot+"inches");
		System.out.println("Camera :"+camera+"px");
		System.out.println("Ram :"+ram+"gb");
		System.out.println("Meomery :"+rom+"gb");
		System.out.println();
	}
}
class CellPhoneDriver
{
	public static void main(String[] args) 
	{
		CellPhone a=new CellPhone();
		a.brand="SAMSUNG";
		a.type="SmartPhone";
		a.price=150000;
		a.screenShot=6.5;
		a.camera=200;
		a.model="S23 ultra";
		a.ram=12;
		a.rom=1024;
		a.displayPhone();
	}
}