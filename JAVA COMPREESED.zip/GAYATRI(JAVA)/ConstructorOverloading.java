class ConstructorOverloading
{
	ConstructorOverloading()
	{
		System.out.println("No argu constructor");
	}
	ConstructorOverloading(int a)
	{
		System.out.println("1 argu int const");
	}
	ConstructorOverloading(byte a)
	{
		System.out.println("1 argu byte const");
	}
	ConstructorOverloading(int a,int b)
	{
		System.out.println("2 argu const");
	}
	public static void main(String[] args) {
		ConstructorOverloading a=new ConstructorOverloading();
		ConstructorOverloading b=new ConstructorOverloading(10);
		ConstructorOverloading c=new ConstructorOverloading(20);
		ConstructorOverloading d=new ConstructorOverloading(100,200);
	}
}