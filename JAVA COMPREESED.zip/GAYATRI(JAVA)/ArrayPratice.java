import java.util.*;
class ArrayPratice
{
	public static void main(String[] args) 
	{
		
	}
}