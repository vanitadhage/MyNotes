class WhileEx2
{
	public static void main(String[] args) {
		final boolean a=false;
		while(a)
		{
			System.out.println("hello");
		}
		System.out.print("byee");
	}
}