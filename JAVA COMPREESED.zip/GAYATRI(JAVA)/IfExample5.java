import java.util.Scanner;
class IfExample5
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the score :");
		int score=sc.nextInt();

		if (score>90) {
			score=(score+(score*3/100));
			System.out.println("Increses the pay by 3% :"+score);
		}
	}
}