class Library
{
	String name;
	double startTime;
	double endTime;
	double fees;
	String address;
	long contactNumber;
	Book book;
	Librarian librarian;
	Shelf shelf;
	Student student;

	Library(String name,double startTime,double endTime,double fees,String address,long contactNumber,Book book)
	{
		this.name=name;
		this.startTime=startTime;
		this.endTime=endTime;
		this.fees=fees;
		this.address=address;
		this.contactNumber=contactNumber;
		this.book=book;
	}
	public void displayLibrary()
	{
		System.out.println("****Library Details ***");
		System.out.println("Name :"+this.name);
		System.out.println("Address :"+this.address);
		System.out.println("Fees :"+this.fees);
		System.out.println(" Timing :"+this.startTime+"am - "+this.endTime+"pm");
		System.out.println("Contact Number :"+this.contactNumber);
		System.out.println();
	}
	public void addLibrarian()
	{
      
	 String name ="Priti";
	 String gender="Female";
	 long contactNumber=98765543320l;
	 String address="Kothrud-pune";
	 String shift="day";
     
      librarian=new Librarian(name,gender,contactNumber,address,shift);
	}
	public void addShelf()
	{
		String type="Historic";
	    int capacity=150;
	    shelf =new Shelf(type,capacity);
	}
	public void addStudent()
	{
		String name="Gayatri";
	    String gender="Female";
	    long contactNumber=8876546534l;
	    String address="Karvenagar-pune";
	    String department="CS";

	    student=new Student(name,gender,contactNumber,address,department);
	} 

}