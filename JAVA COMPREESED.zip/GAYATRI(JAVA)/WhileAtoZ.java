class WhileAtoZ
{
	public static void main(String[] args) {
		char i='Z';
		while(i>='A')
		{
			System.out.println(i);
			i--;
		}
	}
}