import java.util.Scanner;
class SunnyNo
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		int b=num+1;
		int sqrt=0;                               //to find square root sqrt=0; if(i*i==num){sqrt=i;break;}

		for (int i=1;i<=num/2 ;i++ ) {
			if (i*i==b) {
				sqrt=i;
			    break;
			}
		}
		if (sqrt>0) {
			System.out.println("Sunny number");
		}
		else
		{
			System.out.println("It is not Sunny number");
		}
	}
}