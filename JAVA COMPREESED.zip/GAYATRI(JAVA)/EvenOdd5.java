//write a java program to find even odd number without moduls operator
import java.util.Scanner;
class EvenOdd5
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		
			if ((num & 1)==0) {
				System.out.print("it is even number");
			}
			else
			{
				System.out.print("It is odd ");
			}
		
	}
}