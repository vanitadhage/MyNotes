// class Pattern3
// {
// 	public static void main(String[] args) {
// 		for (int i=1;i<=5 ;i++ ) {
// 			char ch='a';
// 			for (char j=1;j<=i ;j++ ) {
// 				System.out.print(ch+" ");
// 				ch++;
// 			}
// 			System.out.println();
// 		}
// 	}

// }

// op 
// a
// a b
// a b c
// a b c d
// a b c d e

// class Pattern3
// {
// 	public static void main(String[] args) {
// 		for (int i=1;i<=5 ;i++ ) {
// 			int no=1;
// 			for (int j=1;j<=i ;j++ ) {
// 				System.out.print(no+" ");
// 				no++;
// 			}
// 			System.out.println();
// 		}
// 	}
// }
// op 
// 1
// 1 2
// 1 2 3
// 1 2 3 4
// 1 2 3 4 5

// class Pattern3
// {
// 	public static void main(String[] args) {
// 		for (int i=1;i<=5 ;i++ ) {
// 			char ch='a';
// 			for (char j=1;j<=i ;j++ ) {
// 				System.out.print(ch+" ");
// 				ch++;
// 			}
// 			System.out.println();
// 		}
// 	}
// }

// op 
// a
// a b
// a b c
// a b c d
// a b c d e


// No 1 to 6

// class Pattern3
// {
// 	public static void main(String[] args) {
		
// 		int a=1;
// 		for (int i=1;i<=3 ;i++ ) {
// 			for (int j=1;j<=i ;j++ ) {
// 				System.out.print(a+" ");
// 				a++;
// 			}
// 			System.out.println();
// 		}
// 	}
// }

// op  
// 1
// 2 3
// 4 5 6

//  class Pattern3
// {
// 	public static void main(String[] args) {
		
// 		char ch='a';
// 		for (int i=1;i<=5 ;i++ ) {
// 			for (int j=1;j<=i ;j++ ) {
// 				System.out.print(ch+" ");
// 				ch++;
// 			}
// 			System.out.println();
// 		}
// 	}
// }

// op 
// a
// b c
// d e f
// g h i j
// k l m n o


// Odd
 
//   class Pattern3
// {
// 	public static void main(String[] args) {
// 		int num=1;
// 		for (int i=1;i<=5 ;i++ ) {
// 			for (int j=1;j<=i ;j++ ) {
// 				System.out.print(num+" ");
// 				num+=2;
// 			}
// 			System.out.println();
// 		}
// 	}
// }

// op 
// 1
// 3 5
// 7 9 11
// 13 15 17 19
// 21 23 25 27 29


//Even
//  class Pattern3
// {
// 	public static void main(String[] args) {
// 		int num=2;
// 		for (int i=1;i<=5 ;i++ ) {
// 			for (int j=1;j<=i ;j++ ) {
// 				System.out.print(num+" ");
// 				num+=2;
// 			}
// 			System.out.println();
// 		}
// 	}
// }

// op 
// 2
// 4 6
// 8 10 12
// 14 16 18 20
// 22 24 26 28 30


 class Pattern3
{
	public static void main(String[] args) 
	{
		int a=1;
		int b=0;
		for (int i=1;i<=5 ;i++ ) 
		{
			if (i==1) 
			{
				System.out.print(i);
			}
			else
			{
              b=a+i;
              for (int j=b;j>a ;j-- )
			{
				System.out.print(j+" ");
			}
			a=b;
		    }
			System.out.println();
	    }
	}
}

// op 
// 1
// 3 2
// 6 5 4
// 10 9 8 7
// 15 14 13 12 11
