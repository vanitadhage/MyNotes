import java.util.*;
class ArrayFibonacci
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int []a={0,1};
		System.out.print("Enter a number :");
		int num=sc.nextInt();

		int []arr=new int[num];            
		arr[0]=0;
		arr[1]=1;

		for (int i=2;i<num ;i++ ) {
			arr[i]=arr[i-2]+arr[i-1];
		}
		System.out.println(Arrays.toString(arr));
	}
}