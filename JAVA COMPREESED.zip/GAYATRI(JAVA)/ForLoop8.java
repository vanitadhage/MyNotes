class ForLoop8
{
	public static void main(String[] args) {
		final int a=1;
		final int b=4;
		for (;b>a ; ) {
			System.out.println("hello");
			
		}
		System.out.println("byee");
	}
}