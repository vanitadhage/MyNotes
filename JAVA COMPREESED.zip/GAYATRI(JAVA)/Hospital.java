class Hospital
{
 public static void main(String [] args)
  {
   short doctors=250;
   short patients=3500;
   short noOfBeds=3700;
   short noOfNurse=3000;
   short wardBoy=60;
   System.out.println("No of doctors :"+doctors);
   System.out.println("No of patients:"+patients);
   System.out.println("No of Beds :"+noOfBeds);
   System.out.println("No of Nurse :"+noOfNurse);
   System.out.println("No of wardBoy :"+wardBoy);
  }
}