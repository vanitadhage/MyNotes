class Example7
{
	String a="Bye"; 
	public static void main(String[] args) {
		Example7 b=new Example7();
		System.out.println(b.a);
		b.m1();
	}
	public void m1()
	{
		System.out.println("hello m1()");
	}
}