class Human
{
	String name;
	Human(String name)
	{
		this.name=name;
	}
	void eat()
	{
		System.out.println("Human can eat");
	}
	void think()
	{
		System.out.println("Human can think");
	}
	void talk()
	{
		System.out.println("Human can talk");
	}
}
class UnderGradute extends Human
{
	String company;
	String branch;
	UnderGradute(String name,String company,String branch)
	{
		super(name);
		this.company=company;
		this.branch=branch;
	}
	void branch()
	{
		System.out.println("Engineer  Branch :"+this.branch);
	}
	void work()
	{
		System.out.println("Engineer is working at :-  "+this.company);
	}
}
class PostGradution extends UnderGradute
{
	String subj;
	PostGradution(String name,String subj,String company,String branch)
	{
		super(name,company,branch);
		this.subj=subj;
	}
	void stream()
	{
		System.out.println("Subject for MTech is :"+this.subj);
	}
}
class Driver3
{
	public static void main(String[] args) {
		PostGradution a=new PostGradution("Ramesh","ThermoDynamic","Infosys","Mechanical");
		System.out.println(a.name);
		a.eat();
		a.talk();
		a.think();
		a.branch();
		a.work();
		a.stream();

	}
}