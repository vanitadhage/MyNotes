import java.util.Scanner;
class IfExample3
{
	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter a score :");
        int score=sc.nextInt();
 
		if (score>90) {
		   System.out.println("pay increses by 3%");
		   //pay*=1.03;
		}
	}
}