class Bank
{
 public static void main(String [] args)
  {
    int accounts=2147542;
    int accountNo=22337676;
    int noOfLockers=1466535;
    System.out.println("Accounts :"+accounts);
    System.out.println("Account No :"+accountNo);
    System.out.println("No Of Lockers:"+noOfLockers);
   
  }
}