import java.util.Scanner;
class CirclePerimeterArea
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
        final double pi=3.14;
        System.out.print("Enter a radius :");
        double radius=sc.nextDouble();
        double perimeter =2*pi*radius;
        double area =pi*radius*radius;
        System.out.println("Radius of a circle is -"+radius+"cm");
        System.out.println("Perimeter is :"+perimeter+"cm");
        System.out.println("area is :"+area+"cm2");
	}

}