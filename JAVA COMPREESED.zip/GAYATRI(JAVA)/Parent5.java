abstract class Parent5
{
	abstract void m1();
	abstract void m2();
}
abstract class Child1 extends Parent5
{
	void m1()
	{
		System.out.println("m1() abstract method");
	}
}
class SubChild1 extends Child1
{
	void m2()
	{
		System.out.println("m2() from subchild1");
	}
}
abstract class SubChild2 extends Parent5
{

}
class GrandChild1 extends SubChild2
{
	void m2()
	{
		System.out.println("m2() from grandchild");
	}
}
class Child2 extends Parent
{
	void m1()
	{
		System.out.println("m1() from Child2");
	}
	void m2()
	{
		System.out.println("m2() from Child2");
	}
}
abstract class Child3 extends Parent5
{

}
abstract class SubChild3 extends Child3
{

}
class GrandChild2 extends SubChild3
{
  void m1()
  {
  	System.out.println("m1() from GrandChild2");
  }
  void m2()
  {
  	System.out.println("m2() from GrandChild2");
  }
}

