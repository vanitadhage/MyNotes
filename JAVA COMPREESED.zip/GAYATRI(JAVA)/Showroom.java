class Showroom
{
 public static void main(String [] args)
  {
    Short noOfFourWheeler=5000;
    short noOfBikes=4500;
    short noOfCompany=500;
    short noOfLights=250;
    short noOfAc=200;
    System.out.println("No Of Four Wheeler :"+noOfFourWheeler);
    System.out.println("No Of Bikes :"+noOfBikes);
    System.out.println("No Of Company :"+noOfCompany);
    System.out.println("No Of Lights :"+noOfLights);
    System.out.println("No Of Ac :"+noOfAc);
  }
}