import java.util.Arrays;
class CloningArray
{
	public static void main(String[] args) 
	{
		char []charaters={'a','e','i','o','u'};
		char []dup=charaters.clone();
		System.out.println("Orignal Array :"+Arrays.toString(charaters));
		System.out.println("Dup arr :"+Arrays.toString(dup));
		charaters[0]='A';
		System.out.println("Orignal Array :"+Arrays.toString(charaters));
		System.out.println("Dup arr :"+Arrays.toString(dup));



		// char[][]charaters={{'a','e','i','o','u'},{'g','b','c','d'}};
		// char [][] dup=charaters.clone();
		// System.out.println("Orignal Array :"+Arrays.deepToString(charaters));
		// System.out.println("Dup arr :"+Arrays.deepToString(dup));
		// charaters[0][0]='A';
		// System.out.println("Orignal Array :"+Arrays.deepToString(charaters));
		// System.out.println("Dup arr :"+Arrays.deepToString(dup));






	}
}