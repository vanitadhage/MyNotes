import java.util.Scanner;
class PassFail
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter your marks :");
		double marks=sc.nextDouble();
		if (marks>=75) {
			System.out.println("Distinction");
		}
		else if (marks>=60) {
			System.out.println("First class ");
		}
		else if (marks>=50) {
			System.out.println("Second  class ");
		}
		else if (marks>35) {
			System.out.println("Passed ");
		}
		else if (marks==35) {
			System.out.println("just passed ");
		}
		else
		{
			System.out.println("you have failed the exam");
		}
	}
}