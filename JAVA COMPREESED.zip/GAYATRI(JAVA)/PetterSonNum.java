import java.util.Scanner;
class PetterSonNum
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
        int sum=0;
		for (int i=num;i>0 ;i/=10 ) {
              int fact=1;
              int lDigit=i%10;
			for (int j=1;j<=lDigit ;j++ ) {
				fact*=j;

			}
			sum+=fact;
		}
		if (sum==num) {
			System.out.println("Peterson Number");
		}
		else
		{
			System.out.println(" NOt Peterson Number");
		}	
	}
}










// class PetterSonNum
// {
// 	public static void main(String[] args) {
// 		int num=145;
// 		int sum=0;

// 		for (int i=num;i>0 ;i/=10 ) {
// 			int fact=1;
// 			int rem=i%10;
// 			for (int j=1;j<=rem ;i++ ) {
// 				fact*=j;
// 			}
// 			sum+=fact;
// 		}
// 		if (sum==num) {
// 			System.out.println("KrishnaMurti Num");
// 		}
// 		else
// 		{
// 			System.out.println(" Not KrishnaMurti Num");
// 		}
// 	}
// }
