class CombineDataType
{
 public static void main(String [] args)
  {
   byte noOfWaterTank=127;
   short building=150;
   short noOfFlats=5000;
   int noOfPeoples=46786;
   float waterTankDensity=151.06442f;
double noOfTrees=876646d;
   System.out.println("No Of Water Tank :"+noOfWaterTank);
   System.out.println("building :"+building);
   System.out.println("No Of Flats :"+noOfFlats);
   System.out.println("No Of Peoples :"+noOfPeoples);
   System.out.println("Water Tank Density :"+waterTankDensity);
   System.out.println("no Of Trees :"+noOfTrees);
  }
}