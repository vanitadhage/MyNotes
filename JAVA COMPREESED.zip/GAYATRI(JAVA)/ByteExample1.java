class ByteExample1
{
 public static void main(String [] args)
  {
   Byte a=0;
   Byte b=-128;
   Byte c=-129;
   Byte d=127;
   Byte e=128;
  }
}