class Ac
{
	int temp;
	String brand;
	int price;
	int voltage;
	int evaporator;
	 public void acInfo()
	 {
	 System.out.println("*****AirConditioner Info *****");																																																																				.out.println("Brand :"+brand);
	 System.out.println("Price :"+price);
	 System.out.println("Voltage :"+voltage);
	 System.out.println("Evaporator :"+evaporator);
	 System.out.println();
	 }
}
class AcDriver
{
	public static void main(String[] args) {
		Ac a=new Ac();

		a.temp=20;
		a.brand="blue star";
		a.price=30000;
		a.voltage=24;
		a.evaporator=40;
		a.acInfo();


	}
}