class ForLoop1
{
	public static void main(String[] args) {
		int i=1;
		for (;i<=10 ; ) {
			System.out.println("hello");
			i++;
		}
		System.out.println("byee");
	}
}