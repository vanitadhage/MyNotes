class MethodExampleFact
{ 
	 static int fact=1;
	public static void main(String[] args) {
		factorial(5);
	}
	public static void factorial(int num)
	{
       //Using recursion to find factorial
		if (num==0) {
			System.out.println(fact);
			return;
		}
		fact=fact*num;
		factorial(--num);

	}
}


        // for (int i=1;i<=num ;i++ ) {
		// 	fact=fact*i;
		// }
		// System.out.println(fact);