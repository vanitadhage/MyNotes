class Example8
{
	static{
		System.out.println("Static block 1");
	}
	public static void main(String[] args) {
		Example9 a=new Example9();
	}
	{
		System.out.println("Non-static block 1");
	}
}
class Example9
{
   static{
   	System.out.println("Byee");
   }
   {
   	System.out.println("Hello");
   }
}