class WhileFibonacci
{
	public static void main(String[] args) {
		int num1=0;
		int num2=1;
		int i=1;
		while(i<=10)
		{
			int op=num1+num2;
			System.out.print(op +" ");
			num1=num2;
			num2=op;
			i++;
			
		}
		
	}
}