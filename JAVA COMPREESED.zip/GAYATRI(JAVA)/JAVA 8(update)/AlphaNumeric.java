import java.util.function.*;
class AlphaNumeric
{
	public static boolean isPrime(int num)
	{
		boolean flag=true;
		for (int i=2;i<num;i++) {
			if (num%i==0) {
				flag=false;
				break;
			}
		}
		return falg;
	}
  public static void main(String[] args) {
  	List<Integer> arr=Arrays.asList(2,3,4,5,6,7,8);
  	arr.stream().filter(ele->AlphaNumeric.isPrime(ele).forEach(ele->System.out.println(ele)));
  }
}