enum WeekDays{
	SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY
}
class ExampleEnum
{
 enum Seasons
 {
 	WINTER,SUMMER,MONSOON
 }

 public static void main(String[] args) {
 	
 	for (WeekDays i :WeekDays.values() ) {
 		System.out.println(i);
 	}
 System.out.println("************************************************************************");
 	for (Seasons s:Seasons.values() ) {
 		System.out.println(s);
 	}
 }
}