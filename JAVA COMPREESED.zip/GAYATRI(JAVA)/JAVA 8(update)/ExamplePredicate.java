import java.util.function.*;
class ExamplePredicate
{
	public static void main(String[] args) {
		String str1="12345abc";
		// String str2="54566435";

		Predicate<String>  alphanumeric=str->str.matches("\\d");
		System.out.println("Str1 has alphanumeric char :"+alphanumeric.test(str1));
		// System.out.println("Str2 has alphanumeric char :"+alphanumeric.test(str2));

	}
}
