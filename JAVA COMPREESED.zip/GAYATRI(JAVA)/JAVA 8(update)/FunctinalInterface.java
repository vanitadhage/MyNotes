import java.util.function.*;
class FunctinalInterface
{
	public static void main(String[] args) {
		Function<Integer,String> evenOdd=(num)->{
			if (num%2==0) 
				return (num + "Even");
			else
				return (num +  "Odd");
			
		};
		System.out.println(evenOdd.apply(3));
	}
}