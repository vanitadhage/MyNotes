import java.util.function.*;
class ExampleFunction
{
	public static void main(String[] args) {
		
		Function<Integer,Integer> function=(num)->Integer.parseInt(new StringBuffer(num.toString()).reverse().toString());
		System.out.println(function.apply(1234));
	}
}