import java.util.function.*;
class MainPredicate
{
	public static void main(String[] args) {
		String str1="abcd123";
		 // String str2="abcd@123#";

		Predicate<String>  alphanumeric=str->str.matches("\\w+");
		System.out.println("Str1 has alphanumeric char :"+alphanumeric.test(str1));
		// System.out.println("Str2 has alphanumeric char :"+alphanumeric.test(str2));

	}
}