// class InnerClassExample
// {
// 	private static String name="gayatri";
// 	static class InnerClass{
// 		public static void myInnerClassMethod()
// 		{
// 			System.out.println("Hello from my inner class method");
// 			System.out.println(name);
// 		}
// 	}
// 	public static void main(String[] args) {
// 		System.out.println("Hello");
// 		InnerClassExample i=new InnerClassExample();
// 		InnerClassExample.InnerClass.myInnerClassMethod();
// 	}
// }

class InnerClassExample
{
	private static String name="gayatri";
	static class InnerClass{
		public  void myInnerClassMethod()
		{
			System.out.println("Hello from my inner class method");
			System.out.println(name);
		}
	}
	public static void main(String[] args) {
		System.out.println("Hello");
		// InnerClassExample i=new InnerClassExample();
		// InnerClassExample.InnerClass.myInnerClassMethod();
		InnerClass a=new InnerClass();
		a.myInnerClassMethod();
	}
}