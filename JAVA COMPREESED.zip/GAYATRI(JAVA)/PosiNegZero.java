import java.util.Scanner;
class PosiNegZero
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int a=sc.nextInt();
		String op=(a>0||a<0)?((a>0)?"Positive":"Negative"):"Zero";
		System.out.println("Entered number is :"+op);
	}
}