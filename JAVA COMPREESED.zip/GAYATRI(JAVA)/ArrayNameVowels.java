import java.util.*;
class ArrayNameVowels
{
	public static void main(String[] args) 
	{
	  Scanner sc=new Scanner(System.in);
	  System.out.print("Enetr a name :");
	  String name=sc.next();

	  char[]nameArray=new char[name.length()];

	  int indx=0;
	  for (int i=0;i<name.length();i++ ) 
	   {
	  		nameArray[indx++]=name.charAt(i);
	  	}	
	  	System.out.println("Name array :"+Arrays.toString(nameArray));

	  	int count=0;
	  	for (int i=0;i<nameArray.length ;i++ ) {
	  		if (nameArray[i]=='a'||nameArray[i]=='e'||nameArray[i]=='i'||nameArray[i]=='o'||nameArray[i]=='u') 
	  		{
	  			count++;
	  		}
	  	}
	  	int index2=0;
	  	char []vowelsArray=new char[count];
	  	for (int j=0;j<nameArray.length ;j++ ) 
	  	{
	  	  if (nameArray[j]=='a'||nameArray[j]=='e'||nameArray[j]=='i'||nameArray[j]=='o'||nameArray[j]=='u') 
	  	   {
	  	     vowelsArray[index2++]=nameArray[j];		
	  	  	}	
	  	}
	  	System.out.println("Vowels array :"+Arrays.toString(vowelsArray));
	}
}