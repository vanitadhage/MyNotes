import java.util.*;
class AlternateNumAdd
{

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int tNo=sc.nextInt();//12345
		int wno=9;
		int sum=0;
        while(tNo!=0)
        {
          int rem=tNo%10;
          sum+=rem;
          tNo/=100;
          // tNo/=10;

        }
        if (sum==wno) {
        	System.out.println("win");
        }
        else{
        	System.out.println("lost");
        }
	}
}










// for (int i=1;i<=tNo ;i++) {
//         	int rem=tNo%10;
//         	if (tNo!=0) {
//         		count++;
//         	tNo/=10;
//         	tNo/=10;
        	
//         	}
//         	sum+=rem;
        	
//         }