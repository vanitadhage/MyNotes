import java.util.*;   
class ArrayCreation2
{
	public static void main(String[] args) {
		// EX1 1st way
		// byte []a=new byte[2];
		// a[0]=10;
		// a[1]=20;
  //       System.out.println(Arrays.toString(a));

  //       EX1 2nd way
		// byte []a={100,127};
		// System.out.println(Arrays.toString(a));

		// // // EX2
		// 1st way
  //       short [][]b=new short[2][3];
		// b[0][0]=11;
		// b[0][1]=22;
		// b[0][2]=33;

		// b[1][0]=44;
		// b[1][1]=55;
		// b[1][2]=66;
		// System.out.println(Arrays.deepToString(b));
        
  //       2nd way
  //       short [][]b={{111,222,333},{444,555,666}};
		// System.out.println(Arrays.deepToString(b));

        

		// // EX3
		// 1st way 
         // int [][]c=new int[2][];
         // c[0]=new int[2];
         // c[1]=new int[3];
         
         // c[0][0]=10;
         // c[0][1]=20;

         // c[1][0]=30;
         // c[1][1]=40;
         // c[1][2]=50;
           
         //   2nd way
         // int [][]c={{10,20},{30,40,50}};
         // System.out.println(Arrays.deepToString(c));
         

		// // EX4
        // float[][][]d=new float[3][][];
        // d[0]=new float[1][3];
        // d[1]=new float[2][1];
        // d[2]=new float[1][2];
        //  d[0][0][0]=11;
        //  d[0][0][1]=12;
        //  d[0][0][2]=13;

        //  d[1][0][0]=14;
        //  d[1][1][0]=15;

        //  d[2][0][0]=16;
        //  d[2][0][1]=17;
         
         // float [][][]d={{{11,22,33}},{{44},{55}},{{66},{77}}};
         // System.out.println(Arrays.deepToString(d));
         
		// // EX5
        // long [][][]e=new long[3][1][3];
        
        // e[0][0][0]=91;
        // e[0][0][1]=92;
        // e[0][0][2]=93;

        // e[1][0][0]=94;
        // e[1][0][1]=95;
        // e[1][0][2]=96;

        // e[2][0][0]=97;
        // e[2][0][1]=98;
        // e[2][0][2]=99;

        // long [][][]e={{{100,200,300}},{{400,500,600}},{{700,800,900}}};
        // System.out.println(Arrays.deepToString(e));

       


		// // EX6
		// double [][][]f=new double[2][][];
		// f[0]=new double[2][];
		// f[0][0]=new double[1];
		// f[0][1]=new double[3];
		// f[1]=new double[3][1];
	

  //       f[0][0][0]=90;

  //       f[0][1][0]=80;
  //       f[0][1][1]=70;
  //       f[0][1][2]=60;
        

  //       f[1][0][0]=40;
  //       f[1][1][0]=30;
  //       f[1][2][0]=20;
		// double [][][] f={{{100},{200,300,400}},{{500},{600},{700}}};
		// System.out.println(Arrays.deepToString(f));
		

		// // EX7
		// long [][][]g=new long[2][][];
		// g[0]=new long[2][];
		// g[0][0]=new long[1];
		// g[0][1]=new long[3];
		// g[1]=new long [1][4];

		// g[0][0][0]=10;

		// g[0][1][0]=20;
		// g[0][1][1]=30;
		// g[0][1][2]=40;

		// g[1][0][0]=50;
		// g[1][0][1]=60;
		// g[1][0][2]=70;
		// g[1][0][3]=80;
        
        // long [][][]g={{{111},{222,333,444}},{{555,666,777,888}}};
		// System.out.println(Arrays.deepToString(g));



		// // EX8
		char [][][]h=new char[4][][];
		h[0]=new char[1][4];
		h[1]=new char[2][1];
		h[2]=new char[1][3];
		h[3]=new char[2][];
		h[3][0]=new char[1];
		h[3][1]=new char[2];

		h[0][0][0]='a';
		h[0][0][1]='b';
		h[0][0][2]='c';
		h[0][0][3]='d';

		h[1][0][0]='e';
		h[1][1][0]='f';

		h[2][0][0]='g';
		h[2][0][1]='h';
		h[2][0][2]='i';

		h[3][0][0]='j';
		h[3][1][0]='k';
		h[3][1][1]='l';

		// char [][][]h={{{'z','y','x','w'}},{{'q'},{'r'}},{{'s','t','u'}},{{'v'},{'o','p'}}};
		System.out.println(Arrays.deepToString(h));
        

		// // EX9

		String [][][]i=new String[3][][];
	    i[0]=new String[1][4];

	    i[1]=new String[2][1];
        i[2]=new String[3][];
	    i[2][0]=new String[1];
	    i[2][1]=new String[2];
	    i[2][2]=new String[3];
	    
	    i[0][0][0]="A";
	    i[0][0][1]="B";
	    i[0][0][2]="C";
	    i[0][0][3]="D";

	    i[1][0][0]="E";
	    i[1][1][0]="F";
        
        i[2][0][0]="G";

        i[2][1][0]="H";
        i[2][1][1]="I";

        i[2][2][0]="J";
        i[2][2][1]="K";
        i[2][2][2]="L";

		// String [][][] i={{{"a","b","c","d"}},{{"e"},{"f"}},{{"i"},{"j","k"},{"l","m","n"}}};
		
		System.out.println(Arrays.deepToString(i));

	}
}