import java.util.*;
class IBMAsseccment2
{
	public static void main(String[] args) {
		int []a={3,3,4,7,8};
		int d=5;
		int count=getTripletCount(a,d);
		System.out.println(count);
	}
	public static int getTripletCount(int []a,int d)
	{
		int l=a.length;
		int count=0;
		for (int i=0;i<l-2 ;i++ ) {
			for (int j=i+1;j<l-1 ;j++ ) {
				for (int k=j+1;k<l ;k++ ) {
					int sum=a[i]+a[j]+a[k];
					if (sum%d==0) {
						count++;
					}
				}
			}
		}
		return count;
	}
}