import java.util.*;
class ArrayFreqCount
{
	public static void main(String[] args) {
		int []arr={1,2,5,7,9,8,7,5,3,1,2,4,5,6,7,9};
         
        int []arr1=new int[arr.length];
        int cnt=-1;
        for (int i=0;i<arr.length ;i++ ) 
        {
          int count=1;
          for (int j=i+1;j<arr.length ;j++ ) 
          {
            if (arr[i]==arr[j]) 
            {
              count++;
              arr1[j]=cnt;
            }		
          }	
          if (arr1[i]!=cnt) 
          {
             arr1[i]=count;	
          }

        }
        for (int i=0;i<arr1.length ;i++ ) 
          {
          	if (arr1[i]!=cnt) 
          	{
          		System.out.println("Number :  "  + arr[i] + "-"+arr1[i]);
          	}
          }
	}
}