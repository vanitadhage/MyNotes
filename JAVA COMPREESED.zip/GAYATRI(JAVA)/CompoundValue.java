import java.util.Scanner;
class CompoundValue
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		final double monthlyIntrestRate=(1+(0.05/12));

		System.out.print("Enter the monthly saving amount :");
		double amount=sc.nextDouble();

        double firstMonth=(amount*monthlyIntrestRate);
        double secondMonth=((amount+firstMonth)*monthlyIntrestRate);
        double thirdMonth=((amount+secondMonth)*monthlyIntrestRate);
        double fourthMonth=((amount+thirdMonth)*monthlyIntrestRate);
        double fifthMonth=((amount+fourthMonth)*monthlyIntrestRate);
        double sixthMonth=((amount+fifthMonth)*monthlyIntrestRate);
        System.out.println("After the sixth month, the account value is :"+sixthMonth);
	}
}