import java.util.Scanner;
class FeetIntoMeters
{
  public static void main(String[] args) 
    {
  		Scanner sc=new Scanner(System.in);
  		final double oneFootInMeter=0.305;

  		System.out.print("Enter a value for feet :");
  		double feet=sc.nextDouble();

  		double meters=feet*oneFootInMeter;
  		System.out.println(feet +"feet is :"+meters+"meters");
  	}	
}