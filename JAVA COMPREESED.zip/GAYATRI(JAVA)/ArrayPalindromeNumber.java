class ArrayPalindromeNumber
{
	public static void main(String[] args) {
		int [] numbers={123,121,876,474,555,678,919,435};
		for (int number :numbers ) 
		{
			if (isPalindrome(number)) 
			{
				System.out.print(number+" ");
			}
		}
	}	
	public static boolean isPalindrome(int number)
	{
		int rev=0;
		for (int i=number;i!=0 ;i/=10 ) {
			int rem=i%10;
			rev=rev*10+rem;
			
		}
		if (rev==number) {
			return true;
		}
		else
		{
			return false;
		}
	}
}