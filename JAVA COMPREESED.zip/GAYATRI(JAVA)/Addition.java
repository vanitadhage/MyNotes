class Addition
{ 
  public static void main(String [] args)
   {
     System.out.print("Addition of two number is :");
     System.out.print(5+5);
   }
}