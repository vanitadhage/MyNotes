class Bike
{
	public void vehicleTypes()
	{
		System.out.println("Bike");
	}
}
class Ismart extends Bike
{
	public void brand()
	{
		System.out.println("Brand :iSmart");
	}
	String a="abc";
}
class BikeDriver
{
	public static void main(String[] args) {
		Ismart a=new Ismart();
		a.vehicleTypes();
		a.brand();
		System.out.println(a.a);
	}
}