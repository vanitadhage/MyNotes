//write a program to find min numbr among 3 
// class MinNumber
// {
// 	public static void main(String[] args) {
// 		int a=4;
// 		int b=5;
// 		int c=8;
		// int op=(a<b)?(a<c?a:c):(b<c?b:c);
// 		System.out.println("The minimum no in 3digit is :"+op);

// 	}
// }

import java.util.Scanner;
class MinNumber
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a num1 :");
		int a=sc.nextInt();
		System.out.print("Enter a num2 :");
		int b=sc.nextInt();
		System.out.print("Enter a num3 :");
		int c=sc.nextInt();
		int  op=(a<b)?(a<c?a:c):(b<c?b:c);
		System.out.println(op);
	}
}