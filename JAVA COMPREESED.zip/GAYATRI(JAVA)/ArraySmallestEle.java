class ArraySmallestEle
{
	public static void main(String[] args) {
		int []arr={10,65,98,19,5,77};

		int min=arr[0];
		for (int i=0;i<arr.length;i++) {
			if (min>arr[i]) {
				min=arr[i];
			}
		}
		System.out.println(min);
	}
}