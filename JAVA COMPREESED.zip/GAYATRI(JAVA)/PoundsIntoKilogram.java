import java.util.Scanner;
class PoundsIntoKilogram
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		final double onePoundInKg=0.454;

		System.out.print("Enter a number in pound :");
		double pound=sc.nextDouble();

		double kilograms=pound*onePoundInKg;
		System.out.println("coverts pound in kilograms :"+kilograms);
	}
}