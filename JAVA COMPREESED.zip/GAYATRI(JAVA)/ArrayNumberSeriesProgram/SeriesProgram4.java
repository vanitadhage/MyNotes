import java.util.*;
class SeriesProgram4
{
	public static void main(String[] args) 
	{
		int []series=new int[10];
		int num1=4;
		series[0]=num1;

		int value=3;
		for (int i=1;i<series.length ;i++ ) 
		{
		  if(series[i-1]%2==0)
		  {
		  	int nextNum=series[i-1]+(value*value);
		  	series[i]=nextNum;
		  	value+=2;
		  }	
		  else
		  {
		  	int nextNum=series[i-1]-(value*value);
		  	series[i]=nextNum;
		  	value+=2;
		  }
		}
		System.out.println(Arrays.toString(series));
	}
}