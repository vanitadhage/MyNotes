import java.util.*;
class SeriesProgram3
{
	public static void main(String[] args) 
	{
		int[]numbers=new int[10];
		int num=11;
		numbers[0]=num;
		int k=1;
		for (int i=1;i<numbers.length ;i++ ) {
			int power=1;
			for ( int j=k ;j<=0 ;j-- ) {
				power*=i;
				if (i%2!=0) {
					num+1;
				}
				else{
					
				}
			}
            int newNum=numbers[i-1]+(power+i);
            numbers[i]=newNum;
            k++;
		}
		System.out.print(Arrays.toString(numbers));
	}
}