class India
{
 public static void main(String [] args)
  { 
    byte noOfStates=29;
    byte unionTerroteries=8;
    byte cabinetMinister=45;
    byte noOfOcean=5;
    byte noOfContients=7;
    System.out.println("No Of States :"+noOfStates);
    System.out.println("Union Terroteries :"+unionTerroteries);
    System.out.println("Cabinet Minister :"+cabinetMinister);
    System.out.println("No Of Ocean  :"+noOfOcean);
    System.out.println("No Of Contients :"+noOfContients);
  }
}