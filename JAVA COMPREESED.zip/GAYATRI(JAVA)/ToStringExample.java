class Student
{
	String name;
	String ntvplace;
	long phoneNumber;
	String branch;

	Student(String name,String ntvplace,long phoneNumber,String branch)
	{
      this.name=name;
      this.ntvplace=ntvplace;
      this.phoneNumber=phoneNumber;
      this.branch=branch;
	}
	public boolean equals(Object obj)
	{
		Student s1=(Student)obj;
		if((this.name==s1.name)&&(this.ntvplace==s1.ntvplace)&&(this.phoneNumber==s1.phoneNumber)&&(this.branch==s1.branch))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}


class ToStringExample
{
	public static void main(String[] args) 
	{
		Student obj1=new Student("gayatri","Pune",9878675645l,"Civil");
		Student obj2=new Student("gayatri","Pune",9878675645l,"Civil");
		System.out.println(obj1.equals(obj2));//True
		// System.out.println(obj1==obj2);//False (beacuse it will compaire reference of the method)

		// Student obj1=new Student("gayatri","Pune",9878675645l,"Civil");
		// Student obj2=new Student("Gayatri","Pune",9878675645l,"Civil");
		// System.out.println(obj1.equals(obj2));//False

	}
}