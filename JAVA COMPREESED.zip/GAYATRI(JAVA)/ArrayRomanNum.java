import java.util.*;
class ArrayRomanNum
{
	public static void main(String[] args) 
	{
		int[]numbers={11,222,334,412,565,666,777,890,991,1000};
        
        System.out.println(Arrays.toString(numbers));
        System.out.println(Arrays.toString(intToRoman(numbers)));   
	}
	public static String [] intToRoman(int []numbers)
	{
		String []romanNumbers=new String[numbers.length];
		int indx=0;
		
		String []thousands={"","M"};
		String []hundreds={"","C","CC","CCC","CD","D","DC","DCC","DCCC","CM"};
		String []tens={"","X","XX","XXX","XL","L","LX","LXX","LXXX","XC"};
		String []units={"","I","II","III","IV","V","VI","VII","VIII","IX"};

		for(int number :numbers){
         String roman=" ";
         roman=thousands[(number%10000)/1000]+hundreds[(number%1000)/100]+tens[(number%100)/10]+units[number%10];
         romanNumbers[indx++]=roman;
		}
		return romanNumbers;
	}

}