import java.util.Scanner;
class VowelsConsonent2
{
	public static void main(String[] args) 
	{
	Scanner sc=new Scanner(System.in);
	System.out.print( "Enter a Charater :");
	char vowels=sc.next().charAt(0);
	if (vowels=='a') { 
		System.out.println("It is vowels");
	}
	else if (vowels=='e') {
		System.out.println("It is vowels");
	}
	else if (vowels=='i') {
		System.out.println("It is vowels");
	}
	else if (vowels=='o') {
		System.out.println("It is vowels");
	}
	else if (vowels=='u') {
		System.out.println("It is vowels");
	}
	else
	{
		System.out.println("It is a consenent");
	}
    }
}