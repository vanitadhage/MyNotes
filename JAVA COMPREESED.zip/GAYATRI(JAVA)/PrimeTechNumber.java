import java.util.Scanner;
class PrimeTechNumber
{
	public static void main(String[] args) 
      {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
            int dup=num;
	      int count=0;

		for ( ; dup!=0;dup/=10){
			count++;
            }
            if(count%2==0) {
                 int op=0;
                 for (int i=1;i<count/2 ;i++ ) {
                  int div=10;
            	div*=10;
            	int a=num%div;
            	int b=num/div;
            	int c=a+b;
                  op=c*c;
              }
            if (op==num) {
                   System.out.println("It is Tech Number");
            }
            else{
                   System.out.println("It is not Tech Number");
                }
            }
            else
            {
                 System.out.print("It is not tech number");
            }
      }
}