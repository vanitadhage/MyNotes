class ArrayBuzzNumber
{
	public static void main(String[] args) 
	{
		int []arr={213,567,876,21,56,9,312,767};
		for (int num :arr ) {
			if (isBuzz(num)) {
				System.out.print(num+" ");
			}
		}
	}
	public static boolean isBuzz(int num)
	{
		int rem=num%10;
		if (num%7==0||rem==7) {
			return true;
		}
		else{
			return false;
		}
	}
}