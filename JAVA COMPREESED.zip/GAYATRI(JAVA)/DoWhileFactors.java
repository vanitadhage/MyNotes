import java.util.Scanner;
class DoWhileFactors
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		System.out.print("Ente a number :");
		int num=sc.nextInt();
		int i=1;
		int fact=1;
		do
		{
			if (num%i==0) {
				System.out.print(i+" ");
			}
			i++;
		}while(i<=num);

	}
}