import java.util.*;
import java.util.Map.Entry;
class MapInterfaceExample
{
  public static void main(String[] args) {
  	Map<Integer,String> map=new HashMap<>();
  	map.put(3,"Ramesh");
  	map.put(1,"Ganesh");
  	map.put(0,"Suresh");
  	// System.out.println(map);
  	// System.out.println(map.entrySet());

  	for (Entry<Integer,String> set:map.entrySet() ) {
  		System.out.println(set);
  	}
  }
}