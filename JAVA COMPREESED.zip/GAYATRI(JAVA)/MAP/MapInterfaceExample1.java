import java.util.*;
class MapInterfaceExample
{
	public static void main(String[] args) {
		Map<Integer,String> a=new HashMap<>();
		a.put(1,"Ramesh");
		a.put(2,"Suresh");
		a.put(3,"Ganesh");
		a.put(4,"Suresh");
		a.put(5,"Ramesh");
		a.put(6,"Mahesh");
		a.put(7,"Ramesh");

		// int count=0;
		// int ct=0;		
		// String s=null;
		for(Entry<Integer,String> set:map.entrySet() ) {
  		System.out.println(a);
			// String val=a.getValue();
			// val2=val;
			// if (val2.equals(val)) {
			// 	count++;
			// }
			// ct=count;
			// if (ct>count) {
			// 	s=val2;
			// }
  	   }
  	   // System.out.println(set);
	}
}