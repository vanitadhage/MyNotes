// class Example21
// {
// 	public static void main(String[] args) 
// 	{
// 		int num=9;
// 		int dup=num;
// 		int sqrnum=num*num;
// 		int rem=1;
// 		int count=0;

//         while(dup>0)
//         {
//            count++;
//            dup/=10;

//         }
// 		for (int i=1;i<=count;i++ ) 
// 		{
// 		   	rem*=10;
// 		}  
// 		if (num==(sqrnum%rem)) 
// 		   {
// 		     System.out.println("Automorphic");   		
// 		   }       
// 		   else{
// 		   	System.out.println("Not Automorphic");
// 		   }                                   
// 	}
// }






/*class Example21
{
	public static void main(String[] args) 
	{
		int num=62;
		int num1=num+1;
		int sqrt=0;
        for (int i=1;i<=num ;i++ ) {
        	if(i*i==num1)
        	{
        		sqrt=i;
        		break;
        	}
        }
        if (sqrt>0) {
        	System.out.print("sunny");
        }
        else{
        	System.out.print("Not sunny");
        }
	}
}*/





         