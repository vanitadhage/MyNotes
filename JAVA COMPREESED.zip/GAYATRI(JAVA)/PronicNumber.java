import java.util.Scanner;
class PronicNumber
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		int num1=0;
		int num2=0;

		for (int i=1;i<=num ;i++ ) {
			if (num==i*(i+1)) {
				num1=i;
				num2=i+1;
			}
		}
		System.out.println(num==(num1*num2)?"Pronic Number":"Not Pronic number");
	}
}