import java.util.Scanner;
class AdditionOfDigit
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt(); //182
		int op=0; //2
		int rem=num%10;
	    op=rem;
	    num=num/10;//182/10->18
	    rem=num%10;//18%10->8
	    op=op+rem;//8+2
	    num=num/10;
	    op=op+num;
	    System.out.println("sum of digit :"+op);

	}
}