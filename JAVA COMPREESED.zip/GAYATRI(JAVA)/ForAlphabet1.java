class ForAlphabet1
{
	public static void main(String[] args) 
	{
		for (char i='a';i<='z' ;++i ) 
		{
			System.out.print(i +"  ");
		}
	}
}