class ArmstrongNo1
{
	public static void main(String[] args)
	{
	  int num=153;
	  int dup=num;
	  int dup1=num;
	  int count=0;
	  int sum=0;

	  while(dup>0)
	  {
	    count++;
	    dup/=10;
	  }

	  while(dup1>0)
	  {
	    int rem=dup1%10;
	    int pow=1;

	    for(int i=1;i<=count;i++)
	    {
	       pow*=rem;
	    }
	    sum+=pow;
	    dup1/=10;
	  }
	  System.out.println(sum==num?"Armstrong":"Not a Armstrong");
	}
}