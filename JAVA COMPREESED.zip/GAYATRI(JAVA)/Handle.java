class Handle
{
	String material;
	String shape;
	Handle(String material,String shape)
	{
		this.material=material;
		this.shape=shape;
	}
	void displayHandle()
	{
		System.out.println("Details Handle");
        System.out.println("material :"+this.material);
        System.out.println("Shape :"+this.shape);
	}
}