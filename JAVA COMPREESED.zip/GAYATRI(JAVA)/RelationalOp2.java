class RelationalOp2
{
	public static void main(String[] args) {
		int a=2;
		int b=3;
		int c=4;
                          //2  + 5   + 4  +  4   +4+4+5==28
		System.out.println(a++ + ++c + ++b + b++ +a+b+c);
                         //2 + 4   + 2   +3=11
	    System.out.println(a + ++b + a++ +a);
                        // 3   +3  +4   +3   +4=17
	    System.out.println(++a + a + ++b + a + b);
                          //2  + 4   +3   +5    + 4 + 5=23
	    System.out.println(a++ + ++a + b++ + ++b + a + b );
	}
}