// class ArrayHighestEle
// {
// 	public static void main(String[] args) {
// 		int []arr={122,543,712,123,432,1000};

// 		int max=0;
// 		for (int i=0;i<arr.length;i++) {
// 			if (max<arr[i]) {
// 				max=arr[i];
// 			}
// 		}
// 		System.out.println(max);
// 	}
// }










