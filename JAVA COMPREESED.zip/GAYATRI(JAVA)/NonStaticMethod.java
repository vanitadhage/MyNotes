class NonStaticMethod
{
	public static void main(String[] args) {
		 NonStaticMethod a=new NonStaticMethod();
		 a.m1();
		 a.m1(10);
	}
	public void m1()
	{
		System.out.println("No argu");
	}
	public void m1(int a)
	{
		System.out.println("1 argu");
	}

}