import java.util.Arrays;
class AarryAlternateEle
{
	public static void main(String[] args) 
	{ 
	  int []arr1={1,2,3,4,5};
	  int []arr2={6,7,8,9,10};
	  int []newArr=new int[(arr1.length)+(arr2.length)];
	   alternateEle(arr1,arr2,newArr);

	   System.out.println(Arrays.toString(newArr));

	}
	public static void alternateEle(int arr1[],int arr2[],int newArr[])
	{
	   int i=0;
	   int j=0;
	   int indx=0;
	   while(i<arr1.length && j<arr2.length)
	   {
	   	newArr[indx++]=arr1[i++];
	   	newArr[indx++]=arr2[j++];
	   }
	   while(i<arr1.length)
	   {
	   	newArr[indx++]=arr1[i++];

	   }
	   while(j<arr2.length)
	   {
	   	newArr[indx++]=arr2[j++];
	   }

	   
	}
}