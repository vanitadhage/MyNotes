class Example5
{
	public static void main(String[] args) {
		Example6 a=new Example6();
		a.m1();
		a.m2();
	}
}