class Example9
{
	public static void main(String[] args) {
		System.out.println(Example10.a);
	}
}
class Example10 
{
	static String a=m1();
	static{
		System.out.println("Byee");
	}
	public static String m1()
	{
		return "Ramesh";
	}
}