class ChildConst
{
	String name="child";
	public static void main(String[] args) {
		ChildConst a=new ChildConst();
		System.out.println(a);
		System.out.println(this.name);
		a.m1();
	}
	void m1()
	{
		String name="hELLO";
	}
}