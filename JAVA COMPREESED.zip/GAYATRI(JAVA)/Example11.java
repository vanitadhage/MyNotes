class Example11
{
	static
	{
		System.out.println(a);
		a="Ramesh";
		System.out.println(a);
	}
	static String a="SURESH";

	public static void main(String[] args) {
		System.out.println(a);
	}
}