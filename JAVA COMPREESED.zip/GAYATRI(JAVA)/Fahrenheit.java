import java.util.Scanner;
class Fahrenheit
{
	public static void main(String [] args) 
	{
	  Scanner sc=new Scanner(System.in);
	  System.out.print("Enter a celsius :");
	  double celsius=sc.nextDouble();
	  double Result=celsius*9/5+32;
      System.out.println("Covert celsius to Fahrenheit :"+Result);
	}
}