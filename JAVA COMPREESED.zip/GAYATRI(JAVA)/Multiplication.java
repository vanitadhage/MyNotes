class Multiplication
{
  public static void main(String [] args)
   { 
     System.out.print("Multiplication of two number is :");
     System.out.print(5*5);
   }
}