class ShortExample1
{
 public static void main(String [] args)
  {
   short a=0;
   short b=-32768;
   short c=-32769;
   short d=32768;
   short e=32767;
  }
}