//logic:-  sum of digit & Product of digit will be same 
//Ex.int num=22,2+2=4 & 2*2=4 it is spy number.

import java.util.Scanner;
class SpyNumber
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
        int sum=0;
        int prod=1;
		while(num>0)
		{
          int rem=num%10;
          sum+=rem;
          prod*=rem;
          num/=10;
		}
		if(sum==prod)
		{
			System.out.println("Spy number");
		}
		else
		{
			System.out.println("Not Spy number ");
		}
	}
}