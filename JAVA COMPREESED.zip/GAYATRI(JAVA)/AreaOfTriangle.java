import java.util.Scanner;
class AreaOfTriangle
{
	public static void main(String[] args) 
	{
	  Scanner sc=new Scanner(System.in);
	  System.out.print("Enter a base :");
	  double base=sc.nextDouble();
	  System.out.print("Enter a height :");
	  double height=sc.nextDouble();
	  double area =base*height/2;
	  System.out.println("Area of triangle :"+area);	
	}
}