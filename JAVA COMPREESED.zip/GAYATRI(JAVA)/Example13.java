// class Example13
// {
// 	static
// 	{
//        System.out.println("Hello");
//        int op=m1(10,20);
//        System.out.println("Addition of 2 numbers is :"+op);
//        System.exit(0);
// 	}
// 	public static int m1(int a,int b)
// 	{
// 		return a+b;
// 	}
// }


class Example13
{
	static
	{
       System.out.println("Hello");
       int op=m1(10,20);
       System.out.println("Addition of 2 numbers is :"+op);
       // System.exit(0);
	}
	public static int m1(int a,int b)
	{
		return a+b;
	}
}