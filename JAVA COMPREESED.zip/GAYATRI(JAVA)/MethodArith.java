class MethodArith
{
	public static void main(String[] args) {
		System.out.println(add(20,10));
		System.out.println(sub(20,10));
		System.out.println(div(7,2));
	}
	public static int add(int a,int b)
	{
		int c =a+b;
		return c;
	}
	public static int sub(int a,int b)
	{
		int c =a-b;
		return c;
	}
	public static double div(int a,double b)
	{
		double c =a/b;
		return c;
	}
}