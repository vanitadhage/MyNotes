import java.util.Scanner;
class DuckNum
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		String a=sc.next();
		if (a.charAt(0)=='0') {
			System.out.println("Not Duck Number");
			System.exit(0);
		}
		else
		{                         
			boolean b=false;

			for (int i=0;i<a.length() ;i++ ) {
				if (a.charAt(i)=='0') {
					b=true;
				    break;
				}
			}
			if (b) 
		    {
			System.out.print("It is a Duck number"); 
		    }
		    else
		    {
			System.out.print("It is not a Duck number"); 
		    }
		}
	}
}


// for (int i=1;i<=num ;i++ ) {
// 			int rem=num%10; 
// 			 if (rem==0) {
// 			 	count++;
// 			   	num/=10;
// 			   }  
// 		    // num/=10; //50

// 		}