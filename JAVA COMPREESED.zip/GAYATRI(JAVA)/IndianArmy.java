class IndianArmy
{
 public static void main(String [] args)
 {
  int strength=1237117;
  int weapons=2500000;
  int missiles=40000;
  int reservedTrops=96000;
  int ak47=1400000;
  System.out.println("strength :"+strength);
  System.out.println("weapons :"+weapons);
  System.out.println("missiles :"+missiles);
  System.out.println("reserved Trops :"+reservedTrops);
  System.out.println("ak47 :"+ak47);
 }
}