import java.util.Scanner;
class BuzzNum
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();

		int rem=num%10;
		
		if (num%7==0||rem==7) {
			System.out.print("It is Buzz number");
		}
		else{
			System.out.println("Not a Buzz number");
		}
	}
}