import java.util.*;
class IBMAssessment3
{
	public static void main(String[] args) {
		
	}
}