class CompoundAssignEx
{
	public static void main(String[] args) {
		int a=10;
		System.out.println(a);
		a+=1;
		System.out.println(a);
		a-=2;
		System.out.println(a);
		a*=2;
		System.out.println(a);
		a/=4;
		System.out.println(a);
		a%=2;

		System.out.println(a);
	}
}