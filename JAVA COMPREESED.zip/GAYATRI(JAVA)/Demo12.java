class Demo12
{
	public static void main(String[] args) {
		int a=10;
		if (a==10) {
			System.out.println("10");
		}
	}
}