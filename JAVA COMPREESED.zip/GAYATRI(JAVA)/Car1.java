class Car1
{
  String brand;
  String model;

  Car1(String brand,String model)
  {
  	this.brand=brand;
  	this.model=model;
  }	
  void createDriver(String name,int age,String gender)
  {
  	Driver a=new Driver(name,age,gender);
  }
  public void displayDriver()
  {
  	System.out.println("brand :"+this.brand);
  	System.out.println("Model :"+this.model);
  }

}