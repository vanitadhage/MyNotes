import java.util.Scanner;
class PersonalInfo
{
  public static void main(String [] args)
  {
    Scanner sc=new Scanner(System.in);
    String name=sc.next();
    String nvt=sc.next();
    short yop=sc.nextShort();
    float cgpa=sc.nextFloat();
    String branch=sc.next();
    String university=sc.nextLine();
    System.out.println("Enter your name :"+name);
    System.out.println("Enter Navtive:"+nvt);
    System.out.println("Year of passout :"+yop);
    System.out.println("Enter your cgpa :"+cgpa);
    System.out.println("Enter your branch :"+branch);
    System.out.println("Enter your university :"+university);
  }
}