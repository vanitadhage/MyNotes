class Frame
{
	String type;
	double price;
	String color;
	double height;
	double width;
	

	public void frameInfo()
	{
		System.out.println("*****Frame Info*****");
		System.out.println("Type :"+type);
		System.out.println("Price :"+price);
		System.out.println("Color :"+color);
		System.out.println("height  :"+height+"cm");
		System.out.println("Width :"+width+"cm");
		System.out.println();
	}
}
class FrameDriver
{
	public static void main(String[] args) 
	{
		Frame a=new Frame();
		
		a.type="PhotoFrame";
		a.price=400;
		a.color="Grey";
		a.height=100;
		a.width=100;
		a.frameInfo();
	}
}