class Human_disease
{
 public static void main(String [] args)
  {
   int noOfDisease=100000;
   int dieFromMaleriaEachYear=619000;
   int cancerCases=18000000;
   int heartDisease=20000000;
   System.out.println("no of disease:"+noOfDisease);
   System.out.println("Die From Maleria Each Year:"+dieFromMaleriaEachYear);
   System.out.println("no of cancer Cases:"+cancerCases);
   System.out.println("no of heart Disease:"+heartDisease); 
  }
}
