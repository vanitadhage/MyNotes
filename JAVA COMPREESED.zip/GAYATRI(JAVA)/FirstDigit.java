import java.util.Scanner;
class FirstDigit
{
	public static void main(String[] args)
   {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num1=sc.nextInt();
		int num2=num1/100;
		System.out.print("first digit of number :"+num2);
	}
}