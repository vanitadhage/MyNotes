// class Pattern1
// {
// 	public static void main(String[] args) {
// 		for (int i=1;i<=5 ;i++ ) {
// 			for (int j=1;j<=5 ;j++ ) {
// 				System.out.print("*  ");
// 			}
// 			System.out.println();
// 		}
// 	}
// }


// class Pattern1
// {
// 	public static void main(String[] args) {
// 		for (int i=5;i>=1 ;i-- ) {
// 			for (int j=5;j>=1 ;j-- ) {
// 				System.out.print("*  ");
// 			}
// 			System.out.println();
// 		}
// 	}
// }

// class Pattern1
// {
// 	public static void main(String[] args) {
// 		for (int i=1;i<=5 ;i++ ) {
// 			for (int j=5;j>=1 ;j-- ) {
// 				System.out.print("*  ");
// 			}
// 			System.out.println();
// 		}
// 	}
// }


// class Pattern1
// {
// 	public static void main(String[] args) {
// 		for (int i=5;i>=1 ;i-- ) {
// 			for (int j=1;j<=5 ;j++ ) {
// 				System.out.print("*  ");
// 			}
// 			System.out.println();
// 		}
// 	}
// }



class Pattern1
{
	public static void main(String[] args) 
	{
		int i,j,row=5;
		for(i=1; i<=row; i++)   
        {   
            for(j=1; j<=row; j++)   
           {   
             System.out.print("*  ");   
           }   
           System.out.println(); 
        }  
	}
}


// class Pattern1
// {
// 	public static void main(String[] args) 
// 	{
// 		int i,j,row=1;
// 		for(i=5; i>=row; i--)   
//         {   
//             for(j=5; j>=row; j--)   
//            {   
//              System.out.print("*  ");   
//            }   
//            System.out.println(); 
//         }  
// 	}
// }


// op
// * * * * *
// * * * * *
// * * * * *
// * * * * *
// * * * * * 