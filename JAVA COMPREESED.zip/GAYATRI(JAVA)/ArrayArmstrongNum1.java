class ArrayArmstrongNum1
{
	public static void main(String[] args) {
		isArmstrong(new int[]{153,234,370,675,407});
	}
	public static void isArmstrong(int[] numbers)
	{
		for (int num :numbers ) 
		{
			int temp=num;
		   int temp1=num;
          int count=0;    
          int sum=0;
      while (temp>0) {
      	count++;
      	temp/=10;
      }
      while(temp1>0)
      {
      	int rem=temp1%10;
      	int pow=1;
      	for (int i=1;i<=count ;i++ ) {
      		pow*=rem;
      	}
      	sum+=pow;
      	temp1/=10;
      }
      if (num==sum) {
      	System.out.println(num);
      }
		}
	}
}