import java.util.*;
class IBMAssessment1
{
	public static void main(String[] args) {
		String []triangles={"2 2 1","3 3 3","3 4 5","1 1 3"};
		String []results=checkTriangles(triangles);
		System.out.println(Arrays.toString(results));
	}
	public static String []checkTriangles(String [] triangles)
	{
		String [] result=new String [triangles.length];
		int indx=0;

		for (String dim:triangles ) {
			String [] sides=dim.split(" ");
			int []dim1=new int[sides.length];
			for (int i=0;i<sides.length ;i++ ) {
				dim1[i]=Integer.parseInt(sides[i]);
			}
			Arrays.sort(dim1);
			if ((dim1[0]+dim1[1])>dim1[2]) {
				if (dim1[0]==dim1[1]&&dim1[1]==dim1[2]) {
					result[indx++]="Eqilateral";
				}
				else if (dim1[0]==dim1[1]||dim1[1]==dim1[2]) {
					result[indx++]="IsoScales";
				}
				else{
					result[indx++]="Non of These";
				}
			}
			else{
				result[indx++]="Non of These";
			}
			
		}
		return result;
	}
}