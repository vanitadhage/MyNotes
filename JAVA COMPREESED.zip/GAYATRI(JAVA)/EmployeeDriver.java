class Employee
{
	public void salary()
	{
		System.out.println("Salaray:20000");
	
	}
}
class Programmer extends Employee
{
	public void bonus()
	{
		System.out.println("Bonus:5000");
	}
}
class EmployeeDriver
{
	public static void main(String[] args) {
		Programmer obj=new Programmer();
		obj.salary();
		obj.bonus();
	}
}