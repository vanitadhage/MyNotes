class College
{
 public static void main(String [] args)
  { 
   short staff=250;
   short noOfBenches=2000;
   short student=4500;
   short window=450;
   System.out.println("staff member :"+staff);
   System.out.println("No Of Benches :"+noOfBenches);
   System.out.println("student :"+student);
   System.out.println("window:"+window);
  }
}
 