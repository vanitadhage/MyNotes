import java.util.Scanner;
class CostOfDriving
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the driving distance :");
		double distance=sc.nextDouble();
		System.out.print("Enter the miles per gallon :");
		double miles=sc.nextDouble();
		System.out.print("Enter the price per gallon :");
		double price=sc.nextDouble();

		double costOfDriving=(distance/miles)*price;
		System.out.println("The cost of driving is :"+costOfDriving);

	}
}