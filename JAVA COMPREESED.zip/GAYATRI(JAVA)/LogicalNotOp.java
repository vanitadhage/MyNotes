class LogicalNotOp
{
	public static void main(String[] args) {
		System.out.println(!true);
		System.out.println(!false);
		System.out.println(!(!false));
		
	}
}