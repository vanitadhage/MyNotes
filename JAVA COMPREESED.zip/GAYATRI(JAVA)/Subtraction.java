class Subtraction
{ 
  public static void main(String [] args)
   {
     System.out.print("Subtraction of two number is :");
     System.out.print(5-2);
   }
}