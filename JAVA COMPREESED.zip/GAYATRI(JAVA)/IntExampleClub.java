class IntExampleClub
{
 public static void main(String [] args)
  {
    int noOfPeoples=2147542;
    int noOfchairs=22337676;
    int noOfGirls=1466535;
    int noOfBoys=12734327;
    int typesOfWines=12345;
    System.out.println("No Of Peoples :"+noOfPeoples);
    System.out.println("No Of chairs :"+noOfchairs);
    System.out.println("No Of Girls :"+noOfGirls);
    System.out.println("No Of Boys :"+noOfBoys);
    System.out.println("Types of Wines :"+typesOfWines);
  }
}