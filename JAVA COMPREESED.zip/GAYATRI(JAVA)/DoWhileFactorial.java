import java.util.Scanner;
class DoWhileFactorial
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		int i=1;
		int fact=1;
		do
		{
			fact*=i;
			i++;
		}while(i<=num);
		System.out.print(fact);
	}
}