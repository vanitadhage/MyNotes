class Division
{
  public static void main(String [] args)
   {
    System.out.print("Division of two number is:");
    System.out.print(10/2);
   }
}