import java.util.Scanner;
class ConversionOfCurrency
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int ch=sc.nextInt();

		switch(ch)
		{
			case 1:{
				     System.out.println("Covert INR into DOLLAR");
				     System.out.println("Enter INR :");
				     double inr=sc.nextDouble();
				     double dollar1=(inr/85);
				     System.out.print(dollar1+"$");
				     break;
			       }

			case 2:{
                     System.out.println("Convert DOLLAR into INR");
                     System.out.println("Enter DOLLAR :");
                     double dollar=sc.nextDouble();
                     double rupees=(dollar*85);
                     System.out.print(rupees);
                     break;
			       }
            
            case 3:{
                     System.out.println("Convert INR into YEN");
                     System.out.println("Enter INR :");
                     double inr1=sc.nextDouble();
                     double yen=(inr1*1.8067);
                     System.out.print(yen);
                     break;
                   }
            
            case 4:{
                    System.out.println("Covert INR int WON");
                    System.out.println("Enter INR:");
                    double inr3=sc.nextDouble();
                    double won=(inr3*15.9333);
                    System.out.print(won);
                    break;
                   }

            case 5:{
                     System.out.println("Convert yen into euro");
                     System.out.println("Enter yen:");
                     double yen=sc.nextDouble();
                     double euro=(yen*160.02);
                     System.out.print(euro);
                     break;
                   }

            case 6:{
                    System.out.println("Covert INR into DIRHAM");
                    System.out.println("Enter a ruppes");
                    double rupees=sc.nextDouble();
                    double dirham=(rupees*0.044);
                    System.out.print(dirham);
                    break;
                   }
            case 7:{
                    System.out.println("Covert Dollar inti yen");
                    System.out.println("Enter a Dollar:");
                    double dollar2=sc.nextDouble();
                    double yen2=(dollar2*149.69);
                    System.out.print(yen2);
                    break;
                   }
            default:{
            	System.out.print("Invalid input");
            }

		}
	}
}