class ForLoop5
{
	public static void main(String[] args) {
		int b=0;
		boolean a=true;
		for (;a ; ) {
			System.out.println("hello");
			b++;
			if (b==1000) {
				break;
			}

		}
		System.out.println("byee");
	}
}