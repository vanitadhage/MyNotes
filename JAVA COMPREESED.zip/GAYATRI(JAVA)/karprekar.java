import java.util.Scanner;
class karprekar
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		int sqr=num*num;
		// int sqrt=sqr;
		int count=0;
		int div=10;
		
        
		for ( ;sqr!=0;sqr/=10 ) {
			count++;
		}
		// System.out.print(count);
		if (count%2==0) {
			
		  int sum=0;   
            for (int i=0  ;i<count/2 ;i++ )  {
            	div*=10;
            	int a=sqr%div;
            	int b=sqr/div;
            	// System.out.println(a+" "+b);
            	 sum=a+b;
             // System.out.println(sum);
            }
            if (sum==num) {
            	System.out.println("karprekar number");
            }
            else
            {
            	System.out.println("Not karprekar number ");
            }
        }
        // else
        // {
        //     	System.out.println("No karprekar number ");

        // }

	}
}