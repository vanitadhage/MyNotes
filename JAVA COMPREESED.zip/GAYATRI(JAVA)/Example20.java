class Example20
{
	public static void main(String[] args) {
		int num=17;
		int sum=0;
		int i=1;
		while(i<=num)
		{
			int rem=i%10;
			if(i%2==0)
			{
				sum+=rem;
				num/=10;
			}
			i++;
		}
		System.out.print(sum);
	}
}