import java.util.Scanner;
class MinNum
{
	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.print("Enter a number1 :");
		int a=sc.nextInt();
		System.out.print("Enter a number2 :");
		int b=sc.nextInt();
		int min =a<b?a:b;
		System.out.println("Min number is :"+min);
	}
}