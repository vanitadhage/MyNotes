class RecursionEvenNo
{
	// static int i=2;
	public static void main(String[] args) {
		EvenNum(1,100);
	}
	public static void EvenNum(int num,int i)
	{
		if (num>i)
		 return; 
		if (num%2==0) {
		 System.out.print(num+" ");
		 EvenNum(num+2,i);
	  	}
	  	else{
		 EvenNum(num+1,i); 
		} 		
	}
}