import java.util.Scanner;
class IfExample2
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a y :");
		int y=sc.nextInt();
		int x=0;
	
		if (y>0) {
			x=1;
			System.out.println("The value of 'x' is"+x);
		}
	}
}