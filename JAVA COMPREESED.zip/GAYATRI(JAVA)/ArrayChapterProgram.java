import java.util.*;
class ArrayChapterProgram
{
	public static void main(String[] args) 
	{
	   Scanner sc=new Scanner(System.in);
	   System.out.print("Enter a chapters :");
	   int chap=sc.nextInt();

	   System.out.print("Enter a start date :");
	   int sdate=sc.nextInt();

	   System.out.print("Enter a end date :");
	   int ldate=sc.nextInt();
	   chapterProgram(chap,sdate,ldate);

	}
	public static void chapterProgram(int chap,int sdate,int ldate)
	{
		int[]chapters=new int[ldate+1];
		int []missedChapt=new int[(ldate-sdate)+1];
		int chapter=0;
		int mcindx=0;
		for (int i=0;i<chapters.length ;i++ ) 
		{
		  chapters[i]=chapter++;
		  if (chapter==chap) 
		  {
		  		chapter=0;
		  	}	
		}
		for (int i=sdate;i<=ldate ;i++ ) 
		{
			 missedChapt[mcindx++]=chapters[i];
		}
		int count=uniqueElement(missedChapt);
		System.out.println(count);
	}
	public static int uniqueElement(int[] arr)
	{
		int cnt=0;
		for (int i=0;i<arr.length ;i++ ) 
		{
			int j=0;
			for ( ;j<arr.length ;j++ ) 
			{
				if (arr[i]==arr[j]) 
					break;
			}
				if (i==j) 
					cnt++;
				
	    }
		return cnt;	
	}
}