import java.util.Scanner;
class IfExample
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		if (num % 5==0) {
			System.out.println("HiFive");	
		}
		if (num% 2==0) {
			System.out.println("HiEven");
		}
	}
}