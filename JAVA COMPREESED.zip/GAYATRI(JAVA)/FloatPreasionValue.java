class FloatPreasionValue
{
 public static void main(String [] args)
  {
    float f=5/3.0f;
    System.out.println(f);
  }
}