class Student implements Cloneable
{
  String name;
  String ntvplace;
  long phoneNumber;
  String branch;

  Student(String name,String ntvplace,long phoneNumber,String branch)
  {
    this.name=name;
    this.ntvplace=ntvplace;
    this.phoneNumber=phoneNumber;
    this.branch=branch;
  }
  protected Object clone() throws CloneNotSupportedException
  {
  	return super.clone();  
  }
}
class CloneExample1
{
   public static void main(String[] args) throws CloneNotSupportedException
   {
   	Student obj1=new Student("Ramesh","Pune",9876543212l,"Cs");
   	Student obj2=(Student)obj1.clone();
   	System.out.println(obj1.name);
   	System.out.println(obj2.name);
    obj1.name="Ganesh";
    System.out.println(obj1.name);
    System.out.println(obj2.name);
   }
}