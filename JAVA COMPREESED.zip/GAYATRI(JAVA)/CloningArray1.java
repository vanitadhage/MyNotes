import java.util.Arrays;
class CloningArray1
{
	public static void main(String[] args) {
		int []arr={10,20,30,40,50};
		int []dup=new int[arr.length];

		// for (int i=0;i<arr.length ;i++ ) {
		// 	dup[i]=arr[i];
		// }
		int i=0;
		while(i<arr.length)
		{
			dup[i]=arr[i];
			i++;
		}
		System.out.println(Arrays.toString(arr));
		System.out.println(Arrays.toString(dup));
		arr[2]=1000;
		System.out.println(Arrays.toString(arr));
		System.out.println(Arrays.toString(dup));

	}
}