class Corona
{
  public static void main(String [] args)
  {
   int coronaCases=696050046;
   int death=6922372;
   int recovered=668066514;
   System.out.println("corona Cases :"+coronaCases);
   System.out.println("death:"+death);
   System.out.println("recovered :"+recovered);
  }
}