class Shape
{
	public void draw()
	{
		System.out.println("Drawing a shape");
	}
}
class Circle extends Shape
{
	public void drawCircle()
	{
       System.out.println("Draw a Circle");
	}
}
class ShapeDriver
{
   public static void main(String[] args) 
   {
   	  Circle a=new Circle();
   	  a.draw();
   	  a.drawCircle();
   }
}