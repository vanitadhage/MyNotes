class DoublePrecisionValue
{
 public static void main(String [] args)
  {
   double d=5/3.0f;
   System.out.println(d);
  }
}