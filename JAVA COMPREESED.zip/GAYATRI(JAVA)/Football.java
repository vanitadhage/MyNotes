class Football
{
 public static void main(String [] args)
 {
  byte noOfPlayers=11;
  byte noOfGoals=5;
  byte noOfTeam=2;
  byte groundMaxLength=120; 
  System.out.println("No Of Players :"+noOfPlayers);
  System.out.println("No Of Goals:"+noOfGoals);
  System.out.println("No Of Team :"+noOfTeam);
  System.out.println("Ground Max Length :"+groundMaxLength);
 }
}
