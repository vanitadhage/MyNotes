class ArrayAramstrongNum
{
	public static void main(String[] args) 
	{
		 int [] arr={153,456,245,665,370,407};
		 for (int num :arr ) {
		 	if (isArmstrong(num)) {
		 		System.out.print(num+" ");
		 	}
		 }
	}
	public static boolean isArmstrong(int num)
	{
		int dup=num;
		int dup1=num;
        int count=0;    
        int sum=0;
      while (dup>0) {
      	count++;
      	dup/=10;
      }
      while(dup1>0)
      {
      	int rem=dup1%10;
      	int pow=1;
      	for (int i=1;i<=count ;i++ ) {
      		pow*=rem;
      	}
      	sum+=pow;
      	dup1/=10;
      }
      if (sum==num) {
      	return true;
      }
      else
      {
      	return false;
      }


	}
}