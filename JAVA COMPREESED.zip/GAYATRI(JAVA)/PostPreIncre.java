class PostPreIncre
{
	public static void main(String[] args) {
		int a=2;
		System.out.println(a);//2
		System.out.println(a++);//2
		System.out.println(++a);//4
		System.out.println(a);//4
		System.out.println(a++);//4
		System.out.println(a++);//5
		System.out.println(++a);//7
		System.out.println(a++);//7
		System.out.println(a);//8
	}
}