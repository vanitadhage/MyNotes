class Example6
{
	public void m1()
	{
		System.out.println("m1() non-static from Example6");
	}
	public void m2()
	{
		System.out.println("m2() non-static from  Example6");
	}
}