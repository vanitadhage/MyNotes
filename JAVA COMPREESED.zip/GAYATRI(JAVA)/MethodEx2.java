class MethodEx2
{
	public static void main(String[] args) {
		String op=m1("Ramesh",9.9,false);
	}
	public static String m1(String name,double cgpa,boolean backlg)
	{
     System.out.println("My name is "+name);
     System.out.println("I have scored "+cgpa+"cgpa");
     System.out.println(backlg);
     return "GOOD EVENING";

	}
}