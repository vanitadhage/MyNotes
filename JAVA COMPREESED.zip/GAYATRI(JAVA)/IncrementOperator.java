class IncrementOperator
{
	public static void main(String[] args) {
		int a=2;
		int b=a++;//2(3)
		int c=a;//3
		System.out.println(a);//3
		System.out.println(b);//2
		System.out.println(c);//3
	}
}