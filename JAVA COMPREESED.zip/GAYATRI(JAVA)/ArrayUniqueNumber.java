import java.util.*;
class ArrayUniqueNumber
{
	public static void main(String[] args) 
	{
		int []arr={5,3,6,4,5,3,7,2,8,13,4,5,6};
		// int count=uniqueNum(arr);
		// System.out.println(count);
	  int cnt=0;
      int j;
      for (int i=0;i<arr.length ;i++ ) 
      {
      	for (j=0 ;j<arr.length ;j++ ) 
      	{
      		if (arr[i]==arr[j]) 
      			break;
        } 
        if (i==j) 
      	  cnt++;
        }
	 int []newArr=new int[cnt];
     int indx=0;
     for (int i=0;i<arr.length ;i++ ) {
     	for ( j=0;j<arr.length ;j++ ) {
     		if (arr[i]==arr[j]) {
     			break;
     		}

     	}
     	if (i==j) {
     		newArr[indx++]=arr[i];
     	}
     }
     System.out.println(Arrays.toString(arr));
     System.out.println(Arrays.toString(newArr));

	}
}












// import java.util.*;
// class ArrayUniqueNumber
// {
// 	public static void main(String[] args) 
// 	{
// 		int []arr={5,3,6,4,5,3,7,2,8,13,4,5,6};
// 		int count=uniqueNum(arr);
// 		System.out.println(count);
// 	}
// 	public static int  uniqueNum(int []arr)
// 	{
// 		// int newArr=new int[arr.length];
//       int cnt=0;
//       int j;
//       for (int i=0;i<arr.length ;i++ ) 
//       {
//       	for (j=0 ;j<arr.length ;j++ ) 
//       	{
//       		if (arr[i]==arr[j]) 
//       			break;
//         } 
//         if (i==j) 
//       	  cnt++;    		
//      }
//      return cnt; 
// 	}
// }