class IfElseEx1
{
	public static void main(String[] args) {
		if (false) {
			System.out.print("hii");
		}
		else {
			System.out.println("byee");
		}
	}
}