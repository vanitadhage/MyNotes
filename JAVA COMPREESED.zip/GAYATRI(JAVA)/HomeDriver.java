class Home
{
	double area;
	String color;
	int doors;
	int rooms;
	int floors;
	

	public void homeInfo()
	{
		System.out.println("*****Frame Info*****");
		System.out.println("Area :"+area+"sqft");
		System.out.println("doors :"+doors);
		System.out.println("Color :"+color);
		System.out.println("rooms  :"+rooms);
		System.out.println("floors :"+floors);
		System.out.println();
	}
}
class HomeDriver
{
	public static void main(String[] args) 
	{
		Home a=new Home();
		
		a.area=1200;
		a.doors=10;
		a.color="maroon";
		a.rooms=5;
		a.floors=2;
		a.homeInfo();
	}
}