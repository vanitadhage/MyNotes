class RecursionReverse
{
	public static void main(String[] args) {
		reverse(123,1,0);

	}
	public static void reverse(int num,int i,int rev)
	{
   
        if (num>0) {
        	 i=num%10;
        	rev=rev*10+i;	
        	reverse(num/=10,i,rev);
        	System.out.println(rev);
        }
	}
}