import java.util.Scanner;
class Division1
{   
	 public static void main(String[] args) 
	{
	   Scanner sc=new Scanner(System.in);
	   System.out.print("Enter a 1st number :");
	   float num1=sc.nextFloat();
	   System.out.print("Enter a 2nd number :");
	   float num2=sc.nextFloat();
	   Float result=num1/num2;
	   System.out.print("Division of 2 number"+result);
	}
}