class CarDriver1
{
	public static void main(String[] args) {
		Car1 a=new Car1("Honda","city");
		a.createDriver("Rashi",21,"Female");
		a.displayCar();
		// System.out.println("hi");
	}
}