//find max number in 3 digit;
// class MaxNumber
// {
// 	public static void main(String[] args) {
// 		int a=9;
// 		int b=7;
// 		int c=3;
// 		int  op=(a>b)?(a>c?a:c):(b>c?b:c);
// 		System.out.println(op);
// 	}
// }
import java.util.Scanner;
class MaxNumber
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a num1 :");
		int a=sc.nextInt();
		System.out.print("Enter a num2 :");
		int b=sc.nextInt();
		System.out.print("Enter a num3 :");
		int c=sc.nextInt();
		int  op=(a>b)?(a>c?a:c):(b>c?b:c);
		System.out.println(op);
	}
}