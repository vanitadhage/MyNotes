class Parent
{
    Parent()
    {
    	super();
    	System.out.println("no argu Parent const");
    }
}
class Child extends Parent
{
   Child()
   {
     this(10);
     System.out.println("No argu child const");
   }
   Child(int a)
   {
   	super();
   	System.out.println("1 argu child const");
   }
   public static void main(String[] args) {
   	Child a=new Child();
   }
}