class Human
{
 public static void main(String [] args)
 {
  byte noOfHeart=1;
  byte noOfFinger=20;
  byte noOfHands=2;
  byte noOfVertebrae=33;
  byte noOfEyes=2;
  System.out.println("No of hearts :"+noOfHeart);
  System.out.println("No Of Finger :"+noOfFinger);
  System.out.println("No Of Hands :"+noOfHands);
  System.out.println("No Of Vertebrae:"+noOfVertebrae);
  System.out.println("No Of Eyes :"+noOfEyes);
 }
}