class MethodExample
{
	public static void main(String[] args) {
		System.out.println("Hello main method");
		myMethod();
	}
	public static void myMethod()
	{
		System.out.println("Hi my Method");
	}
}