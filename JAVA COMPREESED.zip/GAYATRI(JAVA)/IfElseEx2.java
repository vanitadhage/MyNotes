class IfElseEx2
{
	public static void main(String[] args) {
		if (false) {
			System.out.print("hii");
		}
		System.out.println("hi in between");
		else {
			System.out.println("byee");
		}
	}
}