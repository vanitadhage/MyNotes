import java.util.Scanner;
class PositiveNegativeNo
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		String op=(num>0)?"Positive":"Negative";
		System.out.println("The number is :"+op);
	}
}