class Example2
{
	public static void main(String[] args) {
		Example2 a=new Example2();
		a.m1();
	}
	public void m1()
	{
		System.out.println("m1() non-static from Example2");
	}
}