class MethodCallingEx
{
	public static void main(String[] args) {
		name();    //method calling statement
	}
	public static void name()
	{
		System.out.print("Gayatri"+" ");
		middleName();
	}
	public static void middleName()
	{
		System.out.print("Bapurao"+" ");
		surname();
	}
	public static void surname()
	{
		System.out.print("Pawar");
	}

}