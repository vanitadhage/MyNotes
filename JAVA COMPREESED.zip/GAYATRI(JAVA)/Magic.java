import java.util.Scanner;
class Magic
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		int sum=0;
		while(num!=0||sum>9)
		{
			if (num==0) {
				num=sum;
				sum=0;
			}
			int rem=num%10;
			sum+=rem;
			num/=10;
		}
		if (sum==1) {
			System.out.println("Magic number");
		}
		else
		{
			System.out.println("Not magic number");
		}
	}
}