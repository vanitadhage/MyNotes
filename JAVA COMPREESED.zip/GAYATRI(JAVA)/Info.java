import java.util.Scanner;
class Info
{
 public static void main(String [] args)
  {
   System.out.print("Enter your name :");
   Scanner sc=new Scanner(System.in);
   String name=sc.next();

   System.out.print("Enter your NVT :");
   Scanner sc1=new Scanner(System.in);
   String nvt=sc1.next();

   System.out.print("Enter your yop :");
   Scanner scb=new Scanner(System.in);
   short yop=scb.nextShort();

   System.out.print("Enter your branch :");
   Scanner scc=new Scanner(System.in);
   String branch=scc.next();
   
   System.out.print("Enter your University :");
   Scanner scd=new Scanner(System.in);
   String university=scd.nextLine();
   
   System.out.print("Enter your CGPA :");
   Scanner sce=new Scanner(System.in);
   float cgpa=sce.nextFloat();
   
   System.out.print("you have any backlogs :");
   Scanner scf=new Scanner(System.in);
   boolean backlogs=scf.nextBoolean();
  }
}