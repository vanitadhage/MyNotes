import java.util.Arrays;
class CloningTwoDArrayCloneMethod
{
	public static void main(String[] args) {
		char[][]charaters={{'a','b','c','d'},{'g','u','x','y','z'}};
		char [][] dup=charaters.clone();
		System.out.println("Orignal Array :"+Arrays.deepToString(charaters));
		System.out.println("Dup arr :"+Arrays.deepToString(dup));
		charaters[1][0]='B';
		System.out.println("Orignal Array :"+Arrays.deepToString(charaters));
		System.out.println("Dup arr :"+Arrays.deepToString(dup));

	}
}