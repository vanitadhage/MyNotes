import java.util.Scanner;
class Equation1
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a 1st number :");
		int a=sc.nextInt();
		System.out.println("Enter a 2nd number :");
		int b=sc.nextInt();
		int area=a*a+2*a*b+b*b;
		System.out.println("Equation :"+area);
	}
}