// class Fibonacci
// {
// 	public static void main(String[] args) 
// 	{
// 		int num1=0;
// 		int num2=1;
//         int count=10;
//         System.out.print(num1+" "+num2);
// 		for (int i=2;i<count ;++i) {
// 			int op=num1+num2;
// 			System.out.print("  "+op);
// 			num1=num2;
// 			num2=op;
// 		}
// 	}
// }

import java.util.Scanner;
class Fibonacci
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number1 :");
		int num1=sc.nextInt();//0
		System.out.print("Enter a number2 :");
		int num2=sc.nextInt();//1
        int count=5;

		for (int i=1;i<=count ;i++ ) {
			int op=num1+num2;
			System.out.println(op+" ");
			num1=num2;
			num2=op;
		}
	}
}


