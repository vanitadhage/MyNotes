import java.util.Scanner;
class AirpalneRunwayLength
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a Speed :");
		double speed=sc.nextDouble();
		System.out.print("Enter a accelration :");
		double accelration=sc.nextDouble();
		double length=(speed*speed)/(2*accelration);
		System.out.println("The minimum runway length is the airplane is :"+length);
	}
}