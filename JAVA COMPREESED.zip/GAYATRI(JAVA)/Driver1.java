class Parent
{
    String a="Parent class Variable";
}
class Child extends Parent
{
	String a="child class variable";

	public void demo()
	{
		System.out.println(super.a);
		System.out.println(this.a) ;
	}
	
}
class Driver1
{
	public static void main(String[] args)
	 {
	 	Child c= new Child();
	 	c.demo();
	}
}






	 	/*Parent p=new Child() ;
	 	System.out.println(p.a) ;*/