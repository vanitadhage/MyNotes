import java.util.Scanner;
class SwitchVowels
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a charater :");
		char ch=sc.next().charAt(0);
		switch(ch)
		{
           case 'a':
           case 'e':
           case 'i':
           case 'o':
           case 'u':System.out.println("it is a vowels");break;
           default:System.out.println("It is a consenent");break;
		}
	}

}