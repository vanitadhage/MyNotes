import java.util.Scanner;
class  AmicableNum
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num1=sc.nextInt();
		System.out.print("Enter a number :");

		int num2=sc.nextInt();
        int op1=0;
        int op2=0;
		for (int i=1;i<num1 ;i++ ) {
			if (num1%i==0) {
				System.out.println("Factors of num1 "+i+" ");
				  op1+=i;
			}
		}
		for (int j=1;j<num2 ;j++ ) {
			if (num2%j==0) {
				System.out.println("Factors of num2 "+j+" ");
				  op2+=j;
			}
		}
		if(op1==num2&&op2==num1)
		{
			System.out.println("It is Amicable Number");
		}
		else{
			System.out.println("It is Not Amicable Number");

		}
	}
}