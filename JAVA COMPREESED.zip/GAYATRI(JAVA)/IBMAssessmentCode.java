import java.util.*;
class IBMAssessmentCode
{
	public static void main(String[] args) 
	{
	  int []a={25,10,20};//85
		// int []a={100,1};//101
		// int []a={30,10,20};//90  

      System.out.println(getTotalMinCost(a));
	}
   public static int getTotalMinCost(int []a)
	{
		int totalCost=0;
		if (a.length==1) {
			return a[0];
		}

		for (int i=a.length-1;i>0 ;i--) 
	    {
          int sum=a[i-1]+a[i];
          totalCost+=sum;
          a[i-1]=sum;
	   }
      return totalCost;
	}
}

