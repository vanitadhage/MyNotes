import java.util.*;
class ArrayProgram
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the size of a data :");
		int size=sc.nextInt();
		int[]arr=new int[size];

		for (int i=0;i<arr.length ;i++ ) {
			System.out.print("Enter the data"+(i+1)+" : ");
			int data =sc.nextInt();
			arr[i]=data;
		}
		System.out.println(Arrays.toString(arr));
	}
}