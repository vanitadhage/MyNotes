import java.util.Scanner;
class Army
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a age :");
		int age=sc.nextInt();
		System.out.print("Enter a height :");
		double height=sc.nextDouble();
		System.out.print("Enter a weight :");
		double weight=sc.nextDouble();

		if (age>=18&&(height>=162&&weight>=56)) {
			System.out.println("user are able to join Army");
		}
		else
		{
			System.out.println("user are not able to join Army");
		}
	}
}