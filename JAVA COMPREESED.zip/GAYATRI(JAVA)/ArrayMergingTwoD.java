import java.util.Arrays;
class ArrayMergingTwoD
{
   public static void main(String[] args) 
   {
   	int [][]arr={{1,2,3,4},{5,6,7},{8,9}};
   	int []newArr=new int[(arr[0].length)+(arr[1].length)+(arr[2].length)];
    int indx=0;
   	for (int i=0;i<arr.length ;i++ ) 
   	{
   		for (int j=0;j<arr[i].length ;j++ ) 
   		{
   			newArr[indx++]=arr[i][j];
   		}
   	}
   	System.out.print(Arrays.toString(newArr));
   }

}


// class ArrayMergingTwoD
// {
//    public static void main(String[] args) 
//    {
//    	int [][]arr={{1,2,3,4},{5,6,7,8,9}};
//    	int []newArr=new int[(arr[0].length)+(arr[1].length)];
//     int indx=0;
//    	for (int i=0;i<arr.length ;i++ ) 
//    	{
//    		for (int j=0;j<arr[i].length ;j++ ) 
//    		{
//    			newArr[indx++]=arr[i][j];
//    		}
//    	}
//    	System.out.print(Arrays.toString(newArr));
//    }

// }
