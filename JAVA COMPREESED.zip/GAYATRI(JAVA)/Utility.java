import java.util.Scanner;
public class Utility
{
	//Even Odd Number
   public static void even_Odd()
   {
   	Scanner sc=new Scanner(System.in);
   	System.out.print("Enter a number :");
   	int num=sc.nextInt();

   	if (num%2==0) 
   	  {
   		System.out.println(num+"No is Even");
   	  }
   	else
   	 {
   		System.out.println(num+" No is Odd");
   	 }
   }
   
   //prime number
   public static void prime()
   {
   	Scanner sc=new Scanner(System.in);
   	System.out.print("Enter a number :");
   	int num1=sc.nextInt();
   	int i=2;
   	int count=0;
   	while(i<num1)
   	{
   		if (num1%i==0) {
   			count++;
   		}
   		i++;
   	}
   	if (count>0) {
   		System.out.println("No is Not prime");
   	}
   	else
   	{
   		System.out.println("No is Prime");
   	}
   }
   //reverse number
   public static void rev()
   {
     Scanner sc=new Scanner(System.in);
     System.out.print("Enter a number :");
     int num2=sc.nextInt();
     int i,rev=0;

     while(num2!=0)
     {
     	i=num2%10;
     	rev=rev*10+i;
     	num2/=10;
     }
     System.out.println(rev);
   }
   //count od digit
   public static void countDigit()
   {
   	Scanner sc=new Scanner(System.in);
   	System.out.print("Enter a number :");
   	int num3=sc.nextInt();
   	int count=0;
   	int i=0;
   	while(num3!=0)
   		{
   			count++;
   			num3/=10;
   		}
   		i++;
   		System.out.println(count+ "is the count of digit");
   }

   //find hcf of 2 number
   public static void hcf()
   {
   	Scanner sc=new Scanner(System.in);
   	System.out.print("Enter 2 number to find hcf");
   	System.out.print("Enter a num1 :");
   	int num4=sc.nextInt();//24
   	System.out.print("Enter a num2 :");
   	int num5=sc.nextInt();//36
   	int hcf=0;
   	for (int i=1;i<=num4||i<=num5 ;i++ ) {
   		if (num4%i==0&&num5%i==0) {
   			hcf=i;
   		}
    }
   	System.out.println("hcf is :"+hcf);
   }

   //find lcm of 2 number
   public static void lcm()
   {
   	int a=4;
   	int b=5;
   	int c=a>b?a:b;

   	while(true)
   	{
   		if (c%a==0&&c%b==0) {
   			System.out.print("lcm is :"+c);
   			break;
   		}
   		c++;
   	}
   }

   //find hcf to lcm
   public static void hcflcm()
   {

   }

}