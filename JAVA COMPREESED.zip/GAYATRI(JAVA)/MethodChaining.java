class MethodChaining
{
	public static void main(String[] args) {
		m1();
	}
	public static void m1()
	{
		System.out.println("m1() No argu");
		m2(10);
	}
	public static void m2(int a)
	{
		System.out.println("m2() 1 argu");
		m3(10,20);
	}
	public static void m3(int a,int b)
	{
		System.out.println("m3() 2 argu");
	}
}