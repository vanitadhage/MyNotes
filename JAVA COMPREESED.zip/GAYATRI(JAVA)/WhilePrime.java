import java.util.Scanner;
class WhilePrime
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		int i=2;
		int count=0;
		while(i<num)
		{
			if (num%i==0) {
				count++;
			}
			i++;
		}
		//System.out.print((count>0)?"Not a Prime":"Prime");
		if (count>0) {
			System.out.print("Number is not prime");
		}
		else
			System.out.println("Prime");
	}
}