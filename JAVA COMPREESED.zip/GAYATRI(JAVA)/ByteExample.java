class ByteExample
{
  public static void main(String [] args)
  {
    System.out.println("Max :"+ Byte.MAX_VALUE);
    System.out.println("Min :"+ Byte.MIN_VALUEn);
  }
}