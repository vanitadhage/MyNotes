class Hotel
{
 public static void main(String [] args)
 {
   short manager=2;
   short cooks=10;
   short noOfWaiters=50;
   short noOfTables=100;
   short customer=1050;
   System.out.println("No of manager :"+manager);
   System.out.println("No of cooks :"+cooks);
   System.out.println("No of Waiters :"+noOfWaiters);
   System.out.println("No of Tables:"+noOfTables);
   System.out.println("No of customer :"+customer);
 }
}