import java.util.Scanner;
class PerfectSquare
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		int sqrt=0;
        for (int i=1;i<=num ;i++ ) 
        {
        	if (i*i==num) {
			sqrt=i;
			break;
		}

      }
      System.out.println((sqrt==0)?"Not Perfect Square":" sqrt is"+sqrt);
		
	}
}