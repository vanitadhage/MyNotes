import java.util.Scanner;
class DoWhilePinExample
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int pin1=123;
		int count=3;
		do
		{
			System.out.print("Enter a pin :");
			int pin2=sc.nextInt();
			if (pin1==pin2) {
				System.out.println("Phone has been unlocked start chatting");
				break;
			}
			else
			{
				System.out.println("Incorrect Pin "+(count-1)+"attempts left");
			}
			count--;
		}while(count!=0);//(count>0)	
	}
}