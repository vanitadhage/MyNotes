class ForLoop4
{
	public static void main(String[] args) {
		boolean a=true;
		for (;a ; ) {
			System.out.println("hello");
		}
		System.out.println("byee");
	}
}