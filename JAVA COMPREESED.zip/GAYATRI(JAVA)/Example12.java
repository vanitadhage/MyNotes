class Example12
{
	static String a="SURESH";

	static 
	{
		System.out.println(a);
		a="Ramesh";
		System.out.println(a);
	}
	public static void main(String[] args) {
		System.out.println(a);
	}
}