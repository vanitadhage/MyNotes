class HumanBody
{
 public static void main(String [] args)
  {
   long cells=37200000000000L;
   long rbc=250000000000000L;
   long neurons=136000000000L;
   long motochondria=10000000000000L;
   long bacterial=380000000000000L;
   System.out.println("no Of cells :"+cells);
   System.out.println("no Of rbc :"+rbc);
   System.out.println("no Of neurons :"+neurons);
   System.out.println("motochondria :"+motochondria);
   System.out.println("bacterial:"+bacterial);
  }
} 