class Token
{
 public static void main(String [] args)
  {
   String _ ="Hello world";
   System.out.println(_);
  }
}