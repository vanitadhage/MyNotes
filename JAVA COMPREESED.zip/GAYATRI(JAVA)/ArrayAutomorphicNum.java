import java.util.Arrays;
class ArrayAutomorphicNum  //using anonymous array
{
  public static void main(String[] args) 
  {
     isAutomorphic(new int[]{12,36,6,25,76,34,23});	
  }
  public static void isAutomorphic(int []num)
  {
  	for (int number :num ){
  		int count=0;
  		int dup=number;
  		int div=1;
  		int sqr=number*number;

  		while(dup>0)
  		{
  			count++;		
  			dup/=10;
  		}
  		for (int i=1;i<=count ;i++ ) {
  			div*=10;
  		}
  		if (number==(sqr%div)) {
  			System.out.print(number+" ");
  		}
  	}
  }
}