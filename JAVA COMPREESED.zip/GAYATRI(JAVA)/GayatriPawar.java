class GayatriPawar
{
 public static void main(String [] args)
  {
    System.out.print("My first java program");
  }
}