class IfElseEx3
{
	public static void main(String[] args) {
		if (false) 
			System.out.print("hii");
		   System.out.println("byeebyeee");
		else 
			System.out.println("byee");
		
	}
}