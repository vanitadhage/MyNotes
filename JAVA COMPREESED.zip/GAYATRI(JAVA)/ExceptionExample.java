class WrongInputException extends Exception
{                                                                                                                                                                                                                                                                                                                                                                                                                                         
	WrongInputException(String desc)
	{
		super(desc);
	}
}
class Ramesh
{
	public static void evenOdd(int num) throws WrongInputException
	{
		if (num!=0) {
			if (num%2==0) {
				System.out.println("Even");
			}
			else{
				System.out.println("Odd");
			}
		}
		else{
			throw new WrongInputException("Zero");
		}
	}
}
class Suresh
{
	public static void checkNumber() throws WrongInputException
	{
		Ramesh.evenOdd(10);
	}
}
class ExceptionExample
{
	public static void main(String[] args) {
		System.out.println("Exceution Starts");
		try{
			Suresh.checkNumber();
		}
		catch(WrongInputException wie){
          System.out.println("WrongInputException handled");
		}
		System.out.println("Exceution Ends");
	}
}