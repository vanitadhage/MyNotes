import java.util.Scanner;
class BloodDonate
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a age :");
		byte age=sc.nextByte();
		System.out.print("Enter a weight :");
		double weight=sc.nextDouble();
		System.out.print("have yoy had any consumption of alchol or cigratte :");
		boolean ans=sc.nextBoolean();
         if (ans==true) {
         	System.out.println("you are not eligible");
         }
         else if (ans==false) {
         	System.out.println("you are eligible");
         }
         else if (age>=20) {
         	System.out.println("User is able to donate blood");
         }
         else if (weight>=50) {
         	System.out.println("User is able to donate blood");
         }
         else
         {
         	System.out.println("User is not able to donate blood");
         }
	}
}