import java.util.Scanner;
class Rto
{
  public static void main(String[] args) {
  	Scanner sc=new Scanner(System.in);
  	System.out.print("Enter a age :");
  	byte age=sc.nextByte();                                             
  	
    if (age>=18) {
    	System.out.println("you are eligible for driving licences");
    	System.out.println("Have you pass driving test?");
    	boolean test=sc.nextBoolean();
    	if (test) {
    	System.out.println("you have cleared exam :");
    	System.out.println("Enter your marks :");
    	double marks=sc.nextDouble();
    	if(marks>=60){
    	System.out.println("You are passed driving test & wait for licences");
     }
     else
     {
     	System.out.println("Reappeared for the test again");
     }
    }
   }
     
  }

}