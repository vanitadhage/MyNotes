import java.util.*;
class ArrayFreq
{
	public static void main(String[] args) 
	{
		int []a={1,2,3,1,4,2,3,1,4,5};
		Arrays.sort(a);
		 System.out.println(Arrays.toString(a));
		 int count=0;
         int unqcount=uniqueElement(a);
         int [][]freq=new int[unqcount][2];
         
         int m=0;
         int n=0;
		for (int i=0;i<a.length ;i+=count) {
			
		    count=0;
			for (int j=0;j<a.length;j++ ) {
				if(a[i]==a[j]) {
                    count++;
				}
			}
			freq[m++][0]=a[i];
			freq[n++][1]=count;	
          
		}
		System.out.println(Arrays.deepToString(freq));

	}
	public static int uniqueElement(int[] a)
	{
		int count=0;
		for (int i=0;i<a.length ;i++ ) {
			int j=0;
			for (;j<a.length ;j++ ) {
				if (a[i]==a[j]) {
					break;
				}
			}
			if (i==j) {
				count++;
			}
		}
		return count;
	}
}