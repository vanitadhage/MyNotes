import java.util.Scanner;
class TechPrime
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
            int num1=num;
	    int count=0;

		for ( ; num1!=0;num1=num1/10)
			count++;
		
            int div=1;
            int op=0;
            for (int i=0;i<count/2 ;i++ ) {
            	div*=10;
            	int a=num%div;
            	int b=num/div;
            	int c=a+b;
                  op=c*c;
            }
            if (op==num) {

            	System.out.println("It is Tech Number");
                  int cnt=0;
                  for (int j=2;j<num ;j++ ) {
                        
                        if (num%j==0) {
                              cnt++;
                              break;
                        }     
                  }
                System.out.println((count>0)?"Not a Prime":" It is a Tech Prime");
            }
            else
            {
            	System.out.println("It is not Tech Number");
            }

	}
}