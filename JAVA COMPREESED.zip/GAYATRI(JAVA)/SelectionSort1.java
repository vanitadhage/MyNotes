import java.util.*;
class SelectionSort1
{
	public static void main(String[] args) {
		int []a={7,3,5,1,2};
		System.out.println(Arrays.toString(a));
		for (int i=0;i<a.length-1 ;i++ ) {
			int indx=i;
			for (int j=i+1;j<a.length ;j++ ) {
				if (a[indx]>a[j]) {
					indx=j;
				}
			}
			int temp=a[indx];
			a[indx]=a[i];
			a[i]=temp;
			System.out.println(i+":"+Arrays.toString(a));
		}
			System.out.println(Arrays.toString(a));

	}
}