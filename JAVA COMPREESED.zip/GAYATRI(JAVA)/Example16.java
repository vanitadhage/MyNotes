class Example16
{
	Example16() 
	{
      int obj=m1(10,15);
      System.out.println(obj);
	}
	public static void main(String[] args) {
		Example16 a=new Example16();
	}
	public int m1(int a,int b)
	{
       return a*b;
 }
}



