class Mobile
{
	String name;
	private int pin;

	Mobile(String name,int pin)
	{
		this.name=name;
		this.pin=pin;
		System.out.println("Mobile obj created successfully");
	}
	public int getPin()
	{
		return this.pin;
	}
}
class MobileDriver
{
	public static void main(String[] args) 
	{
		Mobile a=new Mobile("Ramesh",1234);
		System.out.println(a.name);
		System.out.println(a.getPin());
	}
}