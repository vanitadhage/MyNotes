class PrimeRecursion
{
	public static void main(String[] args) {
		prime(1,100);
	}
	public static void prime(int i,int lastnum)
	{

	}
}