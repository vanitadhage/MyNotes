class PalindromeRecursion
{
	static int rev=0;
	public static void main(String[] args) {
		int num=121;
		int rev=palindrome(num,0);
       	System.out.print((rev==num)?"Palindrome":"Not Palindrome");

	}
	public static int palindrome(int num,int rev)
	{
       if (num==0) {
           return rev;
         }
       	rev=(rev*10)+(num%10);
       return palindrome(num/10,rev);
       
	}
}



// int num=sc.nextInt();
// 	int rev=0;
// 	for (int i=num;i!=0;i/=10 ) {
// 		int rem=i%10;
// 		rev=rev*10+rem;