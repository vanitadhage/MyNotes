class CommandLineArug1
{
  public static void main(String[] args) 
  {
    int num1=Integer.parseInt(args[0]);
    int num2=Integer.parseInt(args[1]);	
    addition(num1,num2);
    subtraction(num1,num2);
    multiplication(num1,num2);
    division(num1,num2);
    modulus(num1,num2);

  }
  public static void addition(int num1,int num2)
  {
  	int op=num1+num2;
  	System.out.println("Addition :"+op);
  }
   public static void subtraction(int num1,int num2)
  {
  	int op=num1-num2;
  	System.out.println("Subtraction :"+op);
  }
   public static void multiplication(int num1,int num2)
  {
  	int op=num1*num2;
  	System.out.println("Multiplication :"+op);
  }
   public static void division(int num1,int num2)
  {
  	int op=num1/num2;
  	System.out.println("Division :"+op);
  }
   public static void modulus(int num1,int num2)
  {
  	int op=num1%num2;
  	System.out.println("Modulus :"+op);
  }
}