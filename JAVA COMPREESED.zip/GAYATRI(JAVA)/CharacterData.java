import java.util.Scanner;
class CharacterData
{
  public static void main(String [] args)
  {
   Scanner sc=new Scanner(System.in);
   System.out.print("Enter a name :");
   String name=sc.next();
   System.out.print("Enter a index value to fetch the char :");
   byte indx=sc.nextByte();
   char ch=name.charAt((indx)-1);
   System.out.println("character is :"+ch);
  }
}