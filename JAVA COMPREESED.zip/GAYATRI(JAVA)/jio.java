class Mobiles
{
  public static void main(String [] args)
  {
   long noOfMobileUser=11930000000L;
   long noOfPeopleUseSmartPhone=692000000000L;
   long noOfPeopleUseIphone=1360000000L;
   long noOfPeopleUseJioMobiles=441920000L;
   System.out.println("noOfMobileUser :"+noOfMobileUser);
   System.out.println("noOfPeopleUseSmartPhone :"+noOfPeopleUseSmartPhone);
   System.out.println("noOfPeopleUseIphone:"+noOfPeopleUseIphone);
   System.out.println("noOfPeopleUseJioMobiles :"+noOfPeopleUseJioMobiles);
  }
}