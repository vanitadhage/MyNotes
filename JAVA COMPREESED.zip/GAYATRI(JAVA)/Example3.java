class Example3
{
	public static void main(String[] args) {
		Example4 a=new Example4();
		a.m1();
		a.m2();
	}
}
class Example4
{
	public void m1()
	{
		System.out.println("m1() non-static from Example4");
	}
	public void m2()
	{
		System.out.println("m2() non-static from  Example4");
	}
}