class PersonalDetails
{
  public static void main(String [] args)
  {
    System.out.println("Name:Gayatri");
    System.out.println("Native:Beed");
    System.out.println("Currently staying in:pune");
    System.out.println("Education:Bcs");
    System.out.println("University:SPPU");
    System.out.println("CGPA:8.73");
    System.out.println("YOP:2023");
    System.out.println("Skills:HTML,CSS,BOOTSTRAP,SQL");
  }
}