class LibraryDriver
{
  public static void main(String[] args) {
  	System.out.println("Welcome here to study");
  	Book book=new Book("Here yurself","Prem Rawat","SelfHelp","Something Publication","English");
  	Library library =new Library("Aspire",6,12,500,"Deccan",7896756829l,book);
  	library.displayLibrary();
  	library.book.displayBook();
  	library.addLibrarian();
  	library.librarian.displayLibrarian();
    library.addShelf();
    library.shelf.displayShelf();
    library.addStudent();
    library.student.displayStudent();
  }
}