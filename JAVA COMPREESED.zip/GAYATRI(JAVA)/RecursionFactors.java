class RecursionFactors
{
	
	public static void main(String[] args) {
		factors(30,1);

	}
	public static void factors(int num,int a)
	{
		if(a<=num)
		{
		   if(num%a==0)
		    {
              System.out.print(a+" ");
		     }
		factors(num,a+1);
	    }
		
		
	}
}