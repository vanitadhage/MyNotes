class FibonacciRecursion
{
	public static void main(String[] args) {
		
		fibonacci(1,0,1,10);
	}
	public static void fibonacci(int i,int num1,int num2,int count)
	{
		if (i<=count) {
			int op=num1+num2;
			System.out.print(op+" ");
			num1=num2; 
			num2=op;
		   fibonacci(i+1,num1,num2,count);
		}
		

	}
}


