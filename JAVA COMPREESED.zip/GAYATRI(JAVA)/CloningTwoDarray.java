import java.util.Arrays;
class CloningTwoDarray
{
  public static void main(String[] args) {
  	int [][]arr={{100,200},{300,400,500,600},{700}};
  	int [][]dup=new int[3][];

  	for (int i=0;i<arr.length ;i++ ) {
  		dup[i]=new int[(arr[i].length)];
  	}


  	for (int i=0;i<arr.length ;i++ ) {
  		for (int j=0;j<arr[i].length;j++ ) {
  			dup[i][j]=arr[i][j];
  		}
  	}
  	System.out.println(Arrays.deepToString(arr));
  	// System.out.println(Arrays.deepToString(dup));

  }
}