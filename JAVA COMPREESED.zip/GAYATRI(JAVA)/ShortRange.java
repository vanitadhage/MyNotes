class ShortRange
{
 public static void main(String [] args)
  {
    System.out.println("Short :"+ Short.MAX_VALUE);
    System.out.println("Short :"+ Short.MIN_VALUE);
  }
}