class SocialMedia
{ 
	long contactNo;
	String userName;
	SocialMedia(long contactNo,String userName)
	{
		this.contactNo=contactNo;
		this.userName=userName;
	}
	void chats()
	{
		System.out.println("User can chat with others");
	}
	
}
class Instagram extends SocialMedia
{
    String id;
	Instagram(long contactNo,String userName,String id)
	{
        super(contactNo,userName);
        this.id=id;
	}
	void reel()
	{
		System.out.println("User can see the reels");
	}
}
class WhatsApp extends SocialMedia
{
	int noOfGroup;
	WhatsApp(long contactNo,String userName,int noOfGroup)
	{
       super(contactNo,userName);
       this.noOfGroup=noOfGroup;
	}
    void group()
   {
      System.out.println("In Whats app User can create groups ");
   }
}
class SnapChat extends SocialMedia
{  
	String snapId;
	SnapChat(long contactNo,String userName,String snapId)
	{
      super(contactNo,userName);
      this.snapId=snapId;
	}

	void filter()
	{
		System.out.println("In snap we capture the image with filter");
	}
}
class SocialMediaDriver
{
   public static void main(String[] args) 
   {
     Instagram a=new Instagram(8888779966l,"Gayatri","abc_456");
     a.reel();
     a.chats();
     System.out.println("Insta User name is :- "+a.userName);
     System.out.println("Conatct number :"+a.contactNo);
     System.out.println("Insta id :"+a.id);
     System.out.println();
     
     WhatsApp b=new WhatsApp(8888779966l,"Gayatri",4);
     b.group();
     b.chats();
     System.out.println("Whats App user name :"+a.userName);
     System.out.println("WhatsApp login number :"+a.contactNo);
     System.out.println("WhatsApp number of groups :"+b.noOfGroup);
     System.out.println();

     SnapChat c=new SnapChat(8888779966l,"Gayatri","mahi123");
     c.filter();
     c.chats();
     System.out.println("Snap Userame :"+a.userName);
     System.out.println("Conatct  number :"+a.contactNo);
     System.out.println("Snap id is :"+c.snapId);
     

   }
}