import java.util.Scanner;
class IfElseExample3
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a percentage :");
		double per=sc.nextDouble();
		if (per>60) {
			System.out.println("The user eligible for interview");
		}
		if(per<60){
			System.out.println("The user is not eligible for interview");
		}
	}
}