import java.util.*;
class InsertionSort
{
	public static void main(String[] args) {
		int []a={7,3,5,1,2};
		System.out.println(Arrays.toString(a));

		for (int i=1;i<a.length ;i++ ) {
			int ele=a[i];
			int j=i-1;
			while(j>=0 && a[j]>ele)
			{
				a[j+1]=a[j];
				j--;
			}
			a[j+1]=ele;
		}
		System.out.println(Arrays.toString(a));
	}
}