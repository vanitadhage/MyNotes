class PopulationProjection
{
	public static void main(String[] args) {
		long birthRateInSeconds=7l;
		long deathRateInSeconds=13l;
		long newImmigrantEverySeconds=45l;

		
		long currentPopulation=312032486l;

		long secondsInYears=60*60*24*365;

		long numBirths=secondsInYears/birthRateInSeconds;
		long numDeath=secondsInYears/deathRateInSeconds;
		long numImmigrant=secondsInYears/newImmigrantEverySeconds;

		long populationInNextFiveYears=currentPopulation+numBirths+numImmigrant-numDeath;
		System.out.println("Population In Next Five Years is :"+populationInNextFiveYears);
	}
}