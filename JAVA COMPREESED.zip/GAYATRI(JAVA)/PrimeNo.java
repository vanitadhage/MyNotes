// import java.util.Scanner;
// class PrimeNo
// {
// 	public static void main(String[] args) {
// 		Scanner sc=new Scanner(System.in);
// 		System.out.print("Enter a number :");
// 		int num=sc.nextInt();
// 		int count=0;
// 		for (int i=2;i<num ;i++ ) {
// 			if (num%i==0) {
// 				count++;
// 			}
// 		}
// 		System.out.println((count>0)?"Not a prime":"Prime");
// 	}
// }


// import java.util.Scanner;
// class PrimeNo
// {
// 	public static void main(String[] args) {
//       Scanner sc=new Scanner(System.in);
//       System.out.print("Enter a number :");
//       int num=sc.nextInt();
//       int count=0;
//       int i=2;
//       while(i<num)
//       {
//       	if (num%i==0) {
//       		count++;
//       	}
//       	i++;
        
//       }
//       System.out.println((count!=0)?"Not Prime":"Prime");
// 	}
// }


// import java.util.Scanner;
// class PrimeNo
// {
//       public static void main(String[] args) {
//             Scanner sc=new Scanner(System.in);
//             System.out.print("Enter a number:");
//             int num=sc.nextInt();
//             int count=0;

//             for (int i=2;i<num ;i++ ) {
//                   if (num%i==0) {
//                         count++;
//                   }
//             }
//             System.out.println((count>0)?"Not a prime":"Prime");
//       }

// }

import java.util.Scanner;
class PrimeNo
{
      public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            System.out.print("Enter a number :");
            int num=sc.nextInt();
            int count=0;

            for (int i=2;i<num ;i++ ) {
                  if (num%i==0) {
                        count++;
                  }
            }
            if (count>0) {
                  System.out.println("Not a prime");
            }
            else{
                  System.out.println("Prime");
            }
      }
}
