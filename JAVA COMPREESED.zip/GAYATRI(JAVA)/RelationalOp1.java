class RelationalOp1
{
	public static void main(String[] args) {
		int a=2;
		int b=++a;//4
		int c=++b;//4
		System.out.println(a);//3
		System.out.println(b);//4
		System.out.println(c);//4
	}
}