class Parent1
{
	Parent1()
	{
		System.out.println("no argu Parent const");
	}
	Parent1(int a)
	{
		this();
		System.out.println("1 argu Parent const");
	}
}
class Child1 extends Parent1
{
	Child1()
	{
		this(10);
		System.out.println("no argu child const");
	}
	Child1(int a)
	{
		super(10);
		System.out.println("1 argu child const");
	}
	public static void main(String[] args) {
		Child1 a=new Child1();
	}
}