class InsufficientFundsException extends RuntimeException
{
   InsufficientFundsException(String desc)
   {
   	super(desc);
   }
}
class BankFeatures
{
	private double bal=10000;
    static BankFeatures obj=new BankFeatures();
	public double getbalance()
	{
     return this.bal=bal;
	}

	public void setbalance(double nbal)
	{
		this.bal=nbal;
	}

	public void deposit(double amt)
	{
		this.bal=this.bal+amt;
		System.out.print("deposited amount");
		System.out.println("New Bal is :"+this.getbalance());
	}
	public void withdraw(double wamt)
	{
		// int wamt=2000;
		if(this.obj.getbalance()>=wamt)
		{
			obj.setbalance(this.getbalance()-wamt);
			System.out.print("Amount debited");
			System.out.println("New bal is :"+this.getbalance());
		}
		else
		{
			try
			{
				throw new InsufficientFundsException("sorry in your account amount is not sufficient");
			}
			catch(InsufficientFundsException abc)
			{
             System.out.println(abc);
			}
		}
	}
	public static void main(String[] args) {
		obj.withdraw(3000);
	}
}