import java.util.Scanner;
class ExampleNum
{
	public static void main(String[] args) {
		Utility.even_Odd();
		Utility.prime();
		Utility.rev();
		Utility.countDigit();
		Utility.hcf();
		Utility.lcm();
	}
}