class ArrayCreation1
{
	public static void main(String[] args) {
		int [][][]a=new int[10][][];//......[](255)

		byte []b=new byte[128];

		boolean []c=new boolean[10000];
		

		// int []d=new int[2147483647];
		// System.out.print(d);

	
	}

}