import java.util.regex.*;
class RegexRemoveSpeciaChar
{
	public static void main(String[] args) {
		String a="aba2cDb%6e!a@A4aB";
        
		Pattern pt=Pattern.compile("[^a-z A-z 0-9]");
		Matcher mt=pt.matcher(a);
		newstr="";
		while(mt.find())
		{
			newstr+=mt.group();
		}
		System.out.println(newstr);
	}
}