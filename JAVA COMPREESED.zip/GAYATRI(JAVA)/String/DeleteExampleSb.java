import java.util.regex.*;

class DeleteExampleSb
{
   public static void main(String[] args) {
   	StringBuffer buffer=new StringBuffer("RA@M#ES&H!");
    // String b= Arrays.toString(buffer);
  

   	Pattern pt=Pattern.compile("[^a-zA-Z0-9]");
   	Matcher mt=pt.matcher(buffer.toString());
   	while(mt.find())
   	{
   		mt.delete(0,);
   		System.out.println(mt.start()+"--"+mt.group());
   	}
   	System.out.println(buffer);
   }
}