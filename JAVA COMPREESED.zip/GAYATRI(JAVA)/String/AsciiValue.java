import java.util.Scanner;
class AsciiValue
{
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
        System.out.print("Enter a char1 :");
        char ch1=sc.next().charAt(0);
	int asciiV1=ch1;	
	System.out.println("The Ascii value of " + ch1 +"is :"+asciiV1);
		
	}
}