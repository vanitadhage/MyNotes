import java.util.regex.*;                                        
class RegexMatches
{
	public static void main(String[] args) {
		System.out.println(Pattern.matches("[a-z]{5,}","abcdefghij"));
	}
}