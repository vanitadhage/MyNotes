class StartWithMethod
{
	static String a;
	public static void main(String[] args) {
		a="RAMESH";
		String srch="RAM";
		StartWithMethod obj=new StartWithMethod();
		System.out.println(obj.startsWith(srch));                                   
	}
	public boolean startsWith(String srch)
	{
		boolean b=true;
		for (int i=0;i<srch.length() ;i++ ) {
			if ((a.charAt(i))!=(srch.charAt(i))) {
				b=false;
				break;
			}
		}
		return b;
	}
}