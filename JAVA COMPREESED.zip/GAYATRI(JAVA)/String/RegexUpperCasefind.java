import java.util.regex.*;
class RegexUpperCasefind
{
	public static void main(String[] args) {
		String a="aba2cDb%6e!a@A4aB";
		// Pattern pt=Pattern.compile("[a-z]");
		// Pattern pt=Pattern.compile("[A-Z]");
		// Pattern pt=Pattern.compile("[0-9]");
		// Pattern pt=Pattern.compile("[a-z A-Z]");
		// Pattern pt=Pattern.compile("[a-z A-Z 0-9]");
		// Pattern pt=Pattern.compile("[^a-z A-Z 0-9]");
		// Pattern pt=Pattern.compile("[^a-z]");

		Matcher mt=pt.matcher(a);

		while(mt.find())
		{
			System.out.println(mt.start()+" - "+mt.group());
		}
	}
}