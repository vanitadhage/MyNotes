import java.util.regex.*;
class RegexExample3
{
	public static void main(String[] args) {
		String a="abababcabaaabcabaaa";
		Pattern pt=Pattern.compile("a?");
		Matcher mt=pt.matcher(a);
		while(mt.find())
		{
			System.out.println(mt.start()+"-"+mt.group());
		}
	}
}