// class ToLowerCase
// { 
// 	static String a="GaYaTri";
// 	public static void main(String[] args) 
// 	{ 
// 		ToLowerCase ab=new ToLowerCase();
// 		String b=ab.toLowerCase();
// 	  	System.out.println(b);
// 	}
// 	public String toLowerCase()
// 	{
// 		String newstr=" ";
// 		for (int i=0;i<a.length() ;i++ ) {
// 			char ch=a.charAt(i);
// 			if (ch>=65 && ch<=90) {
// 				newstr+=(char)(ch+32);
// 			}else{
// 				newstr+=ch;
// 			}
// 		}
// 		return newstr;
// 	}
// }

// class ToLowerCase
// {
// 	public static void main(String[] args) {
// 		System.out.println("Ramesh".toLowerCase());
// 		System.out.println("RaMEsh".toLowerCase());
// 		System.out.println("RAMESH".toLowerCase());
// 		System.out.println("R@Mesh".toLowerCase());
// 		System.out.println("ramesh".toLowerCase());

// 	}
// }


class ToLowerCase
{
	static String a="rajNAndiNI";
	public static void main(String[] args) 
	{
      ToLowerCase ab=new ToLowerCase();
      String b=ab.toLowerCase();
      System.out.println(b);
	}
	public String toLowerCase()
	{
		String newstr=" ";
		for (int i=0;i<a.length() ;i++ ) {
			char ch=a.charAt(i);
			if (ch>=65 &&ch<=90) {
				newstr+=(char)(ch+32);
			}
			else
			{
				newstr+=ch;
			}
		}
		return newstr;
	}
}