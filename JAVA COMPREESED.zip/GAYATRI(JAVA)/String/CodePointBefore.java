class CodePointBefore
{
	static String str;
	public static void main(String[] args) {
		CodePointBefore ab=new CodePointBefore();
		ab.str="ABCDEFGHI";
              System.out.println(ab.codePointBefore(1));
	}
	public int codePointBefore(int indx)
	{
       
         if (indx>0 && indx<=str.length()) {
                return str.charAt(indx-1);
         }else{
              throw new StringIndexOutOfBoundsException("Invalid indx");
         }

	}
}