import java.util.Arrays;
class SortStr
{
	public static void main(String[] args) 
	{
		String a="gayatri";
		StringBuffer sb=new StringBuffer(a);
		char arr[]=a.toCharArray();
		for (int i=0;i<arr.length ;i++ ) {
			for (int j=i+1;j<arr.length ;j++ ) {
				if (arr[i]>arr[j]) {
					char ch=arr[i];
					arr[i]=arr[j];
					arr[j]=ch;
				}
			}
		}
		System.out.println(Arrays.toString(arr));
		a=new String(arr);
		System.out.println(a);
	}
}