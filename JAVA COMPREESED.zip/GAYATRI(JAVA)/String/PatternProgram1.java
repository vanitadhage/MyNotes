class PatternProgram1
{
  public static void main(String[] args) 
  {
   int a=15;
   int b=5;
   for (int i=1;i<=5 ;i++ ) 
    {
     int j=b;
        for ( j=b;j>=1 ;j-- )
	{
	 System.out.print(a+" ");
        a--;
	}
	b--;
   System.out.println();
}
}
}