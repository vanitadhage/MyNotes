import java.util.regex.*;
import java.util.*;
class DateValidation
{
	public static void main(String[] args) {
		String date="26/01/2024";
		if (Pattern.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}",date)) 
		{
			String[] ele=date.split("/");
			if ((Integer.parseInt(ele[0])<=31)&&(Integer.parseInt(ele[1])<=12)) {
				System.out.println(date +"is correct");
			}else
			{
				System.out.println("wrong date");
			}
		}
		else
		{
			System.out.println(date+"is not correct");
		}
	}
}