class StringBufferExample
{
	public static void main(String[] args) {
		StringBuffer buffer=new StringBuffer(10);
		System.out.println("Len :"+buffer.length());
		System.out.println("cap :"+buffer.capacity());

	}
}