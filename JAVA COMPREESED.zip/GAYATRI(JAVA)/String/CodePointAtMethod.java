// class CodePointAtMethod
// {
// 	String a;
// 	public static void main(String[] args) {
// 		CodePointAtMethod ab=new CodePointAtMethod();
// 		ab.a="ABCDEFGHI";
//               for (int i=0;i<ab.a.length() ;i++ ) {
//                      System.out.println(ab.codePointAt(i));
//               }
// 	}
// 	public int codePointAt(int indx)
// 	{
//        char ch=' ';
       
//        	 try{
//        	 	ch=a.charAt(indx);
       	 	
//        	 }	
//        	 catch(StringIndexOutOfBoundsException abc){
//        	 	System.out.println("Incorrect Indx");
//        	 }
//        return (int)ch;

// 	}
// }

// class CodePointAtMethod
// {
//        public static void main(String[] args) {
//               String a="ABCDEFGHIJKLM";
//               System.out.println(a);
//               for (int i=0;i<a.length() ;i++ ) {
//                      System.out.println(a.codePointAt(i));
//               }
//        }
// }


class CodePointAtMethod
{ 
       static String a;
       public static void main(String[] args) {
              CodePointAtMethod ab=new CodePointAtMethod();
              ab.a="ABCD";
             for (int i=0;i<a.length() ;i++ ) {
                  System.out.println(ab.codePointAt(i));  
             }
       }
       public int codePointAt(int index)
       {
          char ch=' ';

          try
          {
              ch=a.charAt(index);
          }catch(StringIndexOutOfBoundsException abbb)
          {
              System.out.println("Invalid index");
          }
          return (int)ch;
       }
}
















