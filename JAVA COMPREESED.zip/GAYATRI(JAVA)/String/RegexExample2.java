import java.util.regex.*;
class RegexExample2
{
   public static void main(String[] args) 
   {
   	 String a="Ramesh is an Enginner and ramesh has completing his mechanical enginnering.Ramesh lives in Pune.";
   	 String b="ramesh";
   	 // String c=b.toLowerCase();
   	 Pattern p=Pattern.compile(b);
   	 Matcher m=p.matcher(a.toLowerCase());
     int count=0;
   	 while(m.find() ) {
   	 	count++;
  	 System.out.println(m.start()+"...."+m.end()+"...."+m.group());

   	 }
     System.out.println(count);
   }
}