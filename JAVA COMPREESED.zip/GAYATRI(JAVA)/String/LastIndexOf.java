class LastIndexOf
{
	public static void main(String[] args) {
		System.out.println("ABCDEFGHIJ".lastIndexOf("A"));//0
		System.out.println("ABCDEFGHIJ".lastIndexOf("I"));//8
		System.out.println("ABCDEFGHIJ".lastIndexOf("J"));//9
		System.out.println("ABCDEFGHIJ".lastIndexOf("CDE"));//2
		System.out.println("ABCDEFGHIJ".lastIndexOf("CCC"));//-1
		System.out.println("ABCDEFGHIJ".lastIndexOf("DD"));//-1
		System.out.println("ABCDEFGHIJ".lastIndexOf("D"));//3
		System.out.println("ABCDEFGHIJ".lastIndexOf("A"));//0
		System.out.println("ABCDEFGHIJ".lastIndexOf("I"));//8
		System.out.println("ABCDEFGHIJ".lastIndexOf("J"));//9
		System.out.println("ABCDEFGHIJ".lastIndexOf(65));//0
		System.out.println("ABCDEFGHIJ".lastIndexOf(67));//2
		System.out.println("ABCDEFGHIJ".lastIndexOf(68));//3
		System.out.println("ABCDEFGHIJ".lastIndexOf(70));//5
		System.out.println("ABCDEFGHIJ".lastIndexOf("A",1));//-1
		System.out.println("ABCDEFGHIJ".lastIndexOf("A",3));//-1
		System.out.println("ABCDEFGHIJ".lastIndexOf(68,4));//-1
	}
}