import java.util.regex.*;
class RemoveSpecialChar
{
	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("RA@M#ES&H$");
		String str=sb.toString();
		System.out.println(str);
		String rev="";

		Pattern p=Pattern.compile("[^a-zA-A0-9]");
		Matcher m=p.matcher(str);
		int k=0;
		int i=0;
		while(m.find())
		{
			k=m.start()-i;
			sb.delete(k,k+1);
			i++;
		}
		System.out.println(sb);
	}
}