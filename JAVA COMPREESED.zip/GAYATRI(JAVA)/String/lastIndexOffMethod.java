class lastIndexOffMethod
{
	static String a="ABCDEFGH";
	public static void main(String[] args) 
	{

	  lastIndexOffMethod obj=new lastIndexOffMethod();
	 
	  System.out.println(obj.indexOffMethod("H"));

	}
	public int indexOffMethod(String ch)
	{
      int index=-1;
      
      for (int i=0;i<a.length()-1;i++) 
      {
      	if ((a.charAt(i))==(ch.charAt(0))) 
      	{
      		index=i;
      		for (int j=1;j<ch.length()-1 ;j++ ) 
      		{
      			if ((ch.charAt(j))!=(a.charAt(i+j))) 
      				index=-1;
      				break;
      		}
      	}
      }
      return index;
	}
}