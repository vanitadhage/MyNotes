class EqualsMethod
{
	String a;
	public static void main(String[] args) {
		EqualsMethod ab=new EqualsMethod();
		 ab.a="Hello";
		String b="Hello";
		System.out.println(ab.equal(b));
	}
	public boolean equal(String anthr)
	{
		if (a==anthr) {
			return true;
		}
		else{
			return false;
		}
	}
}