// class EqualsIgnoreCase
// {
// 	static String a="Hello";
// 	static String b="heLLo";
// 	public static void main(String[] args) {
// 		EqualsIgnoreCase ab=new EqualsIgnoreCase();
// 		boolean b=ab.equalsIgnoreCase();
// 		System.out.println(b);
		
// 	}
// 	public boolean equalsIgnoreCase()
// 	{
// 		String s1=a.toLowerCase();
// 		String s2=b.toLowerCase();

//        if (s1.equals(s2)) {
//        	return true;
//        }
//        else{
//        	return false;
//        }
// 	}

// }



class EqualsIgnorecase
{
	 String a="HeLLO";
	 String b="hello";
	public static void main(String[] args) {
		EqualsIgnorecase ab=new EqualsIgnorecase();
		boolean c=ab.equalsIgnoreCase();
		System.out.println(c);
	}
	public boolean equalsIgnoreCase()
	{
		String str1=a.toUpperCase();
		String str2=b.toUpperCase();

		if (str1.equals(str2)) {                                                
			return true;
		}
		else{
			return false;
		}
	}
}