
class PalindromeCommandLine
{
	public static void main(String[] args) 
	{
	  String i=args[0];
      StringBuffer buffer=new StringBuffer(i);
       buffer.reverse();
       if (i.equals(buffer)) {
       	System.out.println("Palindrome");
       }else{
       	System.out.println("Not Palindrome");
       }
	}
}