class PalindromeStr
{
	public static void main(String[] args) {
		String a="naman";
		String rev="";
		for (int i=a.length()-1;i>=0 ;i-- ) {
			rev=rev+a.charAt(i);
		}
		if (a.equals(rev)) {
			System.out.println("Palindrome");
		}else{
			System.out.println("Not Palindrome");
		}
	}
}