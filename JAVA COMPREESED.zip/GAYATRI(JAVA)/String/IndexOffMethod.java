class IndexOffMethod
{
	static String a="ABCDEFGH";
	public static void main(String[] args) 
	{

	  IndexOffMethod obj=new IndexOffMethod();
	 
	  System.out.println(obj.indexOffMethod("B"));

	}
	public int indexOffMethod(String ch)
	{
      int index=-1;
      
      for (int i=0;i<a.length();i++) 
      {
      	if ((a.charAt(i))==(ch.charAt(0))) 
      	{
      		index=i;
      		for (int j=1;j<ch.length() ;j++ ) 
      		{
      			if ((ch.charAt(j))!=(a.charAt(i+j))) 
      				index=-1;
      				break;
      		}
      	}
      }
      return index;
	}
}