
class AsciiValueWithChar1
{
  public static void main(String[] args) 
  {
      for (int i=65;i<=90;i++) 
      {
       System.out.print((char)i+":"+i+"   ");
      }
   }
}