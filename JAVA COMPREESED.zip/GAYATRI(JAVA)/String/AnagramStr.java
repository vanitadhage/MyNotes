import java.util.*;
class AnagramStr
{
	public static void main(String[] args) 
	{
		String str1="form";
		String str2="morf";

            char[]a1=str1.toCharArray();
			char[]a2=str2.toCharArray();

			Arrays.sort(a1);
            Arrays.sort(a2);

		if (str1.length()!=str2.length()) 
		{
			System.out.println("both string Not Anagram");
		}
		else
		{
			boolean d=true;
			for (int i=0;i<a1.length ;i++ ) {
				if (a1[i]==a2[i]) {
					continue;
				}
				else
				{
					d=false;
					break;
				}
			}
			System.out.println(d?"Anagram":"Not Anagram");
		}
	
	   
	}
}