// class LengthProgram
// {
//   public static void main(String[] args) 
//   {
//   	String a="Something";
//   	System.out.println(a.length());
//   	int length=findlength(a);
//   	System.out.println(length);
//   }
//   public static int findlength(String str)
//   {
//   	int length=0;
//   	for (int i=0; ;i++ ) 
//   	{
//   	  try{
//   	  	str.charAt(i);
//   	  	length++;
//   	  }	catch(StringIndexOutOfBoundsException aiobe){
//   	  	break;
//   	  }
//   	}
//   	return length;
//   }
// }

class LengthProgram
{
  public static void main(String[] args) {
    String a="rajnandini";
    int length=lengthMethod(a);
    System.out.println(length);

  }
  public static int lengthMethod(String abc)
  {
      int count=0;
      for (int i=0; ;i++ ) {
        try{
           abc.charAt(i);
           count++;
        }catch(StringIndexOutOfBoundsException abc)
        {
         break;
        }
      }
      return count;
  }
}