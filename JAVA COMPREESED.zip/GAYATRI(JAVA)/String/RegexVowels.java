// WAJP TO FIND VOWELS FROM GIVEN STRING
import java.util.regex.*;
class RegexVowels
{
	public static void main(String[] args) {
		String a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String b=a.toLowerCase();
		Pattern pt=Pattern.compile("[aeiou]");
		Matcher mt=pt.matcher(b);
		while(mt.find())
		{
           System.out.println(mt.start()+"-"+mt.group());
		}
	}
}