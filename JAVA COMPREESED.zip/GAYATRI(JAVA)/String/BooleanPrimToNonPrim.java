// class BooleanPrimToNonPrim
// {
// 	public static void main(String[] args) {
// 		boolean b=true;
// 		Boolean ab=b;
// 		System.out.println(ab);
// 		Boolean bc=Boolean.valueOf(b);
// 		System.out.println(bc);
// 		Boolean cd=new Boolean(b);
// 		System.out.println(cd);//Warning : [removal] Boolean(boolean) in Boolean has been deprecated and marked for removal
// 	    Boolean de=(Boolean)b;
// 	    System.out.println(de);
// 	}
// }

