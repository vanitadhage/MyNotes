class ToUpperCase
{ 
	static String a="GayaTri";
	public static void main(String[] args) 
	{ 
		ToUpperCase ab=new ToUpperCase();
		String b=ab.toUpperCase();
	  	System.out.println(b);
	}
	public String toUpperCase()
	{
		String newstr=" ";
		for (int i=0;i<a.length() ;i++ ) {
			char ch=a.charAt(i);
			if (ch>=97 && ch<=122) {
				newstr+=(char)(ch-32);
			}else{
				newstr+=ch;
			}
		}
		return newstr;
	}
}



// class ToUpperCase
// {
// 	public static void main(String[] args) {
// 		System.out.println("Ramesh".toUpperCase());
// 		System.out.println("RaMEsh".toUpperCase());
// 		System.out.println("RAMESH".toUpperCase());
// 		System.out.println("R@Mesh".toUpperCase());
// 		System.out.println("ramesh".toUpperCase());

// 	}
// }