class StringProgram
{ 
  public static void main(String[] args)
  {
    String in="a";
    String in1="z";
    for(int i=0;i<in1;i++)
    {
     System.out.println(i);
    }
  }
}