// import java.util.regex.*;
// class Example1
// {
//    public static void main(String[] args) 
//    {
//    	 String a="Hello Ramesh,How are you ramesh.Ramesh Lives in Pune.";
//    	 String b="ramesh";
//    	 Pattern p=Pattern.compile(b);
//    	 Matcher m=p.matcher(a.toLowerCase());
//    	 while(m.find()) 
//      {
//   	 System.out.println(m.group());
//    	 }
//    }
// }

import java.util.regex.*;
class Example1
{
   public static void main(String[] args) 
   {
     String a="Hello Ramesh,How are you ramesh.Ramesh Lives in Pune.";
     String b="e";
     Pattern p=Pattern.compile(b);
     Matcher m=p.matcher(a.toLowerCase());
     while(m.find()) 
     {
     System.out.println(m.start()+"-"+m.group());
     }
     System.out.println(a);
   }
}