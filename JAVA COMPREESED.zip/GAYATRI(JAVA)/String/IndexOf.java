class IndexOf
{
	public static void main(String[] args) {
		System.out.println("ABCDEFGHIJ".indexOf("A"));//0
		System.out.println("ABCDEFGHIJ".indexOf("I"));//8
		System.out.println("ABCDEFGHIJ".indexOf("J"));//9
		System.out.println("ABCDEFGHIJ".indexOf("CDE"));//2
		System.out.println("ABCDEFGHIJ".indexOf("CCC"));//-1
		System.out.println("ABCDEFGHIJ".indexOf("DD"));//-1
		System.out.println("ABCDEFGHIJ".indexOf("D"));//3
		// System.out.println("ABCDEFGHIJ".indexOf("A"));//0
		// System.out.println("ABCDEFGHIJ".indexOf("I"));//8
		// System.out.println("ABCDEFGHIJ".indexOf("J"));//9
		System.out.println("ABCDEFGHIJ".indexOf(65));//0
		System.out.println("ABCDEFGHIJ".indexOf(67));//2
		System.out.println("ABCDEFGHIJ".indexOf(68));//3
		System.out.println("ABCDEFGHIJ".indexOf(70));//5
		System.out.println("ABCDEFGHIJ".indexOf("A",1));//-1
		System.out.println("ABCDEFGHIJ".indexOf("A",3));//-1
		System.out.println("ABCDEFGHIJ".indexOf(68,4));//-1


	}
}