class CodePointCount
{
	static String ab="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static void main(String[] args) {
		CodePointCount a=new CodePointCount();
		System.out.println(ab.codePointCount(0,5));
		System.out.println(ab.codePointCount(0,ab.length()));
		System.out.println(ab.codePointCount(0,0));
		System.out.println(ab.codePointCount(1,5));
		System.out.println(ab.codePointCount(2,1));
	}
	public int codePointCount(int start,int end)
	{
		int count=0;
		if (start>=0 && end<=ab.length() && start<=end) {
			return end-start;

		}else{
			throw new StringIndexOutOfBoundsException("Invalid index");
		}
	}
}
































// class CodePointCount
// {
// 	public static void main(String[] args) {
// 		String a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
// 		System.out.println(a.codePointCount(0,5));
// 		System.out.println(a.codePointCount(0,a.length()));
// 		System.out.println(a.codePointCount(0,0));
// 		System.out.println(a.codePointCount(2,1));
        
// 	}
// }