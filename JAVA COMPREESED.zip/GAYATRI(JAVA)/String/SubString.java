class SubString
{
	public static void main(String[] args) {
		String a="Rajnandini";
        SubString obj=new SubString();
        System.out.println(obj.subStringMethod(3));
		
	}
	public String subStringMethod()
	{
		// int indx=3;
		for (int i=0;i<a.length() ;i++ ) {
			if (a.charAt(i)) {
				
			}
	}
}