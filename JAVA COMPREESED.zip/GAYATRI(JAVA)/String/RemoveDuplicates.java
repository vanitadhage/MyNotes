class RemoveDuplicates
{
	public static void main(String[] args) {
		String a=("aabcdd");
		StringBuffer sb=new StringBuffer(a);

		for (int i=0;i<sb.length() ;i++ ) {
			for (int j=i+1;j<sb.length() ;j++ ) {
				if (sb.charAt(i)==sb.charAt(j)) {
					sb.delete(j,i+1);
				}
			}
		}
		a=new String(sb);
		System.out.println(a);
	}
}