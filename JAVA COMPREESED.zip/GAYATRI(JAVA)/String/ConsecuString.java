import java.util.*;
class ConsecuString
{
  public static void main(String []args)
  {
   
   Pattern pt=Pattern.compile("ababbaaacbb");
   Matcher mt=pt.matcher("a");
   while(mt.find())
   {
    System.out.println(mt.start()+"-"+mt.group());
   }
   
  }
}