class PatternProgram
 {
  public static void main(String[] args) 
   {
     int a=15;
     int b=5;
     for (int i=1;i<=b ;i++) 
     {
        int j=b;
       for ( j=b;j>1;j--)
       {

	System.out.print(a+" ");
       }
	b--;
     }
	System.out.println();
  }
}