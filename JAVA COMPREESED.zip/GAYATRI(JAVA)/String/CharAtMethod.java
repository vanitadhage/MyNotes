class CharAtMethod
{
	String str;
	public static void main(String[] args) throws InterruptedException {
		CharAtMethod a =new CharAtMethod();
		 a.str="Something";
		 for (int i=0;i<a.str.length() ;i++ ) {
		 	Thread.sleep(2000);
		 	System.out.println(a.charAt(i));
		 }
	}
	public char charAt(int indx)
	{
		char []ch=str.toCharArray();
		try
		{
			return ch[indx];
		}catch(ArrayIndexOutOfBoundsException a)
		{
			System.out.println("U have entered invalid index");
		}
		return ' ';
	}
}


// class  CharAtMethod
// {
// 	public static void main(String[] args) {
// 		String a="Gayatri";
// 		for (int i=0;i<a.length() ;i++ ) {
// 			System.out.println(a.charAt(i));
// 		}
// 	}
// }