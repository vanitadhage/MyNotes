// class TrimMethod
// {
// 	public static void main(String[] args) {
// 		String a=" Gayatri";
// 		System.out.println(a);
// 		System.out.println(a.length());
// 		a=a.trim();
// 		System.out.println(a);
// 		System.out.println(a.length());
// 	}
// }


class TrimMethod
{ 
	static String a=" Gayatri ";
	public static void main(String[] args) {
		 
	 TrimMethod obj=new TrimMethod();
	 System.out.println((obj.trimMethod()).length());
     // System.out.println(obj);
	}
	public String trimMethod()
	{
      String b="";
      char spc=' ';
      int indx=0;

      for (int i=0;i<a.length();i++ ) {
      	char ch=a.charAt(i);
      	if (ch!=spc) {
      		indx=i;
      		break;
      	}
      	
      }
      b=a.substring(indx);
      int ind=0;
      for (int i=b.length()-1;i>=0 ;i-- ) {
      	char ch=b.charAt(i);
      	if (ch!=spc)
      	 {
      	   ind=i;
      	   break;	
      	}
      }
      b=b.substring(0,ind+1);
      return b;
	}
}