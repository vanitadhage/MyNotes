class EndsWithMethod
{
	static String a;
	public static void main(String[] args) {
		a="RAMESH";
		String srch="H";
		EndsWithMethod obj=new EndsWithMethod();
		// System.out.println(obj.endsWith(srch));
		System.out.println(obj.endsWith(srch));
	}
	public boolean endsWith(String srch)
	{
		if (srch.length()>a.length()) {
			return false;
		}
		int indx1=(a.length()-1);
		int indx2=(srch.length()-1);
		while(indx2>=0)
		{
			char textChar=a.charAt(indx1);
			char srchChar=srch.charAt(indx2);
			if (textChar!=srchChar) {
				return false;			
			}
			indx1--;
		    indx2--;
		}
		return true;
	}
	
}

















// int index=0;
// 		int count;
// 		int endStrChar;
		
// 		for (int i=0;i<srch.length();i++ ) {
// 			endStrChar=0;
// 			if ((srch.charAt(i))>='A' && (srch.charAt(i)<='Z')||(srch.charAt(i)>='a') &&(srch.charAt(i)<='z')||i==srch.length()-1) {
// 				if (i==srch.length()-1) {
// 					endStrChar=1;
// 				}
// 				count=0;
// 				for (int j=0;j+endStrChar< end.length()&&i>end.length();j++ ) {
// 					if (srch.charAt(i-end.length()+j+endStrChar)==end.charAt(j)) {
// 						count=1;
// 					}else{
// 						count=0;
// 					}
// 				}
// 				index+=count;
// 			}
// 		}
		// return index;