class BooleanNonPrimToPrim
{
	public static void main(String[] args) {
		Boolean b=true;
		boolean ab=b;
		System.out.println(ab);
		boolean bc=b.booleanValue();
		System.out.println(bc);
		boolean cd=new Boolean(b);
		System.out.println(cd);//Warning : [removal] Boolean(boolean) in Boolean has been deprecated and marked for removal
	    boolean de=(boolean)b;
	    System.out.println(de);
	}
}