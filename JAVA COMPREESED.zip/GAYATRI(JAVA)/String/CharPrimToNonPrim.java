// class CharPrimToNonPrim
// {
// 	public static void main(String[] args) {
// 		char b='a';
// 		Character ab=b;
// 		System.out.println(ab);
// 		Character bc=Character.valueOf(b);
// 		System.out.println(bc);
// 		Character cd=new Character(b);
// 		System.out.println(cd);// warning: [removal] Character(char) in Character has been deprecated and marked for removal
// 	    Character de=(Character)b;
// 	    System.out.println(de);
// 	 }
// }

