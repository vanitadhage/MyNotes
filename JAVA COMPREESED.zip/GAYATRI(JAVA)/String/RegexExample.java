import java.util.regex.*;
class RegexExample
{
  public static void main(String[] args) {
  	Pattern p=Pattern.compile("a");
    Matcher m=p.matcher("Gayatri");
  while(m.find())
  {
  	System.out.println(m.start()+"...."+m.group());
  }
  }
}