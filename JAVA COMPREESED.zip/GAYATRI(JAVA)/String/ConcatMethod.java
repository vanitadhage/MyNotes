class ConcatMethod
{
	public static void main(String[] args) {
		String str1="Gayatri ";
		String str2="Pawar ";
		System.out.println(str1+str2);
		// System.out.println(str1.concat(str2));
	}
}