class CharNonPrimToPrim
{
	public static void main(String[] args) {
		Character b='a';
		char ab=b;
		System.out.println(ab);
		char bc=b.charValue();
		System.out.println(bc);
		char cd=new Character(b);
		System.out.println(cd);// warning: [removal] Character(char) in Character has been deprecated and marked for removal
	    char de=(char)b;
	    System.out.println(de);
	 }
}