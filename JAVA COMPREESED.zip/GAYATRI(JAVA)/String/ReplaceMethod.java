class ReplaceMethod
{

	static String a="Hello How are you";
	public static void main(String[] args) 
	{ 
	  	ReplaceMethod obj=new ReplaceMethod();
	  	System.out.println(obj.replaceMethod(a));
	}
	public String replaceMethod(String str)
	{
       
	}
}