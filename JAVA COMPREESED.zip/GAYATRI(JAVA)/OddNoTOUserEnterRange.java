import java.util.Scanner;
class OddNoTOUserEnterRange
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a start number :");
		int sno=sc.nextInt();
		System.out.print("Enter a end number :");
		int eno=sc.nextInt();

		for (int i=sno;i<=eno ;i+=2 ) {
			System.out.print(i + "  ");
		}
	}
}