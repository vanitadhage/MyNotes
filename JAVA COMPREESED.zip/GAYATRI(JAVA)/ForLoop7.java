class ForLoop7
{
	public static void main(String[] args) {
		final boolean a=true;
		for (;a ; ) {
			System.out.println("hello");
			
		}
		System.out.println("byee");
	}
}