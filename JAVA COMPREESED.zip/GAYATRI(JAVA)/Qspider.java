class Qspider
{
 public static void main(String [] args)
 {
  byte staff=25;
  byte classroom=10;
  byte javaTrainer=3;
  byte Subjects=8;
  byte ac=40;
  System.out.println("No of staff :"+staff);
  System.out.println("No of classroom :"+classroom);
  System.out.println("No of javaTrainer :"+javaTrainer);
  System.out.println("No of Subjects :"+Subjects);
  System.out.println("No of ac :"+ac);
 }
}