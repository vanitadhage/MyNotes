import java.util.*;
class ArrayPrimeNum
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int nm=sc.nextInt();
		
		int[] primeNumber=isprime(nm);
		System.out.println(Arrays.toString(primeNumber));
		
	}
	public static int[] isprime(int nm)
	{
		int []primeArray=new int[nm];
       int count=0;
       for (int i=3;true ;i++ ) 
       {
       	int cnt=0;
       	for (int j=2;j<i ;j++ ) 
       	{
       		if (i%j==0) 
       		{
       		cnt++;
       		break;
       	    }
       	}
       	    if (cnt==0) 
       	    {
       		primeArray[count++]=i;
       		if (count==nm) 
       		{
       			break;
       		}
       	 }
       }
       return primeArray;
	}
}