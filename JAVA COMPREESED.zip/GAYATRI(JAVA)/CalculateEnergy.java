import java.util.Scanner;
class CalculateEnergy
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a amount of water in kg :");
		double m=sc.nextDouble();
		System.out.print("Enter a initial temperature :");
		double initialTemperature=sc.nextDouble();
		System.out.print("Enter a final temperature :");
		double finalTemperature=sc.nextDouble();
		double q=m*(finalTemperature-initialTemperature)*4184;
		System.out.println("The energy needed is :"+q);

	}
}