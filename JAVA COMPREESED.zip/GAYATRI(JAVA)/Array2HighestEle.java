class Array2HighestEle
{
	public static void main(String[] args) {

         int max=0;
		 int []arr={122,543,712,123,999,432,1000};
         
		 for (int i=0;i<arr.length ;i++ ) {
		 	for (int j=0;j<arr.length ;j++ ) {
		 		if (arr[i]<arr[j]) {
		 			max=arr[i];
                    arr[i]=arr[j];
                    arr[j]=max;
		 		}
		 	}
		 }
		 System.out.println(max);
	}
}