class SwitchExample8
{
	public static void main(String[] args) 
	{
	   byte a = 7;
	   final byte b = 4;
	   switch(a)
	   {
	   	case 1:System.out.println("case 1");break;
	   	       
	   	case 2:System.out.println("case 2");break;
	   	      
	   	case 3:System.out.println("case 3");break;

	   	case b:System.out.println("case 3");break;
	   	       
	   	default:System.out.println("From default ");
	   }	
	}
}