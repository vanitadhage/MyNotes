class Parent{}
class Child1 extends Parent{}
class SubChild1 extends Child1{}
class SubChild2 extends Child1{}
class Child2 extends Parent{}
class SubChild3 extends Child2{}
class SubChild4 extends Child2{}
class DriverDownCasting
{
  public static void main(String[] args) {
      Parent a=new Child2();
      // SubChild3 b=(SubChild3)a;
      // Child2 b=(SubChild1)a;
      SubChild1 b=(SubChild1)a;


  	// Child1 a=new SubChild1();
  	// SubChild1 b=(SubChild2)a;
  	// Child1 b=(SubChild2)a;
  	// Parent b=(Child1)a;
      

  	// Parent a=new Child1();
  	// Parent b=(SubChild1)a;
  	// Child1 b=(SubChild1)a;
  	// SubChild1 c=(Child1)a;
  	// Child1 b=(Child1)a;
  }
}