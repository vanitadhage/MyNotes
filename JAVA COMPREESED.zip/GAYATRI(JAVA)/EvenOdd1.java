import java.util.Scanner;
class EvenOdd1
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		String op=(num%2==0)?"EVEN":"ODD";

		System.out.println(op);
	}
}