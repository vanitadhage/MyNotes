import java.util.Scanner;
class VowelsConsonent1
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter your name:");
		char ch=sc.next().charAt(0);
		String op=(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')?"Vowel":"Consonent";
		System.out.println(" charater '"+ch+"' is a  "+op);

	}
}