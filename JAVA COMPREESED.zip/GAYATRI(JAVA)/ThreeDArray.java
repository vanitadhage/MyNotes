import java.util.*;
class ThreeDArray
{
   public static void main(String[] args) {
   	// 1String
   	// String [][][]arr={{{"a","b","c","d"}},{{"e"},{"f"}},{{"i"},{"j","k"},{"l","m","n"}}};

   	// for (int i=0;i<arr.length ;i++ ) 
   	// {
   	// 	for (int j=0;j<arr[i].length ;j++ ) 
   	// 	{
   	// 		for (int k=0;k<arr[i][j].length ;k++ ) 
   	// 		{
   	// 			System.out.print(arr[i][j][k]+"  ");
   	// 		}
   	// 		System.out.println();
   	// 	}
   	// 	System.out.println();
   	// }
   	// System.out.println();


    // 2 char
   	// char [][][]arr={{{'a','b','c','d'}},{{'e'},{'f'}},{{'i'},{'j','k'},{'l','m','n'}}};

    // int i=0;
    // while(i<arr.length)
    // {
    // 	int j=0;
    // 	while(j<arr[i].length)
    // 	{
    //        int k=0;
    //        while(k<arr[i][j].length)
    //        {
    //          System.out.print(arr[i][j][k]+" ");
    //          k++;
    //        }
    //        j++;
    //        System.out.println();
    // 	}
    // 	i++;
    // 	System.out.println();
    // }
    
     // 3 double
   	 // double [][][]arr={{{100},{200,300,400}},{{500},{600},{700}}};
   	 // int i=0;
   	 // do{
   	 // 	int j=0;
   	 // 	do{
   	 // 		int k=0;
   	 // 		do{
   	 // 			System.out.print(arr[i][j][k]+" ");
   	 // 			k++;

   	 // 		}while(k<arr[i][j].length);
   	 // 		System.out.println();
   	 // 		j++;
   	 // 	}while(j<arr[i].length);
   	 // 	System.out.println();
     //   i++;
   	 // }while(i<arr.length);
   	 // System.out.println();

   	// 4 foreach
   	 // String [][][]arr={{{"a","b","c","d"}},{{"e"},{"f"}},{{"i"},{"j","k"},{"l","m","n"}}};
     // for (String [][]i :arr ) {
     // 	for (String[]j :i ) {
     // 		for (String k :j ) {
     // 			System.out.print(k+" ");
     // 		}
     // 		System.out.println();
     // 	}
     // 	System.out.println();
     // }

       // 5 deepToString
   	// String [][][]arr={{{"a","b","c","d"}},{{"e"},{"f"}},{{"i"},{"j","k"},{"l","m","n"}}};
   	// System.out.print(Arrays.deepToString(arr));

   	  // 6 toString
   	

     char [][][]arr={{{'l','m'},{'n','o'},{'p','q','r'}}};
     for (char [][]ch1 :arr ) {
     	System.out.print(Arrays.toString(ch1));
     }

   }
}