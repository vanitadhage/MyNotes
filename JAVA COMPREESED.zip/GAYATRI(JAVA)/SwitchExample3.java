class SwitchExample3
{
	public static void main(String[] args) 
	{
	   boolean a = true;
	   switch(a)
	   {
	   	case true:System.out.println("case 1");break;
	   	       
	   	case false:System.out.println("case 2");break;
	   	       
	   	default:System.out.println("From default ");
	   }	
	}
}