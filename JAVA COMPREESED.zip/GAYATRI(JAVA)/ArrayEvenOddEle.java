import java.util.*;
class ArrayEvenOddEle
{
	public static void main(String[] args) 
	{
		int []arr={2,3,4,5,6,7,8,9};
		int evencnt=0;
		int oddcnt=0;
		for (int num :arr ) {
			if (num%2==0) {
				evencnt++;
			}
			else{
				oddcnt++;
			}
		}
		int [] evenArray= new int [evencnt];
		int evenindx=0;
		int [] oddArray= new int [oddcnt];
        int oddindx=0;

        for (int num :arr ) {
        	if (num%2==0) {
        		evenArray[evenindx++]=num;
        	}
        	else{
        		oddArray[oddindx++]=num;
        	}
        }
		// int [] oddNumber=oddNum(arr);
		System.out.println(Arrays.toString(arr));
		System.out.println(Arrays.toString(evenArray));
		System.out.println(Arrays.toString(oddArray));

	}
}