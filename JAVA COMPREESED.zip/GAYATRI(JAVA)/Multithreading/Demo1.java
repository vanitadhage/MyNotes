class Demo1
{
	public static void main(String[] args) 
	{
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		Add ad=new Add(num1,num2);
		ad.start();
		Sub sb=new Sub(num1,num2);
		sb.start();
		Mul mu=new Mul(num1,num2);
		mu.start();
		Div dv=new Div(num1,num2);
		dv.start();
		Mod mo=new Mod(num1,num2);
		mo.start();
	}
}
class Add extends Thread
{
	int num1;
	int num2;
	Add(int num1,int num2)
   {
      this.num1=num1;
      this.num2=num2;
   }
	public void run()
	{
      System.out.println("Addition :"+(num1+num2));
	}
   
}
class Sub extends Thread
{
  int num1;
  int num2;
  Sub(int num1,int num2)
  {
  	this.num1=num1;
  	this.num2=num2;
  }
  public void run()
  {
  	System.out.println("Subtraction :"+(num1-num2));
  }
}
class Mul extends Thread
{
  int num1;
  int num2;
  Mul(int num1,int num2)
  {
  	this.num1=num1;
  	this.num2=num2;
  }
  public void run()
  {
  	System.out.println("Multiplication :"+(num1*num2));
  }
}
class Div extends Thread
{
  int num1;
  int num2;
  Div(int num1,int num2)
  {
  	this.num1=num1;
  	this.num2=num2;
  }
  public void run()
  {
  	System.out.println("Division :"+(num1/num2));
  }
}
class Mod extends Thread
{
  int num1;
  int num2;
  Mod(int num1,int num2)
  {
  	this.num1=num1;
  	this.num2=num2;
  }
  public void run()
  {
  	System.out.println("Modulus :"+(num1%num2));
  }
}
