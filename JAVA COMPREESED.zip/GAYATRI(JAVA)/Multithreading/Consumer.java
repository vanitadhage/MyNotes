class Consumer
{
	public static void main(String[] args)throws InterruptedException
	 {
		Producer t1=new Producer();
		t1.start();
		t1.setName("Gayatri");
        // Thread.sleep(2000);//deadlock occur
		synchronized(t1)
		{
			t1.wait();//0ms,10ns(milisecond,nanosecond)
			System.out.println(t1.sum);
		}
	}
}
class Producer extends Thread
{
   int sum=0;
   public void run()
   {
    synchronized(this)
    {
    	for (int i=1;i<=500;i++ ) {
   		sum+=i;
   	 }
   	 this.notify();
    }
   }
}