class Demo
{
	public static void main(String[] args) {
		MyThread th=new MyThread();
		th.start();
		for (int i=1;i<=10 ;i++ ) {
			System.out.println(Thread.currentThread().getName()+"-"+i);
		}
	}
}
class MyThread extends Thread
{
   @Override
   public void run()
   {
   	Thread.currentThread().setName("Gayatri");
   	for (int i=1;i<=10 ;i++ ) {
   		System.out.println(Thread.currentThread().getName()+"-"+i);
   	}
   }
}

// ****************OUTPUT*************
// Gayatri-1
// main-1
// Gayatri-2
// main-2
// Gayatri-3
// main-3
// Gayatri-4
// main-4
// Gayatri-5
// main-5
// Gayatri-6
// main-6
// Gayatri-7
// main-7
// Gayatri-8
// main-8
// Gayatri-9
// main-9
// Gayatri-10
// main-10