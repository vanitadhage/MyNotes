class Instagram
{
	String name;
	String bio;
	int followers;
	Instagram(String name,String bio,int followers)
	{
     this.name=name;
     this.bio=bio;
     this.followers=followers;
	}

	Instagram(Instagram obj)
	{
     name=obj.name;
     bio=obj.bio;
     followers=obj.followers;
	}
	public String toString()
	{
		return("hi my name is"+this.name+"and i have"+this.followers+"followers");
	}
}
class InstagramDriver
{
	public static void main(String[] args) {
	Instagram mobile=new Instagram("Gayatri","goregous girl",1000);
	Instagram laptop=mobile;
	System.out.println(mobile);
	System.out.println(laptop);
	mobile.followers=1100;
	System.out.println(mobile);
	System.out.println(laptop);
    	
	}
}