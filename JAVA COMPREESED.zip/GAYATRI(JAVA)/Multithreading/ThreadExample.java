class ThreadExample
{
	public static void main(String[] args) {
		MyThread t1=new MyThread();
		t1.start();
		t1.run();
		System.out.println(Thread.currentThread().getName());
	}
}
class MyThread extends Thread{
	public void run()
	{
		System.out.println("Helloo");
	}
}