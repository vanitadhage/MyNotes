class CommandLineArray
{
	public static void main(String[] person) {
		for (String personName :person ) {
			System.out.println("Hi my name is "+personName);
		}
	}
}