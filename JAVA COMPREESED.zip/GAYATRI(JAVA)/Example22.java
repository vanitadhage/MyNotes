import java.util.Scanner;
class Example22
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
       // for (int i=2;i<=100 ;i++) 
       // {
       // 	if (i%2==0) 
       // 	{
       	       // System.out.print(i+" ");
       // 	}
       	 
       // }

  //       int i=1;
		// for ( ; i<=100;i+=2 ) {
		// 	System.out.print(i+"  ");
		// }

  //       int i=3 ;
		// while(i<=50)
		// {
		// 	System.out.print(i+" ");
		// 	i+=2;
		// }	


		// int i=1;
		// do{
		// 	System.out.print(i+" ");
		// 	i++;
		// 	}while(i<=100);

		// int num=12;
		// int i=1;
		// while(i<=10)
		// {
		// 	System.out.println(num*i);
		// 	i++;
		// }	

		// int i=1;
		// int num=16;
		// do{
		// 	System.out.println(num*i);
		// 	i++;
		// }while(i<=10);


  //       int num=15;
		// for (int i=1;i<=10 ;i++) {
		// 	System.out.println(num*i);

		// }

		// for (int i=100;i>=1 ;i-- )
		// {
		// 	System.out.print(i+" ");
		// }

        // for (int i=200;i>=2 ;i-- ) {
        // 	if (i%2==0) {
        // 		System.out.print(i+" ");
        // 	}
        // }


         // for (int i=200;i>=1 ; i--) {
         // 	if (i%2==1) {
         // 		System.out.print(i+"  ");
         // 	}
         // }

        
 //        System.out.println("Enter Percentage :");
 //        int num=sc.nextInt();
 //        if (num>60) {
 //        	System.out.println("Passed");
 //        }
 //        else{
 //        	System.out.println("Fail");
	// }



      }
}