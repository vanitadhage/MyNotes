class MethodOverloading
{
	public static void main(String[] args) {
		m1();
		m1(10);
		m1(10,20);
	}
	public static void m1()
	{
       System.out.println("No argument");
	}
	public static void m1(int a)
	{
		System.out.println("1 argument");
	}
	public static int m1(int a,int b)
	{
		// System.out.println("2 argument");
		return a+b;
	}

}