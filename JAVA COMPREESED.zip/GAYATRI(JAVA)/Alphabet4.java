class Alphabet4
{
	public static void main(String[] args) 
	{
		for (char i='A';i<='Z';i+=3 ) 
		{
			System.out.print(i +"  ");
		}
	}
}

