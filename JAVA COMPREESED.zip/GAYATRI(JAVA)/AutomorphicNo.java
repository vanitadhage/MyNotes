import java.util.Scanner;
class AutomorphicNo
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
		int dup=num;
		int sqr=num*num;
		int count=0;
		int div=1;

		while(dup>0)
		{
			count++;
			dup/=10;
		}
		for (int i=1;i<=count ;i++ ) 
		{
			div*=10;
		}
		if (num==(sqr%div)){
			System.out.println("Automorphic No");
		}
		else
		{
			System.out.println("Not an Automorphic No");
		}
		// System.out.println((num==(sqr%div))?"Automorphic No":"Not an Automorphic No");
	}
}