class RelationalOperator
{
	public static void main(String[] args) {
	 
	 System.out.println(10>12);//false
	 System.out.println(10>10);//false
	 System.out.println(10.01>10.00);//true
	 // System.out.println(true>false);//false
	 // System.out.println(true<false);//false
	 // System.out.println(true>=false);//false
	 System.out.println(10>=10);//true
	 System.out.println('a'!=97);//false
	 System.out.println('a'!='b');//true
	 System.out.println(1!=0);//true
	 System.out.println(0!=0);//false
	 System.out.println(2>0);//true
	 System.out.println(true==!false);//true
	 System.out.println(true!=false);//true
	 System.out.println(true!=true);//	false
	}
}c cv vc cv