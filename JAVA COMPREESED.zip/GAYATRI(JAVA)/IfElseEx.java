class IfElseEx
{
	public static void main(String[] args) {
		if (true) {
			System.out.print("hii");
		}
		else {
			System.out.println("byee");
		}
	}
}