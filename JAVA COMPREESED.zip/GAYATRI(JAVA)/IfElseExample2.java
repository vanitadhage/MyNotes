import java.util.Scanner;
class IfElseExample2
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a age :");
		int age=sc.nextInt();
		System.out.print("Enter a property :");
        int prop=sc.nextInt(); 
        System.out.print("Enter a surname:");
        String surname=sc.next();
       
		if (age>=21&&prop>=10000000||surname=="Ambani") 
		{
			System.out.println("The boy is eligible for marrrying his girlfriend");
		}
		else
		{
			System.out.println("The boy is not eligible for marrrying his girlfriend");
		}
	}
}
