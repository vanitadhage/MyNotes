import java.util.*;
 class ArrayCharater
 {
 	public static void main(String[] args) 
 	{
      char []arr={'A','D','M','I','N'};
    int i;
      for (  i=0;i<arr.length ;i++ ) 
      {
      	for (int j=i+1;j<arr.length ;j++ ) 
      	{
      		if (arr[i]>arr[j]) 
      		{
      		  char temp=arr[j];
      		  arr[j]=arr[i];
      		  arr[i]=temp;	
      		}
      	}
      }
      System.out.println(Arrays.toString(arr));
 		int count=0;
 		char indx1=arr[i];
 		char indx2=arr[arr.length-2];
 		for (char k=indx1;k<=indx2 ;k++ ) {
 			count++;
 		}
 		System.out.println("count :"+count);
 	}
 }