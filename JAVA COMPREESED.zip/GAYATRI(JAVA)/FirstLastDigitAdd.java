import java.util.Scanner;
class FirstLastDigitAdd
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();//123456
		int sum=0;
		int i=1;
		while(num!=0)
		{
			int rem=num%10;
			sum+=rem;
			num/=100000;
		}
		i++;
		System.out.println(sum);
	}
}