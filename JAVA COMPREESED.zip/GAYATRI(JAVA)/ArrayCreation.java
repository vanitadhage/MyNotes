class ArrayCreation
{
	public static void main(String[] args) 
	{
		int[]a; //a->1(one diamension array)

		int b[]; //b->1

		// []int c;         //CTE(illegal start of expression)

        int c[            ];  //c->1

        int[][]d; //d->2 (two diamension array)

        int [] e [];//e->2

        int [][] f,g;//f->2,g->2

        int []h[],i;//h->2,i->1

        int [][]j,k,l;//j->2,k->2,l->2

        int [][]m[],n,o[];//m->3,n->2,o->3

        // int []m,[]n=new int[10][];
        // System.out.print(n);
        int []p=new int[-1];
        System.out.print(p);

        

	}
}