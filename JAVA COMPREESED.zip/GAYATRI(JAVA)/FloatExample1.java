class FloatExample1
{
 public static void main(String [] args)
  {
   float waterTankWeight=65f;
   float waterTankDensity=0.22671f;
   float waterTankDiameter=977.5f;
   float waterTankHeight=610f;
   System.out.println("Water Tank Weight :"+waterTankWeight);
   System.out.println("Water Tank Density :"+waterTankDensity);
   System.out.println("water Tank Diameter :"+waterTankDiameter);
   System.out.println("water Tank Height :"+waterTankHeight);
  }
}