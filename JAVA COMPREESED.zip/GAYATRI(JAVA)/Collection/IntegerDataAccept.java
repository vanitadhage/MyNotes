import java.util.*;
class IntegerDataAccept
{
	public static void main(String[] args) {
		List l=new ArrayList();
		l.add(10);
		Byte b=20;
		l.add(b);
		l.add(30);
		l.add("40");
		l.add(50);
		l.add(false);
		l.add(new StringBuffer("70"));
		System.out.println(l);

		
		Iterator i=l.iterator();
		while(i.hasNext())
		{
			if (i.next() instanceof Integer) {
				
			}else
			{
				i.remove();
			}
		}
		System.out.println(l);
	}
}