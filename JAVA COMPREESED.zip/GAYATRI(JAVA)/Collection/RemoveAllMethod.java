import java.util.*;
class RemoveAllMethod
{
	public static void main(String[] args) 
	{
	  Collection a=new ArrayList();
	  for (int i=10;i<=100 ;i+=10 ) {
	  		a.add(i);
	  	}	
	  	System.out.println(a);
	  	Collection b=new ArrayList();
	  	b.add(null);
	  	b.add(10);
	  	b.add(null);
	  	// a.removeAll(null);
	  	System.out.println(a);
	  	try{
          a.removeAll(null);
	  	}catch(NullPointerException e)

	}
}