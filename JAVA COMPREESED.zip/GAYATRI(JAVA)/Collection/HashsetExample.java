import java.util.*;
class HashsetExample
{
	public static void main(String[] args) {
		HashSet<Integer> hset=new HashSet<>();
		for (int i=1;i<=10;i++) {
			hset.add(i);
		}
		System.out.println(hset);
	}
}


