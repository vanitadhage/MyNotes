import java.util.*;
class DequeMethods
{
	public static void main(String[] args) {
		Deque d=new ArrayDeque();
		d.offer(10);
		d.offer(20);
		d.offer(30);
		d.offer(40);
		d.offer(50);

		// d.addFirst(5);
		// System.out.println(d);

		// d.addLast(60);
		// System.out.println(d);

		// d.offerFirst(4);
		// System.out.println(d);
        
  //       d.offerLast(70);
		// System.out.println(d);

		d.removeFirst();
		System.out.println(d);
        
        d.removeLast();
		System.out.println(d);

		d.pollFirst();
		System.out.println(d);
        
        d.pollLast();
		System.out.println(d);

		
		System.out.println(d.getFirst());
		System.out.println(d.getLast());
        

        System.out.println(d.peekFirst());
		System.out.println(d.peekLast());

	}
}