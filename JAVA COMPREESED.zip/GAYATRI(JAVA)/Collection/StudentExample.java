import java.util.*;
class Student implements Comparable<Student>
{
	int id;
	String name;
	int yop;
	Student(int id,String name,int yop)
	{
		this.id=id;
		this.name=name;
		this.yop=yop;
	}
	public String toString()
	{
		return(this.id+"-"+this.name+"-"+this.yop);
	}
	// public int compareTo(Student std)
	// {
	// 	if (id==std.id) 
	// 	{
	// 		return 0;
	// 	}else if (id>std.id) 
	// 	{
	// 		return 1;
	// 	}
	// 	else
	// 	{
	// 		return -1;
	// 	}
	// }

	public int compareTo(Student std)
	{
		if (name.compareTo(std.name)==0) 
		{
			return 0;
		}else if (name.compareTo(std.name)>0) 
		{
			return 1;
		}
		else{
			return -1;
		}
	}

	// public int compareTo(Student std)
	// {
	// 	if (yop==std.yop) 
	// 	{
	// 		return 0;
	// 	}else if (yop>std.yop) 
	// 	{
	// 		return 1;
	// 	}
	// 	else
	// 	{
	// 		return -1;
	// 	}
	// }	
}
class StudentExample
{
	public static void main(String[] args) 
	{
		Set<Student> std=new HashSet<>();
										
		std.add(new Student(1,"Gayatri",2023));
		std.add(new Student(2,"Priti",2022));
		std.add(new Student(3,"Vanita",2025));
		std.add(new Student(4,"Mansi",2024));
		std.add(new Student(5,"Mahi",2021));
		System.out.println(std);

		List<Student> lst=new ArrayList<>(std);
		Collections.sort(lst);
		System.out.println(lst);

	}
}