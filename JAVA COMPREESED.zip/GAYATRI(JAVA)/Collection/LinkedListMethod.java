import java.util.*;
class LinkedListMethod
{
	public static void main(String[] args) {
		LinkedList<Integer> l=new LinkedList<>();
		for (int i=10;i<=50;i+=10 ) {
			l.add(i);
		}
		System.out.println(l);
		
		System.out.println(l.getFirst());

		System.out.println(l.getLast());

		// System.out.println(l);
	}
}