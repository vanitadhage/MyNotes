import java.util.*;
class QueueMethods
{
	public static void main(String[] args) {
		Queue q=new PriorityQueue();
		q.offer(10);
		q.offer(30);
		q.offer(20);
		// System.out.println(q);
		// q.offer(40);
		// System.out.println(q.add(50));
  //       System.out.println(q);
		// System.out.println(q.poll());//poll==remove 
		// System.out.println(q.remove());
		System.out.println(q.element());
		System.out.println(q.peek());

		
		

	}
}