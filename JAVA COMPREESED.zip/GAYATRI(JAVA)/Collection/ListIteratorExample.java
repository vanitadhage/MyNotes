import java.util.*;
class ListIteratorExample
{
	public static void main(String[] args) 
	{
		List list=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		System.out.println(list);
		List list2=new ArrayList(list);
		System.out.println(list2);

		ListIterator li=list2.listIterator();
		while(li.hasNext())
		{
			Integer ele =(Integer)li.next();
			if (ele%2==0) {
				
				li.set("Even");
			}
        }
        System.out.println(list2);
        while(li.hasPrevious())
        {
        	if (li.previous() instanceof Integer) 
        	{
        		li.set("Odd");
        	}
			
	    }
	System.out.println(list2);
        }
}