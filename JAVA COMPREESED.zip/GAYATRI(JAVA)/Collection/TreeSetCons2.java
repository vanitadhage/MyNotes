import java.util.*;
class TreeSetCons2
{
	public static void main(String[] args) {
		TreeSet ts=new TreeSet();
		ts.add(10);
		ts.add(20);
		System.out.println(ts);

		TreeSet ts1=new TreeSet(ts);
		System.out.println(ts1);
	}
}