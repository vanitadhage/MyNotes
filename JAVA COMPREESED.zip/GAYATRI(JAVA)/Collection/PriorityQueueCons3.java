import java.util.*;
class Info
{
	int id;
	String name;
	Info(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
   public String toString()
   {
   	return (this.id+"-"+this.name);
   }
}
class SortByDescending implements Comparator<Info>
{
     public int compare(Info i1,Info i2)
	{
		return i2.id-i1.id;
	}
}

class PriorityQueueCons3 
{
   public static void main(String[] args) {
   	 PriorityQueue<Info> pq=new PriorityQueue<>(new SortByDescending());
   	  pq.offer(new Info(1,"gayatri"));
   	  pq.offer(new Info(2,"vanita"));
   	  System.out.println(pq);

   }
}



