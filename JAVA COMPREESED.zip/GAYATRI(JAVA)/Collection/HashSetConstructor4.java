import java.util.*;
class HashSetConstructor4
{
	public static void main(String[] args) 
	{
		HashSet hset=new HashSet();
		for (int i=1;i<=10;i++) {
			hset.add(i);
		}
		HashSet h1=new HashSet(hset);
		System.out.println(h1);
	}
}