import java.util.*;
class ToArray
{
	public static void main(String[] args) {
		List<Integer> l=new ArrayList<>();
		l.add(10);
		l.add(20);
		l.add(30);
		l.add(40);
		l.add(50);
        
        System.out.println(l);
        Object []obj=l.toArray();
        System.out.println(Arrays.toString(obj));

       
        
        // System.out.println(Arrays.toString(obj));

	}
}