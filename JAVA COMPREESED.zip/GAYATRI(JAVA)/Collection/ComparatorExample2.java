import java.util.*;
class ComparatorExample2
{
	public static void main(String[] args) {
		List<Integer> list=new ArrayList<>();
		for (int i=1;i<=15;i++ ) {
			list.add((int)(Math.random()*10));
		}
		System.out.println(list);
		Collections.sort(list,new SortInAscending());
		System.out.println(list);
		Collections.sort(list,new SortInDescending());
		System.out.println(list);
	}
}
class SortInAscending implements Comparator<Integer>
{
	public int compare(Integer i1,Integer i2)
	{
		return i1-i2;
	}
}
class SortInDescending implements Comparator<Integer>
{
	public int compare(Integer i1,Integer i2)
	{
		return i2-i1;
	}
}