interface Interf
{
   int addition(int num1,int num2);
}
class LambdaExpression
{
	public static void main(String[] args) {
		Interf obj=(num1,num2)->num1+num2;
		System.out.println(obj.addition(5,5));
	}
}