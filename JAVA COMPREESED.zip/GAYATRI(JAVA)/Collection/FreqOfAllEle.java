import java.util.*;
class FreqOfAllEle
{
	public static void main(String[] args) {
		List<Integer> a=Arrays.asList(10,50,20,20,10,10,20,20,30,40,30,40,50,50);
		Set<Integer> b=new TreeSet(a);
		for (Integer i:b ) {
			System.out.println(i+"-"+Collections.frequency(a,i));
		}
	}
}