import java.util.*;
class LinkedListMethod1
{
	public static void main(String[] args) {
		LinkedList<Integer> l=new LinkedList<>();
		for (int i=10;i<=50;i+=10 ) {
			l.add(i);
		}
		System.out.println(l);
		l.removeFirst();
		System.out.println(l);
        l.removeLast();
		System.out.println(l);
	}
}