import java.util.*;//StudentManageMentSystem.java
class Student
{
	int id;
	String name;
	String branch;
	long phone;
	int yop;
	double per;
	Student(int id,String name,String branch,long phone,int yop,double per)
	{
		super();
		this.id=id;
		this.name=name;
		this.branch=branch;
		this.phone=phone;
		this.yop=yop;
		this.per=per;
	}
	public String toString()
	{
		return(this.id+"-"+this.name+"-"+this.branch+"-"+this.yop+"-"+this.per);
	}
}
class SortByYop implements Comparator<Student>
{
	public int compare(Student s1,Student s2)
	{
		return s1.yop-s2.yop;
	}
}
class SortByPer implements Comparator<Student>
{
	public int compare(Student s1,Student s2)
	{
		return (int)(s1.per-s2.per);
	}
}