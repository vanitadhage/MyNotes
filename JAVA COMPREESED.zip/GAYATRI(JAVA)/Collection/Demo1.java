import java.util.*;
class Demo1
{
	public static void main(String[] args) {
		List a=new ArrayList();
		a.add(10);
		System.out.println(a);
	}
}