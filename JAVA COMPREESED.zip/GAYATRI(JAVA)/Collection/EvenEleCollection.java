import java.util.*;
// import java.util.stream;
class EvenEleCollection
{
	public static void main(String[] args) {
		// List<Integer> l=new ArrayList<>();
      //Using stream
      // List<Integer> even=l.stream().filter((ele)->ele%2==0).collect();

        List<Integer> list=new ArrayList<>();

        for (int i=1;i<=10;i++ ) 
           	list.add(i);
          System.out.println(list);

          Iterator it =list.iterator();
          while(it.hasNext())
          {
          	Integer a=(Integer)it.next();
          	if (a%2!=0) {
          		it.remove();
          	}
          }
          System.out.println(list);
	}
}