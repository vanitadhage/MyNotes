import java.util.*;
class Demo<E>
{
   LinkedList<E> ll=new LinkedList<E>();
   
   public boolean offer(E i)
   {
     return (ll==null?null:ll.add(i));
   }
   public String toString()
   {
   	return (""+ll);
   }

   public E poll()
   {
   	return (ll==null?null:ll.get(0));
   }
   public E peek()
   {
    return (ll==null?null:ll.remove());
   }
   
}
class QueueImplementation
{
  public static void main(String[] args){
  	Demo<Integer> d=new Demo<Integer>();
  	d.offer(10);
  	d.offer(20);
  	d.offer(30);
  	System.out.println(d);
  	System.out.println(d.peek());
  	System.out.println(d.poll());

  
  }
}
