import java.util.*;
class FindFreq
{
	public static void main(String[] args) {
		List<Integer> a=Arrays.asList(10,20,20,10,10,20,20,30,40,50);
		System.out.println(a);
		System.out.println(Collections.frequency(a,20));
	}
}