import java.util.*;
class LinkedHashSetCons1
{
	public static void main(String[] args) {
		LinkedHashSet ls=new LinkedHashSet();
		ls.add(10);
		ls.add(20);
		
		System.out.println(ls);


	}
}