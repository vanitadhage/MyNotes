import java.util.*;
class ContainsAllMethod
{
	public static void main(String[] args) {
		Collection<Integer> a=Arrays.asList(10,20,30,40,50);
		// System.out.println(a.contains(10));
		// System.out.println(a.contains(60));
		// System.out.println(a.contains(null));
		// System.out.println(a.contains("50"));

       TreeSet<Integer> b=new TreeSet();
       System.out.println(b.containsAll(10,20,30));
       // System.out.println(b.containsAll("50"));
	}
}