import java.util.*;
class HashSetConstructor3
{
	public static void main(String[] args) 
	{
		HashSet hset=new HashSet(16,0.5f);
		for (int i=1;i<=10;i++) {
			hset.add(i);
		}
		System.out.println(hset);
	}
}

