import java.util.*;
class StackMethods
{
	public static void main(String[] args) {
		Stack c=new Stack();
		c.push(10);
		c.push(20);
		c.push(30);
		c.push(40);
		c.push(50);
		System.out.println(c);

		c.pop();
		System.out.println(c);

		
		System.out.println(c.peek());

		System.out.println(c.empty());
		
		System.out.println(c.search(1));



	}
}