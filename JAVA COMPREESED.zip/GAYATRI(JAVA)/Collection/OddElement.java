import java.util.*;
class OddElement
{
	public static void main(String[] args) {
		LinkedList<Integer> l=new LinkedList<>();
		for (int i=1;i<=20 ;i++ ) 
			l.add(i);
		
System.out.println(l);
		Iterator i=l.iterator();
	while(i.hasNext())
		{
			Integer e1=(Integer)i.next();
			if (e1%2!=0) {
				i.remove();
			}

		}
		System.out.println(l);
	}
}