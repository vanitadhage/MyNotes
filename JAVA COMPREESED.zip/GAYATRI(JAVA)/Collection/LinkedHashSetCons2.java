import java.util.*;
class LinkedHashSetCons2
{
	public static void main(String[] args) {
		LinkedHashSet ls=new LinkedHashSet();
		ls.add(10);
		ls.add(20);
		System.out.println(ls);

		LinkedHashSet ls1=new LinkedHashSet(ls);
		System.out.println(ls1);
	}
}