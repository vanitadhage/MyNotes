import java.util.*;
class Info implements Comparator<Info>
{
	int id;
	String name;
	Info(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	public String toString(){
		return this.id+"-"+this.name;
	}

	public int compare(Info info1,Info info2)
	{
		return info1.id-info2.id;
	}
}
class SortById implements Comparator<Info>
{
	public int compare(Info info1,Info info2)
	{
		return info1.id-info2.id;

	}
}
class SortByName implements Comparator<Info>
{
	public int compare(Info info1,Info info2)
	{
		return info1.name.compareTo(info2.name);
	}
}
class ComparatorExample
{
	public static void main(String[] args) {
		List<Info>li=new ArrayList<Info>();
		li.add(new Info(3,"Mahi"));
		li.add(new Info(4,"rahi"));
		li.add(new Info(2,"riya"));
		li.add(new Info(1,"vanita"));
		li.add(new Info(5,"Mansi"));

		Collections.sort(li,new SortById());
		// Collections.sort(li,new SortByName());


		for (Info info:li ) {
			System.out.println(info);
		}

	}
}
