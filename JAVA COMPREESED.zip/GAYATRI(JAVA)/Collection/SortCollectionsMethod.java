import java.util.*;
class SortCollectionsMethod
{
	public static void main(String[] args) {
		List<Integer> c=new ArrayList<>();
		c.add(10);
		c.add(30);
		c.add(20);
		c.add(50);
		c.add(40);
		c.add(60);
		c.add(70);

		System.out.println(c);

        System.out.println("Sort");
		Collections.sort(c);
		System.out.println(c);

        System.out.println("reverse");
        Collections.reverse(c);
        System.out.println(c);
		
		System.out.println("Shuffle");
        Collections.shuffle(c);
        System.out.println(c);

        System.out.println("Swap");
        Collections.swap(c,2,5);
        System.out.println(c);

        System.out.println("Fill");
        Collections.fill(c,80);
        System.out.println(c);

        System.out.println("Min");
       System.out.println(Collections.min(c));
        // System.out.println(c);

        System.out.println("Max");
        System.out.println(Collections.max(c));
        // System.out.println(c);

	}
}