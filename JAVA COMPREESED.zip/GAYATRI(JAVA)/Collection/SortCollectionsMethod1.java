import java.util.*;
class SortCollectionsMethod1
{
	public static void main(String[] args) {
		List<Integer> c=new ArrayList<>();
		for (int i=10;i<=100;i+=10 ) {
            c.add(i);
        }
		

  //       System.out.println("Sort");
		// Collections.sort(c);
		// System.out.println(c);

        // System.out.println("reverse");
        // Collections.reverse(c);
        // System.out.println(c);
		
		// System.out.println("Shuffle");
  //       Collections.shuffle(c);
  //       System.out.println(c);

        // System.out.println("Swap");
        // Collections.swap(c,2,5);
        // System.out.println(c);

        // System.out.println("Fill");
        // Collections.fill(c,80);
        // System.out.println(c);

       //  System.out.println("Min");
       // System.out.println(Collections.min(c));
        // System.out.println(c);

        System.out.println("Max");
        System.out.println(Collections.max(c));
  //       // System.out.println(c);

	}
}