import java.util.*;
class Info 
{
	int id;
	String name;
	Info(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	public String toString(){
		return this.id+"-"+this.name;
	}

	public int getId()
	{
		return id;
	}
	public String getName()
	{
		return name;
	}
}

class ComparatorExample1
{
	public static void main(String[] args) {
		List<Info>li=new ArrayList<Info>();
		li.add(new Info(3,"Mahi"));
		li.add(new Info(4,"rahi"));
		li.add(new Info(2,"riya"));
		li.add(new Info(1,"vanita"));
		li.add(new Info(5,"Mansi"));

		// li.sort(Comparator.comparing(Info::getId));
		// Collections.sort(li,Comparator.comparing(Info::getId));
		// li.sort(Comparator.comparing(Info::getName));
		Collections.sort(li,Comparator.comparing(Info::getName));




		for (Info info:li ) {
			System.out.println(info);
		}

	}
}
