import java.util.*;
class RemoveMethod
{
	public static void main(String[] args) 
	{
		// List a=new ArrayList();
		// for (int i=10;i<=100 ;i+=10 ) {
		// 	a.add(i);
		// }
		// System.out.println(a);
		// a.remove(50);//it will throw exception beacuse we can create store object in list type thats why it use list add(int)method which acceptint
		// System.out.println(a);



		Collection a=new ArrayList();
		for (int i=10;i<=100 ;i+=10 ) {
			a.add(i);
		}
		System.out.println(a);
		a.remove(50);
		System.out.println(a);
	}
}