import java.util.*;
class LinkedListMethod3
{
	public static void main(String[] args) {
		LinkedList<String> l=new LinkedList<String>();
		l.add("One");
		l.add("Two");
		l.add("Three");
		l.add("Four");
		l.add("Five");
        
	    System.out.println(l);
		System.out.println(l.removeFirstOccurance("One"));
		// l.removeFirstOccurance(10);
		// System.out.println(l);
  //       l.removeLastOccurance(50);
		// System.out.println(l);
	}
}