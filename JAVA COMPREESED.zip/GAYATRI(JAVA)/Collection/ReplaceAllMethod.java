import java.util.*;
class ReplaceAllMethod
{
	public static void main(String[] args) {
		List<Integer> c=new ArrayList<>();
		c.add(10);
		c.add(30);
		c.add(20);
		c.add(50);
		c.add(40);
		c.add(60);
		c.add(70);

		System.out.println("Replace All");
        Collections.replaceAll(c,10,90);
        System.out.println(c);
	}
}