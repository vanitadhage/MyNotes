import java.util.*;
class PrimeVector
{
	public static void main(String[] args) {
		Vector<Integer> v=new Vector<>();
		for (int i=1;i<=20 ;i++ ) {
			v.add(i);
		}

		Enumeration<Integer> e=v.elements();
		while(e.hasMoreElements())
		{
			isPrime(e.nextElement());
		}
	}
	public static void isPrime(Integer i)
	{
		int num=i.intValue();
		System.out.println(num);
		int count=0;
		for (int j=1;j<num ;j++ ) {
			if (num%2==0) {
				count++;
			}
		}
		System.out.println((count>0)?"NotPrime":"Prime");
	}

}