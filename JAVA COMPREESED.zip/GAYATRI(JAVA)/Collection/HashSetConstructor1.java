import java.util.*;
class HashSetConstructor1
{
	public static void main(String[] args) 
	{
		HashSet hset=new HashSet ();
		for (int i=1;i<=10;i++) {
			hset.add(i);
		}
		System.out.println(hset);

		
	}
}