import java.util.*;
class VectorMethodExample
{
	public static void main(String[] args) {
		Vector<Integer> v=new Vector<>();
		for (int i=1;i<=10 ;i++ ) {
			v.add(i);
		}
		System.out.println(v);

	    System.out.println("Capacity");
		System.out.println(v.capacity());
		
		System.out.println("First Element");
		System.out.println(v.firstElement());

		System.out.println("Last Element");
		System.out.println(v.lastElement());

		System.out.println("Element");
		System.out.println(v.elementAt(1));

		System.out.println("set Element");
		v.setElementAt(10,2);
		System.out.println(v);
 
		System.out.println("remove Element");
		v.removeElementAt(1);
		System.out.println(v);
        
		System.out.println("insert Element");
		v.insertElementAt(11,2);
		System.out.println(v);
	}
}