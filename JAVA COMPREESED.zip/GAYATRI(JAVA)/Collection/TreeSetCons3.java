import java.util.*;
class Sort implements Comparator<Integer>
{
	public int compare(Integer i1,Integer i2)
	{
		// return i1-i2;//Ascending 
		return i2-i1;//Descending
	}
}
class TreeSetCons3
{
	public static void main(String[] args) {
		TreeSet<Integer> ts=new TreeSet<>(new Sort());
		ts.add(10);
		ts.add(50);
		ts.add(20);
		ts.add(30);
		ts.add(40);
		System.out.println(ts);
	}
}