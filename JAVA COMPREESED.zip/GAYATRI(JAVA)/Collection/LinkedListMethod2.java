import java.util.*;
class LinkedListMethod2
{
	public static void main(String[] args) {
		LinkedList<Integer> l=new LinkedList<>();
		for (int i=20;i<=50;i+=10 ) {
			l.add(i);
		}
		System.out.println(l);
		l.addFirst(10);
		System.out.println(l);
        l.addLast(60);
		System.out.println(l);
	}
}