import java.util.*;
class LinkedHashSetCons3
{
	public static void main(String[] args) 
	{
		LinkedHashSet ls=new LinkedHashSet(10);
		ls.add(10);
		ls.add(20);
		System.out.println(ls);
	}
}