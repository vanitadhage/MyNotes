import java.util.*;
class TreeSetMethods
{
	public static void main(String[] args) {
		TreeSet ts=new TreeSet();
		for (int i=10;i<=100 ;i+=10 ) {
			ts.add(i);
		}
		System.out.println(ts);
		
		System.out.println("First element :-"+ts.first());
		System.out.println(ts);
		System.out.println("Last element :-"+ts.last());
		System.out.println(ts);
		System.out.println("Lower element :-"+ts.lower(40));
		System.out.println(ts);
		System.out.println("Floor :-"+ts.floor(55));
		System.out.println(ts);
		System.out.println("ceiling :-"+ts.ceiling(59));
		System.out.println(ts);
		System.out.println("Higher :-"+ts.higher(60));
		System.out.println(ts);
		System.out.println("PollFirst :-"+ts.pollFirst());
		System.out.println(ts);
		System.out.println("PollLat :-"+ts.pollLast());
		System.out.println(ts);
		
	}
}