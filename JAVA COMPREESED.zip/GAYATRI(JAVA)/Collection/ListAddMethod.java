import java.util.*;
class ListAddMethod
{
	public static void main(String[] args) {
		List<Integer> l=new ArrayList<>();
		for (int i=10;i<=50;i+=10 ) {
			l.add(i);
		}
        System.out.println(l);
		// System.out.println("Add");
		l.add(5,60);
		System.out.println(l);

		Collection<Integer> c=new ArrayList<>();
		for (int i=70;i<=110;i+=10 ) {
			c.add(i);
		}
		System.out.println(c);

		System.out.println("AddAll");
		l.addAll(c);
		System.out.println(l);

		System.out.println("Remove");
		l.remove(2);
		System.out.println(l);

		System.out.println("indexOff");
		System.out.println(l.indexOf(100));
		// System.out.println(l);

		// System.out.println("LastIndexOff");
		System.out.println(l.lastIndexOf(110));

		System.out.println("Get");
		System.out.println(l.get(1));
		// System.out.println(l);


		// System.out.println("set");
		System.out.println(l.set(1,100));
		// System.out.println(l);

	}
}