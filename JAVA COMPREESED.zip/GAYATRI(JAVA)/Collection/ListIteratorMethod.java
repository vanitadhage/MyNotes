import java.util.*;
class ListIteratorMethod
{
   public static void main(String[] args) {
   	List<Integer> a=new ArrayList<>();
   	for (int i=1;i<=10 ;i++ ) {
   		a.add(i);
   	}
   	System.out.println(a);
   	ListIterator li=a.listIterator();
   	while(li.hasPrevious())
   	{
   		if(li.previous() instanceof Integer)
   		{
   			li.set("Hi");
   		}
   	}
   }
}