import java.util.Scanner;
class AreaOfRectangle
{
	public static void main(String[] args) 
	{
	  Scanner sc=new Scanner(System.in);
		System.out.print("Enter a length :");
		double length=sc.nextDouble();
		System.out.print("Enter a Width :");
		double height=sc.nextDouble();
		double area=length*height;
		System.out.print("Area  of Rectangle :"+area);	
	}
}