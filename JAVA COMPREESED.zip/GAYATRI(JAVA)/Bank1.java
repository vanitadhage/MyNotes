import java.util.Scanner;
class Bank1
{
	static Scanner sc=new Scanner(System.in);
	static AccountHolder obj;
	static
	{
		System.out.println("******WELCOME TO LAXMI-CHIT FUND******");
	}

	public static void main(String[] args) 
	{
		for (; ; ) 
		{
			System.out.println("CHOOSE AN OPTION :1.Create Account 2.Existing Account-Holder");
			System.out.println("Enter number :");
			int option=sc.nextInt();
			switch(option)
			{
              case 1:
              {
              	Scanner scanner=new Scanner(System.in);
              	System.out.println("**** Account Creation ****");
              	System.out.println("Please enter details ");
              	scanner.reset();
              	System.out.print("Enter your name :");
              	String name=scanner.nextLine();
              	scanner.reset();//write
              	System.out.print("Address :");
              	String address=scanner.nextLine();
              	System.out.print("Contact Number :");
              	scanner.reset();
              	long contactNumber=scanner.nextLong();
              	System.out.print("Adhar Number :");
              	long adharNumber=scanner.nextLong();
              	System.out.print("Pancard Number :");
              	String pancardNumber=scanner.next();
              	System.out.print("Opening deposit amount :");
              	scanner.reset();
              	double amount=scanner.nextDouble();
              	System.out.print("Enter a new pin");
              	int pin=scanner.nextInt();
              	obj =new AccountHolder(name,address,contactNumber,adharNumber,pancardNumber,amount,pin);
              	break;
              }

              case 2:
              {
              	for (; ; ) 
              	{
              		System.out.println("******* Features *******");
              		System.out.println("1.Deposit 2.Withdraw 3.Account-Balance 4.Account-Details 5.Exit");
              		System.out.print("Enter an option :");
              		System.out.println();
              		int option2=sc.nextInt();

              		switch(option2)
              		{
              			case 1:
              			{
              				System.out.println("Amount Deposit Feature");
              				System.out.print("Enter the Amount to deposit :");
              				double depositAmount=sc.nextDouble();
              				double newBalance=obj.getBalance()+depositAmount;
              				obj.setBalance(newBalance);
              				System.out.println("Amount Deposited");
              				continue;
              			}
              			case 2:
              			{
                            System.out.println("Amount Withdraw Feature");
                            System.out.print("Enter the amount to withdraw :");
                            double withdrawAmount=sc.nextDouble();
                            System.out.print("Enter your pin :");
                            int pin1=sc.nextInt();
                            if(pin1 == obj.getPin())
                            {
                            	if (withdrawAmount<obj.getBalance()) 
                            	{
                            	   System.out.println("Amount Withdraw");
                            	   double newBalance = obj.getBalance()-withdrawAmount;
                            	   obj.setBalance(newBalance);	
                            	}
                            	else
                            	{
                            		System.out.println("Insufficient Funds");
                            	}
                            }
                            else
                            {
                            	System.out.println("Incorrect Pin try Again");
                            }
                            continue;
              			}
              			case 3:
              			{
              				System.out.println("Balance Feature");
              				System.out.print("Enter your pin :");
              				int pin1=sc.nextInt();
              				if(obj.getPin()==pin1)
              				{
              					System.out.println("Amount Balance is :"+obj.getBalance());
              				}
              				else
              				{
              					System.out.println("Incorrect Pin & Try again");
              				}
              				continue;
              			}
              			case 4:
              			{
              				System.out.println("Account Details");
              				System.out.println("Account Holder :"+obj.getName());
              				System.out.println("Address :"+obj.getAddress());
              				System.out.println("Phone number :"+obj.getContact());
              				System.out.println("Account Number :"+obj.accountNumber);
              				continue;
              			}
              			case 5:
              			{
              				System.exit(0);
              			}
              			default:
              			{
              				System.out.println("Enter an correct option");
              				break;
              			}
              		}
              		break;
              	}
              }
              default:System.out.println("Invalid Input");break;

			}
		}
	}
}