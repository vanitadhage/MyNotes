class ForLoop6
{
	public static void main(String[] args) {
		int b=0;
		boolean a=true;
		for (;a ; ) {
			System.out.println("hello");
			b++;
			if (b==1000) {
				a=false;
			}

		}
		System.out.println("byee");
	}
}