
class Aeroplane
{
 public static void main(String [] args)
  {
   short noOfPassenger=600;
   short noOfPilots=3;
   short noOfSeats=850;
   short noOfdoors=6;
   short noOfengines=4;
   System.out.println("No Of Passenger :"+noOfPassenger);
   System.out.println("No Of Pilots :"+noOfPilots);
   System.out.println("No Of Seats :"+noOfSeats);
   System.out.println("No Of doors :"+noOfdoors);
   System.out.println("No Of engines :"+noOfengines);
  }
}