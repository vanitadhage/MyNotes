class Example14
{
	static 
	{
		System.out.println("Static block 1");
	}
	public static void main(String[] args) {
		Example15 a=new Example15();
		a.m1();
	}
}
class Example15
{
	static
	{
		System.out.println("Hii");
	}
	{
		System.out.println("Hellooo");
	}
	public void m1()
	{
		System.out.println("Byeee");
	}
}