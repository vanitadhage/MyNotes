class SwitchExample7
{
	public static void main(String[] args) 
	{
	   byte a = 7;
	   switch(a)
	   {
	   	case 1:System.out.println("case 1");break;
	   	  default:System.out.println("From default ");     
	   	case 2:System.out.println("case 2");break;
	   	      
	   	case 3:System.out.println("case 3");break;

	   	case 4:System.out.println("case 3");break;
	  
	   }	
	}
}