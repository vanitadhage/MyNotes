import java.util.*;
class TwoDArray
{
	public static void main(String[] args) {
		// String [][] arr={{"a","b"},{"c"},{"d","e","f"}};

       

		// 1.For Loop


		// for (int i=0;i<arr.length ;i++ ) 
		// {
		// 	for (int j=0;j<arr[i].length ;j++ ) 
		// 	{
		// 		System.out.print(arr[i][j]+" ");
		// 	}
		// 	System.out.println();
		// }


       //H.W
		// byte [][] arr={{11,22},{33},{44,55,66}};

		// for (byte i=0;i<arr.length ;i++ ) 
		// {
		// 	for (byte j=0;j<arr[i].length ;j++ ) 
		// 	{	
		// 		System.out.print(arr[i][j]+" ");
		// 	}
		// 	System.out.println();
		// }


        
         // 2 While Loop
		// int i=0;
		// while(i<arr.length)
		// {
		// 	int j=0;
		// 	while(j<arr[i].length)
		// 	{
		// 		System.out.print(arr[i][j]+"  ");
		// 		j++;
		// 	}
		// 	i++;
		// 	System.out.println();
		// }

		//H.W
		// short [][] arr={{111,222},{333},{444,555,666}};
		// short i=0;
		// while(i<arr.length)
		// {
		// 	short j=0;
		// 	while(j<arr[i].length)
		// 	{
		// 		System.out.print(arr[i][j]+"  ");
		// 		j++;
		// 	}
		// 	i++;
		// 	System.out.println();
		// }

		// 3.Do-While Loop

		// int i=0;
		// do
		// { 
		// 	int j=0;
		// 	do
		// 	{
  //             System.out.print(arr[i][j]+" ");
  //             j++;
		// 	}while(j<arr[i].length);
		// 	System.out.println();
		// 	i++;
		// }while(i<arr.length);
       

       //H.W
		// long [][]arr={{500,600},{700,800,900}};
		// int i=0;
		// do
		// { 
		// 	int j=0;
		// 	do
		// 	{
  //             System.out.print(arr[i][j]+" ");
  //             j++;
		// 	}while(j<arr[i].length);
		// 	System.out.println();
		// 	i++;
		// }while(i<arr.length);
       

       // 4.For each Loop  (braces also optional.)
  //      String [][] arr={{"a","b"},{"c"},{"d","e","f"}};
		// for (String []i :arr ) {
		// 	for (String j :i ) {
		// 		System.out.print(j+" ");
				
		// 	}
		// 	System.out.println();
		// }


      //5.deepToString()
		// String [][] arr={{"a","b"},{"c"},{"d","e","f"}};
		//  System.out.println(Arrays.deepToString(arr));

		// 6.toString
		char [][]arr={{'A','B'},{'C','D'}};
		for (char []chr :arr ) {
			System.out.print(Arrays.toString(chr));
		}
	}
