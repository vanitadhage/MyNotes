class Home
{
 public static void main(String [] args)
 {
  byte member=10;
  byte noOfMobiles=6;
  byte noOfFans=5;
  byte window=6;
  byte shoes=20;
  System.out.println("Member :"+member);
  System.out.println("No Of Mobiles :"+noOfMobiles);
  System.out.println("No Of Fans:"+noOfFans);
  System.out.println("Window:"+window);
  System.out.println("Shoes :"+shoes);
 }
}