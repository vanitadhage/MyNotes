import java.util.*;
import java.io.*;
import java.awt.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
class MaharajSketch
{
	public static void main(String[] args) {
		File file=new File("C:\\Users\\phoenix\\Desktop\\maharaj.gif");
		try{
			BufferedImage image=ImageIO.read(file);
			for (int i=0;i<image.getHeight() ;i++ ) {
				for (int j=0;j<image.getWidth() ;j++ ) {
					Color color=new Color(image.getRGB(i,j));
					if ((color.getRed()==0)&&(color.getGreen()==0)&&(color.getBlue()==0)) {
						System.out.print("*");
					}else{
						System.out.print(" ");
					}
				}
				System.out.println();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}