//Q)Write a java program to find last digit of a number.
import java.util.Scanner;
class LastDigit
{
	public static void main(String[] args)
   {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num1=sc.nextInt();
		int num2=num1%10;
		System.out.print("Last digit of number :"+num2);
	}
}