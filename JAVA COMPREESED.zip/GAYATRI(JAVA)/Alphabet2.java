class Alphabet2
{
	public static void main(String[] args) {
		for (char i='z';i>='a' ;--i ) {
			System.out.print(i +"  ");
		}
	}
}