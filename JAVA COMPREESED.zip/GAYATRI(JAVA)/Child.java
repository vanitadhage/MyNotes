class Parent
{
	String a="Parent";
	Parent()
	{
		System.out.println("Parent const");
	}
	void m1()
	{
		System.out.println("M1() Prent");
	}
	int addition(int a,int b)
	{
		return a+b;
	}
}
class Child extends Parent
{
	public static void main(String[] args) {
		Child a=new Child();
		a.interaction();
		System.out.println(a.a);
	}
	public void interaction()
	{
		System.out.println(super.a);
		super.m1();
		int op=super.addition(10,20);
		System.out.println(op);
	}
}