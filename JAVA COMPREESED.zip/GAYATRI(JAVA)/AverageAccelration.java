import java.util.Scanner;
class AverageAccelration
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a v0 :");
		double v0=sc.nextDouble();             //20.5
		System.out.print("Enter a v1 :");
		double v1=sc.nextDouble();            //50.9
		System.out.print("Enter a t :");
		double t=sc.nextDouble();             //5.5
        double a=v1-v0;  
        double op=a/t; 

        System.out.println("The Average Accelration is :"+a);                     
	}
}