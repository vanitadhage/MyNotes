import java.util.Scanner;
class AdditionOfDigitEx
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number");
		int num=sc.nextInt();  //456
		int op=0;//0
		int rem=num%10;//6
		op=rem; //6
		num=num/10;//45
		rem=num%10;//5
		op=op+rem;//6+5
		num=num/10;//4
		op=op+num;//6+5+4=15
		System.out.println("Addition of 3 digit number is :"+op);
	}
}