class Door
{
	String material;
	String color;
    Handle handle;
	Door(String material,String color)
	{
		this.material=material;
		this.color=color;
	}
	void displayDoor()
	{
		System.out.println("Door Details");
		System.out.println("Material :"+this.material);
		System.out.println("color :"+this.color);
	}
	void createHandle(String material,String shape)
	{
      handle=new Handle(material,shape);

	}
}