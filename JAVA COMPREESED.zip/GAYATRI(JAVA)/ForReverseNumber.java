// import java.util.Scanner;
// class ForReverseNumber
// {
// 	public static void main(String[] args) {
// 		Scanner sc=new Scanner(System.in);
// 		System.out.print("Enter a number :");
// 		int num=sc.nextInt();
//         int i,rev=0;
//         for (; num!=0 ;num /=10 ) {
//         	i=num%10;
//             rev=rev*10+i;
//         }
//         System.out.println("The Reverse Number is :"+rev);

// 	}
// }

import java.util.Scanner;
class ForReverseNumber
{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter a number :");
        int num=sc.nextInt();
        int i,rev=0;
        for ( ;num>0 ;num/=10 ) {
            i=num%10;
            rev=rev*10+i;
        }
        System.out.print(rev);
    }
}