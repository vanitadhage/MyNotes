class Parent
{
   public void marriage()
   {
   	System.out.println("Sushilla");
   }
}
class Child extends Parent
{
   public void marriage()
   {
   	System.out.println("Shilla");
   }
}
class Driver4
{
  public static void main(String[] args) {
  	Child obj=new Child();
    obj.marriage();

    Parent obj1=(Child)obj;
    obj1.marriage();
  }
}