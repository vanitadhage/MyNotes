import java.util.Scanner;
class Seasons
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a month :");
		String month=sc.next();

		switch(month.toLowerCase())
		{
			case "oct":
			case "nov":
			case "dec":
			case "jan":System.out.println("It's a winter buy a sweeter");break;
			case "feb":
			case "mar":
			case "apr":
			case "may":System.out.println("It's a summer keep youself cool");break;
			case "jun":
			case "july":
			case "aug":
			case "sep":System.out.println("It's a moonsoon buy a raincoat");break;
			default:System.out.println("wrong month Entered");

		}
	}
}