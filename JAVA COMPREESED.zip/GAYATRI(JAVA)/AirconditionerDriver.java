class Airconditioner
{
	String a="Air Conditioner";
	public void aircond()
	{
		System.out.println("Types of Air conditioner");
	}
}
class Ac extends Airconditioner
{
	public void brand()
	{
		System.out.println("Brand :BlueStar");
	}
}
class AirconditionerDriver
{
	public static void main(String[] args) {
		AirconditionerDriver obj1=new AirconditionerDriver();
		obj1.m1();
	}
	public void m1()
	{
        Ac obj=new Ac();
		obj.aircond();
		obj.brand();
		System.out.println(obj.a);
	}
}