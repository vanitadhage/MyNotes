import java.util.Scanner;
class Equation
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a num1 :");
		double num1=sc.nextDouble();
		System.out.print("Enter a num2 :");
		double num2=sc.nextDouble();
		System.out.print("Enter a num3 :");
		double num3=sc.nextDouble();
		System.out.print("Enter a num4 :");
		int num4=sc.nextInt();
		double result1=num1*num2*num3*num4;
	    System.out.println("multiplication of 1st four num :"+result1);
		System.out.print("Enter a num5 :");
		double num5=sc.nextDouble();
		System.out.print("Enter a num6 :");
		double num6=sc.nextDouble();
		double result2=num5*num6;
		System.out.println("multiplication of  num : :"+result2);
		double finalResult=result1/result2;
		System.out.print("Final result :"+finalResult);

	}
}