import java.util.Scanner;
class CalculateTip
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a subtotal :");
		double subtotal=sc.nextDouble();

		System.out.print("Enter a tip rate : ");
		double tipRate=sc.nextDouble();

		double tip=(tipRate/100)*subtotal;
		System.out.println("The tip is :"+tip);
		double total=subtotal+tip;
		System.out.println("The total is :"+total);
	}
}