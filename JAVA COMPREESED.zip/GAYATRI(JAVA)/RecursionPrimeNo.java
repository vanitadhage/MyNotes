// class RecursionPrimeNo
// {
// 	public static void main(String[] args) {
// 		int a=3;
// 		if (prime(a,2)) {
// 			System.out.println("It is prime num");
// 		}
// 		else
// 		{
// 			System.out.println("Not a prime");
// 		}
// 	}
// 	public static boolean prime(int a,int i)
// 	{
// 		if (a<=2) 
// 			return (a==2)? true:false;                                  
// 			if (a%i==0) 
// 				return false;
// 				if (i*i>a) 
// 					return true;
// 		return prime(a,i+1);
// 	}
// }



//Prime number using Recursion

 class RecursionPrimeNo
 {
 	static int i=2;
 	public static void main(String[] args) {
 		int num=13;
 		int count=prime(num);
 		System.out.println((count==0)?"Prime":"Not a prime");
 	}
 	public static int prime(int num)
 	{
 		int count=0;
 		if (num==i) {
 			return count;
 		}
 		if (num%i==0) {
 			count++;
 			return count;
 		}
 		i++;
 		prime(num);
 		return count;
 	}
 }