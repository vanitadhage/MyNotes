import java.util.Scanner;
class NumberOfYears
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        
		System.out.print("Enter the number of minutes :");
		long noOfMin=sc.nextLong();
		long year=(noOfMin/(60*24*365));
		System.out.println("The approxiate years is :"+year);
	}
}