import java.util.Scanner;
class VolumeOfCylinder
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		final double pi=3.14;
		System.out.print("Enter a radius :");
		double radius=sc.nextDouble();
		double area=pi*radius*radius;
		System.out.println("Area of cylinder :"+area);
		System.out.print("Enter a height :");
		double height=sc.nextDouble();
		double volume=area*height;
		System.out.println("Volume of cylinder :"+volume);
	}
}