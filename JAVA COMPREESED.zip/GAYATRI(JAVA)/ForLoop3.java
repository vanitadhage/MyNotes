class ForLoop3
{
	public static void main(String[] args) {
		for (;false ; ) {
			System.out.println("hello");
		}
		System.out.println("byee");
	}
}