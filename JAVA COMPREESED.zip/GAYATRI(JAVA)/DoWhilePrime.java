import java.util.Scanner;
class DoWhilePrime
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
        int i=2;
        int count=0;
		do
		{
          if (num%i==0) {
          	count++;
          }
          i++;
		}while(i<num);
		if (count!=0) {
			System.out.println("Entered number is Not Prime");
		}
		else{
			System.out.println("Enterred number is Prime");
		}
	}
}