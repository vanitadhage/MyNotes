import java.util.*;
class IBMAsessment5
{
	public static void main(String[] args) {
		int arr[]={1,1,2,4};
		int load =3;
		int minServers=getMinServers(arr,load) ;
		System.out.println(minServers);
	}
	public static int getMinServers(int []arr,int load)
	{
		int count=0;
        System.out.println(Arrays.toString(arr));
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
        int intLoad=0;
        for (int i=arr.length-1;i>=0 ;i-- ) {
        	if (intLoad+arr[i]<=load) {
        		count++;
        		intLoad+=arr[i];
        	}
        	if (intLoad==load) {
        		return count;
        	}
        }
        return -1;
	}
}