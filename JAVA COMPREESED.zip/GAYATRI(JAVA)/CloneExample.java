class Student implements Cloneable
{
  String name;
  String ntvplace;
  long phoneNumber;
  String branch;

  Student(String name,String ntvplace,long phoneNumber,String branch)
  {
    this.name=name;
    this.ntvplace=ntvplace;
    this.phoneNumber=phoneNumber;
    this.branch=branch;
  }
  public Object clone() throws CloneNotSupportedException
  {
  	return super.clone();  
  }

}
class CloneExample
{
   public static void main(String[] args) throws CloneNotSupportedException
   {
   	Student obj1=new Student("Ramesh","Pune",9876543212l,"Cs");
   	Student obj2=obj1;
   	System.out.println(obj1.name);
   	System.out.println(obj2.name);
    obj1.name="suresh";
    System.out.println(obj1.name);
    System.out.println(obj2.name);
   }
}