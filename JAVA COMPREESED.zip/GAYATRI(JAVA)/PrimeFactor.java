//write a java program to find prime factors of a number.
import java.util.Scanner;
class PrimeFactor
{
	public static void main(String[] args) {
		// int num=20;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number :");
		int num=sc.nextInt();
	    
		for (int i=1;i<=num ;i++ ) {
			if (num%i==0) {
				// System.out.print(i+"  ");
				int num2=i;
				int count=0;
				for (int j=2;j<num2;j++ ) {
					if (num2%j==0) {
						count++;
						break;
					}
				}
				if (count==0&&num2>1) 
				{
					System.out.println(num2);
			    }
			}
		
		}
	}
}