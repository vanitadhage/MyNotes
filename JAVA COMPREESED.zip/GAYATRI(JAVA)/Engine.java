class Engine
{
	int noOfPiston;
	double bhp;
	String engineType;

	Engine(int noOfPiston,double bhp,String engineType)
	{
		this.noOfPiston=noOfPiston;
		this.bhp=bhp;
		this.engineType=engineType;
	}
	public void displayEngine()
	{
		System.out.println("Engine Details");
		System.out.println("No of Piston "+this.noOfPiston);
		System.out.println("Break horse power :"+this.bhp+"bhp");
		System.out.println("Engine Type :"+this.engineType);
	}
}