class MethodEx3
{
	public static void main(String[] args) {
		System.out.println("Main Starts");
		ramesh(10);  //method calling statement
		System.out.println("Main ends");
	}
	public static void ramesh(int a)
	{
		System.out.println("Ramesh starts");
		System.out.println(a +"from main");
		System.out.println(suresh()+"From suresh");
		System.out.println("Ramesh ends");
	}
	public static int suresh()
	{
		System.out.println("suresh starts");
		int b=20;
		return b;
	}
}