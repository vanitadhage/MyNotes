import java.util.Scanner;
class Bmi
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		final double onePoundInKg=0.45359237;
		final double oneInchInMeter=0.0254;

		System.out.print("Enter weight in pounds :");
		double weight=sc.nextDouble();

		System.out.print("Enter a height in inches :");
		double height=sc.nextDouble();

		weight=weight*onePoundInKg;
		height=height*oneInchInMeter;

		double bodyMassIndex=weight/Math.pow(height,2);
		System.out.println("BMI is :"+bodyMassIndex);
	}
}
