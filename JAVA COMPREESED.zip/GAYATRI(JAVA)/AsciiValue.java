// import java.util.Scanner;
// class AsciiValue
// {
// 	public static void main(String[] args) {
// 		Scanner sc=new Scanner(System.in);

// 		char ch1='A';
// 		char ch2='Z';

// 		int asciiV1=ch1;
// 		int asciiV2=ch2;

// 		System.out.println("The Ascii value of " + ch1 +"is :"+asciiV1);
// 		System.out.println("The Ascii value of " + ch2 +"is :"+asciiV2);



// 	}
// }


import java.util.Scanner;
class AsciiValue
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter a char1 :");
        char ch1=sc.next().charAt(0);
	
        System.out.print("Enter a char2 :");
        char ch2=sc.next().charAt(0);

		int asciiV1=ch1;
		int asciiV2=ch2;

		System.out.println("The Ascii value of " + ch1 +"is :"+asciiV1);
		System.out.println("The Ascii value of " + ch2 +"is :"+asciiV2);


	}
}


